import { GoogleGenAI } from "@google/genai";
import { 
  Difficulty, Question, Feedback, VocabQuestion, ReadingPassage, 
  CollocationQuestion, WordRelationQuestion, IdiomQuestion, DictationQuestion, 
  ToneQuestion, MapQuestion, SynapticBridgeQuestion, EchoQuestion, 
  SpeakingCueCard, HeadingMatchGame, StyleTransferResult, PronunciationResult, 
  SynapticFeedback, EchoFeedback, FreeRecallResult, AssessmentQuestion,
  VocabOption
} from '../types';

const getGenAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

const getModel = (complex: boolean = false) => complex ? 'gemini-3-pro-preview' : 'gemini-3-flash-preview';

const safeParseJSON = (text: string) => {
  try {
    const jsonMatch = text.match(/\{[\s\S]*\}|\[[\s\S]*\]/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
    return JSON.parse(text);
  } catch (e) {
    console.error("JSON Parse Error", e);
    return null;
  }
};

const safeParseArray = (text: string) => {
    const parsed = safeParseJSON(text);
    return Array.isArray(parsed) ? parsed : [];
};

const getStrictLevelPrompt = (difficulty: Difficulty) => {
    return `Strictly adhere to IELTS Band Level: ${difficulty}.`;
};

export const generateQuestion = async (difficulty: Difficulty): Promise<Question> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Generate an IELTS Paraphrasing question. ${getStrictLevelPrompt(difficulty)}.
        Return JSON: { "text": "Original sentence", "context": "Academic/General", "targetVocabulary": ["word1", "word2"] }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseJSON(response.text) as Question;
};

export const evaluateParaphrase = async (original: string, userText: string): Promise<Feedback> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(true),
        contents: `Evaluate this IELTS paraphrase.
        Original: "${original}"
        User: "${userText}"
        
        Return JSON: {
            "score": number (0-100),
            "breakdown": { "vocabulary": number, "grammar": number, "meaning": number },
            "analysis": "Specific feedback",
            "strengths": ["point 1", "point 2"],
            "weaknesses": ["point 1", "point 2"],
            "betterAlternative": "Band 9 version",
            "vocabularyUsed": ["list", "of", "words"],
            "inlineFeedback": [{ "text": "substring", "type": "strength"|"weakness"|"improvement", "explanation": "why" }]
        }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseJSON(response.text) as Feedback;
};

export const evaluateEssay = async (prompt: string, essay: string): Promise<Feedback> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(true),
        contents: `Evaluate this IELTS Task 2 Essay.
        Prompt: "${prompt}"
        Essay: "${essay}"
        
        Return JSON: {
            "score": number (0-100),
            "breakdown": { "vocabulary": number, "grammar": number, "taskResponse": number, "coherence": number },
            "analysis": "Comprehensive feedback",
            "strengths": [],
            "weaknesses": [],
            "betterAlternative": "A brief Band 9 paragraph example",
            "vocabularyUsed": [],
            "inlineFeedback": []
        }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseJSON(response.text) as Feedback;
};

export const generateVocabSet = async (difficulty: Difficulty): Promise<VocabQuestion[]> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Generate 5 IELTS Vocabulary questions. ${getStrictLevelPrompt(difficulty)}.
        Format:
        1. DEFINITION: Match word to definition.
        2. SENTENCE: Fill in the blank (contextSentence uses '_______').
        3. SPELLING: Anagram or spelling check.
        
        Return JSON array of { 
            id, word, definition, contextSentence, 
            options: [{word, definition, example}], 
            correctAnswer, synonyms: [], band: "7.0-9.0", 
            questionType: "DEFINITION" | "SENTENCE" | "SPELLING" 
        }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseArray(response.text) as VocabQuestion[];
};

export const generateVocabCard = async (word: string, context: string): Promise<VocabQuestion> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Generate a detailed vocabulary card for "${word}" in the context of: "${context}".
        Return JSON: {
            id: "${word}", 
            word: "${word}", 
            definition: "concise academic definition", 
            contextSentence: "example sentence", 
            options: [], 
            correctAnswer: "${word}",
            synonyms: ["syn1", "syn2", "syn3"],
            band: "estimated IELTS band"
        }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseJSON(response.text) as VocabQuestion;
};

export const generateCollocationSet = async (difficulty: Difficulty): Promise<CollocationQuestion[]> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Generate 5 IELTS Collocation questions. ${getStrictLevelPrompt(difficulty)}.
        Return JSON array of { id, stem, options, correctAnswer, explanation }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseArray(response.text) as CollocationQuestion[];
};

export const generateWordRelationSet = async (type: 'SYNONYM' | 'ANTONYM', difficulty: Difficulty): Promise<WordRelationQuestion[]> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Generate 5 IELTS ${type} questions. ${getStrictLevelPrompt(difficulty)}. 
        
        Mix 2 variants randomly (approx 50/50 split):
        1. "MCQ": Standard multiple choice. Find the ${type} for the 'target' word among 'options' (4 choices).
        2. "BINARY": True/False statement. Format: "'target' is a ${type} of 'secondWord'". 'correctAnswer' is "True" or "False".
        
        IMPORTANT: 
        - Include an 'explanation' field defining the target word and why the answer fits.
        - For BINARY questions, the 'options' field MUST be an empty array [].
        - For BINARY questions, 'secondWord' MUST be provided.
        
        Return JSON array of { id, target, secondWord, options, correctAnswer, type: '${type}', variant: 'MCQ' | 'BINARY', explanation }.`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseArray(response.text) as WordRelationQuestion[];
};

export const generateIdiomSet = async (difficulty: Difficulty): Promise<IdiomQuestion[]> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Generate 5 IELTS Idiom questions. ${getStrictLevelPrompt(difficulty)}.
        Mix variants: MCQ (fill blank), MATCH (match idiom halves).
        Return JSON array of { id, sentence, missingWord, options, meaning, variant, pairs: [{a, b}], correctAnswer }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseArray(response.text) as IdiomQuestion[];
};

export const generateDictationSet = async (difficulty: Difficulty): Promise<DictationQuestion[]> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Generate 5 IELTS Dictation sentences. ${getStrictLevelPrompt(difficulty)}.
        Sentences should be challenging with tricky spelling or homophones.
        Return JSON array of { id, sentence, focusWords }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseArray(response.text) as DictationQuestion[];
};

export const generateToneSet = async (difficulty: Difficulty): Promise<ToneQuestion[]> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Generate 5 Tone/Register transformation questions. ${getStrictLevelPrompt(difficulty)}.
        User sees a casual sentence and must pick the best formal/academic equivalent.
        Return JSON array of { id, casualSentence, options, correctAnswer, explanation }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseArray(response.text) as ToneQuestion[];
};

export const generateMapQuestion = async (difficulty: Difficulty): Promise<MapQuestion> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Generate a Map Labelling listening script and question. ${getStrictLevelPrompt(difficulty)}.
        The map context should be a campus or facility layout.
        The audio script should describe a path to a specific location.
        Return JSON object { id, mapSvg: "campus_1", audioScript, correctLocationId, options: ["Library", "Cafe", "Lab", "Gym", "Entrance"] }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseJSON(response.text) as MapQuestion;
};

export const generateSynapticBridgeSet = async (difficulty: Difficulty): Promise<SynapticBridgeQuestion[]> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(true),
        contents: `Generate 3 Synaptic Bridge questions. ${getStrictLevelPrompt(difficulty)}.
        Task: Provide a simple sentence and a target 'anchor word'. User must rewrite the sentence to include the anchor word naturally.
        Return JSON array of { id, simpleSentence, anchorWord, definition, constraint, targetCollocation }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseArray(response.text) as SynapticBridgeQuestion[];
};

export const generateEchoSet = async (difficulty: Difficulty): Promise<EchoQuestion[]> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Generate 3 Lexical Echo questions. ${getStrictLevelPrompt(difficulty)}.
        Task: Provide a high-level word. User must actively recall and type the definition.
        Return JSON array of { id, word, context, fullDefinition, keyAnchors: ["keyword1", "keyword2"], phonetic }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseArray(response.text) as EchoQuestion[];
};

export const generateReadingPassage = async (difficulty: Difficulty, topic: string = "Science"): Promise<ReadingPassage> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(true),
        contents: `Generate an IELTS Reading Passage about ${topic}. ${getStrictLevelPrompt(difficulty)}.
        Length: Approx 300 words.
        Include 4 questions.
        Return JSON object { title, text, questions: [{ id, text, options, correctAnswer }], band, topic }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseJSON(response.text) as ReadingPassage;
};

export const generateWritingPrompt = async (difficulty: Difficulty): Promise<Question> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Generate an IELTS Writing Task 2 prompt. ${getStrictLevelPrompt(difficulty)}.
        Return JSON object { text: "Prompt text", context: "Topic Category" }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseJSON(response.text) as Question;
};

export const evaluateFreeRecall = async (originalText: string, userRecall: string): Promise<FreeRecallResult> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(true),
        contents: `Evaluate the user's free recall of the original text.
        Original: "${originalText}"
        User Recall: "${userRecall}"
        
        Check for key information points retained.
        Return JSON: { score: number (0-100), feedback: "summary", missedPoints: ["point 1", "point 2"] }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseJSON(response.text) as FreeRecallResult;
};

export const generateSpeakingCueCard = async (): Promise<SpeakingCueCard> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Generate an IELTS Speaking Part 2 Cue Card.
        Return JSON: { topic: "Describe...", bulletPoints: ["You should say:", "point 1", "point 2", "and explain..."] }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseJSON(response.text) as SpeakingCueCard;
};

export const evaluateSpeaking = async (topic: string, transcript: string): Promise<Feedback> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(true),
        contents: `Evaluate IELTS Speaking Part 2.
        Topic: "${topic}"
        Transcript: "${transcript}"
        
        Return JSON: {
            "score": number (0-9.0),
            "breakdown": { "vocabulary": number, "grammar": number, "coherence": number, "pronunciation": number },
            "analysis": "feedback",
            "strengths": [],
            "weaknesses": [],
            "betterAlternative": "improved snippet"
        }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseJSON(response.text) as Feedback;
};

export const generateAssessmentTest = async (): Promise<AssessmentQuestion[]> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Generate 10 English assessment questions ranging from A2 to C2 level.
        Format: MCQ.
        Return JSON array of { id, question, options, correctAnswer, difficulty: "EASY"|"MEDIUM"|"HARD" }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseArray(response.text) as AssessmentQuestion[];
};

export const generatePart1Chat = async (history: {role: string, text: string}[]): Promise<{text: string}> => {
    const ai = getGenAI();
    const contents = history.map(h => ({ role: h.role === 'ai' ? 'model' : 'user', parts: [{ text: h.text }] }));
    
    // Add system instruction as part of config in real app, here simplifying by prepending context or assume model knows context
    const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [
            { role: 'user', parts: [{ text: "You are an IELTS Examiner. Conduct a Part 1 interview. Ask one question at a time. Keep it brief." }] },
            ...contents
        ]
    });
    return { text: response.text || "I didn't catch that." };
};

export const generateHeadingMatch = async (difficulty: Difficulty): Promise<HeadingMatchGame> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Generate an IELTS Reading Task: Matching Headings. ${getStrictLevelPrompt(difficulty)}.
        Create 4 paragraphs and 6 possible headings.
        Return JSON: {
            paragraphs: [{id: "A", text: "..."}],
            headings: [{id: "h1", text: "..."}],
            correctMatches: {"A": "h1", "B": "h3", ...}
        }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseJSON(response.text) as HeadingMatchGame;
};

export const generateStyleTransfer = async (input: string): Promise<StyleTransferResult> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Rewrite the following informal sentence into Neutral, Formal, and Academic registers.
        Input: "${input}"
        Return JSON: { neutral: "", formal: "", academic: "", analysis: "Why the changes were made" }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseJSON(response.text) as StyleTransferResult;
};

export const generatePronunciationSentence = async (difficulty: Difficulty): Promise<string> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Generate a single challenging sentence for pronunciation practice. ${getStrictLevelPrompt(difficulty)}.
        Focus on intonation, stress, or connected speech.
        Return just the sentence text.`,
    });
    return response.text || "The quick brown fox jumps over the lazy dog.";
};

export const evaluatePronunciation = async (sentence: string, transcript: string): Promise<PronunciationResult> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `You are an IELTS pronunciation examiner. Compare the student's spoken transcript against the target sentence and evaluate their pronunciation accuracy.

Target sentence: "${sentence}"
Student's speech (transcript): "${transcript}"

Analyze word by word. For each word, determine if it was pronounced correctly (present and recognizable in transcript). Common issues: omitted words, substituted sounds, stress errors.

Return ONLY valid JSON:
{
  "score": <0-100 based on accuracy>,
  "analysis": "<2-3 sentence examiner feedback on overall pronunciation quality, fluency, and key issues>",
  "words": [
    {"word": "<each word from target>", "isCorrect": <true/false>, "errorType": "<if wrong: omitted/substituted/mispronounced>", "correction": "<phonetic hint or correct pronunciation if wrong>"}
  ]
}`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseJSON(response.text) as PronunciationResult;
};

export const evaluateSynapticBridge = async (question: SynapticBridgeQuestion, input: string): Promise<SynapticFeedback> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Evaluate Synaptic Bridge answer.
        Target Word: ${question.anchorWord}
        Constraint: ${question.constraint || 'None'}
        User Input: "${input}"
        
        Did they use the word correctly and improve the sentence structure?
        Return JSON: { score: number, isCorrect: boolean, activated: boolean, analysis: string, improvement: string, synapseLevelUp: boolean }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseJSON(response.text) as SynapticFeedback;
};

export const evaluateEcho = async (question: EchoQuestion, definition: string): Promise<EchoFeedback> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Evaluate Lexical Echo definition.
        Word: ${question.word}
        True Definition: ${question.fullDefinition}
        User Definition: "${definition}"
        Key Anchors: ${JSON.stringify(question.keyAnchors)}
        
        Return JSON: { score: number, semanticAccuracy: number, matchedAnchors: [], missedAnchors: [], analysis: string, refinedDefinition: string }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseJSON(response.text) as EchoFeedback;
};

export const generateMockExamContent = async (difficulty: Difficulty): Promise<any> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `Generate a FULL mock exam content bundle.
        Level: ${difficulty}.
        Include:
        1. Listening: 4 Sections. Scripts + Questions (MCQ/GapFill).
        2. Reading: 3 Passages. Texts + Questions.
        3. Writing: Task 1 (Data description) + Task 2 (Essay).
        4. Speaking: Part 1, 2, 3 Topics.
        
        Return a large JSON structure containing all these parts.
        Structure:
        {
          listening: [{ section: 1, script: "...", questions: [{id, text, type, options, correctAnswer}] }, ...],
          reading: [{ section: 1, title, text, questions: [...] }, ...],
          writingTask1: { prompt, data: [{name, value}], chartType },
          writingTask2: { text },
          speaking: { part1: ["q1", "q2"], part2Topic, part3: ["q1"] }
        }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseJSON(response.text);
};

export const generateListeningSection = async (difficulty: Difficulty, section: number): Promise<any> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Generate IELTS Listening Section ${section}. ${getStrictLevelPrompt(difficulty)}.
        Return JSON: { 
            context: "Situation description",
            script: "Full dialogue/monologue script...",
            questions: [{id, text, options: ["A","B","C"], correctAnswer: "A"}]
        }`,
        config: { responseMimeType: "application/json" }
    });
    return safeParseJSON(response.text);
};

export const formatMathExpression = async (input: string): Promise<string> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: getModel(),
        contents: `Format the following math input into a clean string representation (e.g. LaTeX or readable text): "${input}"`,
    });
    return response.text?.trim() || input;
};

export const solveMathProblem = async (input: string): Promise<string> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `Solve this math problem step-by-step. Show the final answer clearly.
        Problem: "${input}"`,
    });
    return response.text || "Could not solve.";
};

export const recognizeHandwrittenMath = async (base64Image: string): Promise<string> => {
    const ai = getGenAI();
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
            parts: [
                { text: "Recognize the mathematical expression in this image. Return just the expression string." },
                { inlineData: { mimeType: 'image/png', data: base64Image } }
            ]
        }
    });
    return response.text?.trim() || "";
};

// ── Procedural sound engine — no audio files needed ──────────────────────────
// All sounds are synthesized via Web Audio API

let ctx: AudioContext | null = null;
let _muted = false;
export const setSoundMuted = (m: boolean) => { _muted = m; };
export const getSoundMuted = () => _muted;

function getCtx(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!ctx) {
    try { ctx = new (window.AudioContext || (window as any).webkitAudioContext)(); } catch { return null; }
  }
  // Resume if suspended (browser autoplay policy)
  if (ctx.state === 'suspended') ctx.resume();
  return ctx;
}

function play(
  type: OscillatorType,
  freq: number,
  duration: number,
  volume = 0.18,
  detune = 0,
  rampDown = true,
) {
  if (_muted) return;
  const c = getCtx();
  if (!c) return;
  const osc = c.createOscillator();
  const gain = c.createGain();
  osc.connect(gain);
  gain.connect(c.destination);
  osc.type = type;
  osc.frequency.setValueAtTime(freq, c.currentTime);
  if (detune) osc.detune.setValueAtTime(detune, c.currentTime);
  gain.gain.setValueAtTime(volume, c.currentTime);
  if (rampDown) gain.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + duration);
  osc.start(c.currentTime);
  osc.stop(c.currentTime + duration);
}

function chord(notes: number[], duration: number, vol = 0.12) {
  notes.forEach(f => play('sine', f, duration, vol));
}

export const sfx = {
  /** Short soft click — button press */
  click() { play('sine', 600, 0.06, 0.12); },

  /** Lighter hover tick */
  hover() { play('sine', 900, 0.04, 0.05); },

  /** Menu card select — punchy thud */
  select() {
    play('triangle', 180, 0.12, 0.22);
    play('sine', 440, 0.08, 0.1);
  },

  /** Correct answer / success */
  correct() {
    play('sine', 523, 0.08, 0.15);
    setTimeout(() => play('sine', 659, 0.08, 0.15), 80);
    setTimeout(() => play('sine', 784, 0.12, 0.2), 160);
  },

  /** Wrong answer */
  wrong() {
    play('sawtooth', 220, 0.06, 0.18);
    setTimeout(() => play('sawtooth', 180, 0.1, 0.18), 60);
  },

  /** Mode switch / navigation — swoosh up */
  navigate() {
    play('sine', 320, 0.05, 0.1);
    setTimeout(() => play('sine', 480, 0.05, 0.1), 50);
    setTimeout(() => play('sine', 640, 0.06, 0.12), 100);
  },

  /** Completion fanfare */
  complete() {
    chord([523, 659, 784], 0.15, 0.1);
    setTimeout(() => chord([659, 784, 988], 0.15, 0.1), 150);
    setTimeout(() => chord([784, 988, 1175], 0.3, 0.14), 300);
  },

  /** Profile open — game-boot blip */
  profileOpen() {
    play('square', 200, 0.04, 0.1);
    setTimeout(() => play('square', 400, 0.04, 0.1), 50);
    setTimeout(() => play('square', 600, 0.06, 0.12), 100);
  },

  /** XP gain — coin-like ping */
  xp() {
    play('sine', 1046, 0.06, 0.1, 0);
    setTimeout(() => play('sine', 1318, 0.08, 0.15), 70);
  },

  /** Back / close */
  back() {
    play('sine', 400, 0.05, 0.08);
    setTimeout(() => play('sine', 280, 0.05, 0.1), 50);
  },
};

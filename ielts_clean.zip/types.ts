
export enum GameState {
  MENU = 'MENU',
  PLAYING = 'PLAYING',
  LOADING = 'LOADING',
  RESULT = 'RESULT',
  ERROR = 'ERROR'
}

export type Language = 'EN' | 'MN';

export enum GameMode {
  PARAPHRASE = 'PARAPHRASE',
  VOCABULARY = 'VOCABULARY',
  WRITING = 'WRITING',
  READING = 'READING',
  SPEAKING = 'SPEAKING',
  LISTENING = 'LISTENING',
  PRONUNCIATION = 'PRONUNCIATION',
  COLLOCATION = 'COLLOCATION',
  SYNONYM = 'SYNONYM',
  ANTONYM = 'ANTONYM',
  IDIOM = 'IDIOM',
  DICTATION = 'DICTATION',
  TONE = 'TONE',
  MAP = 'MAP',
  DICTIONARY = 'DICTIONARY',
  HEADING_MATCH = 'HEADING_MATCH',
  STYLE_TRANSFER = 'STYLE_TRANSFER',
  SYNAPTIC_BRIDGE = 'SYNAPTIC_BRIDGE',
  LEXICAL_ECHO = 'LEXICAL_ECHO',
  MOCK_EXAM = 'MOCK_EXAM',
  SAT_DASHBOARD = 'SAT_DASHBOARD',
  SAT_WHITEBOARD = 'SAT_WHITEBOARD',
  SAT_CALCULATOR = 'SAT_CALCULATOR'
}

export enum Difficulty {
  FOUNDATION = 'Band 1.0-4.0',
  EASY = 'Band 4.5-6.0',
  MEDIUM = 'Band 6.5-7.5',
  HARD = 'Band 8.0-9.0'
}

export enum ReadingTopic {
  SCIENCE = 'Science & Nature',
  HISTORY = 'History & Archaeology',
  TECHNOLOGY = 'Technology & Future',
  SOCIETY = 'Society & Psychology',
  ENVIRONMENT = 'Environment & Ecology',
  ART = 'Art & Culture'
}

export type SubscriptionPlan = 'free' | 'pro' | 'elite';

export interface UserProfile {
  name: string;
  targetBand: string;
  avatar: string;
  proficiencyLevel: Difficulty;
  synapseLevels?: Record<string, number>;
  tutorialsSeen?: string[];
  plan?: SubscriptionPlan;
  activeBanner?: string;
  unlockedBanners?: string[];
  school?: string;
  friendCode?: string;
  customBannerUrl?: string;
  darkMode?: boolean;
  title?: 'owner' | 'manager' | 'verified' | 'student';
}

export interface AssessmentQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: string;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD';
}

export interface Question {
  text: string;
  context: string; 
  targetVocabulary?: string[];
}

export interface SynapticBridgeQuestion {
    id: string;
    simpleSentence: string;
    anchorWord: string;
    definition: string;
    constraint?: string;
    targetCollocation?: string;
}

export interface SynapticFeedback {
    score: number;
    isCorrect: boolean;
    activated: boolean;
    analysis: string;
    improvement: string;
    synapseLevelUp: boolean;
}

export interface EchoQuestion {
    id: string;
    word: string;
    context: string;
    fullDefinition: string;
    keyAnchors: string[];
    phonetic?: string;
}

export interface EchoFeedback {
    score: number;
    semanticAccuracy: number;
    matchedAnchors: string[];
    missedAnchors: string[];
    analysis: string;
    refinedDefinition: string;
}

export interface VocabOption {
  word: string;
  definition: string;
  example: string;
}

export interface VocabQuestion {
  id: string;
  word: string;
  definition: string; 
  contextSentence: string; 
  options: VocabOption[]; 
  correctAnswer: string;
  synonyms: string[];
  band: string;
  questionType?: 'DEFINITION' | 'SENTENCE' | 'SPELLING'; 
}

export interface CollocationQuestion {
    id: string;
    stem: string; 
    options: string[]; 
    correctAnswer: string;
    explanation: string;
}

export interface WordRelationQuestion {
    id: string;
    target: string;
    options: string[];
    correctAnswer: string;
    type: 'SYNONYM' | 'ANTONYM';
    variant: 'MCQ' | 'BINARY' | 'MATCH';
    secondWord?: string;
    pairs?: { a: string; b: string }[];
    explanation?: string;
}

export interface IdiomQuestion {
    id: string;
    sentence: string; 
    missingWord: string; 
    options: string[]; 
    meaning: string;
    variant: 'MCQ' | 'BINARY' | 'MATCH';
    targetIdiom?: string;
    pairs?: { a: string; b: string }[];
    correctAnswer?: string;
}

export interface DictationQuestion {
    id: string;
    sentence: string;
    focusWords: string[]; 
}

export interface ToneQuestion {
    id: string;
    casualSentence: string;
    options: string[]; 
    correctAnswer: string; 
    explanation: string;
}

export interface MapQuestion {
    id: string;
    mapSvg: string; 
    audioScript: string; 
    correctLocationId: string; 
    options: string[]; 
}

export interface InlineFeedback {
  text: string;
  type: 'strength' | 'weakness' | 'improvement';
  explanation: string;
}

export interface Feedback {
  score: number; 
  breakdown: {
    grammar: number;
    vocabulary: number;
    meaning?: number;       
    taskResponse?: number;  
    coherence?: number;     
  };
  analysis: string;
  strengths: string[];
  weaknesses: string[];
  betterAlternative: string;
  vocabularyUsed: string[];
  inlineFeedback?: InlineFeedback[];
}

export interface ReadingQuestion {
    id: string;
    text: string;
    options: string[];
    correctAnswer: string;
}

export interface ReadingPassage {
    title: string;
    text: string;
    questions: ReadingQuestion[];
    band: string;
    topic?: string;
}

export interface SpeakingCueCard {
    topic: string;
    bulletPoints: string[];
}

export interface HeadingMatchGame {
    paragraphs: { id: string; text: string }[];
    headings: { id: string; text: string }[]; 
    correctMatches: Record<string, string>; 
}

export interface StyleTransferResult {
    neutral: string;
    formal: string;
    academic: string;
    analysis: string;
}

export interface PronunciationResult {
    score: number;
    analysis: string;
    words: {
        word: string;
        isCorrect: boolean;
        errorType?: string;
        correction?: string;
    }[];
}

export interface FeynmanResult {
    isAccurate: boolean;
    simplificationScore: number;
    feedback: string;
    betterExplanation?: string;
}

export interface FreeRecallResult {
    score: number;
    feedback: string;
    missedPoints: string[];
}

export interface SessionStats {
  totalQuestions: number;
  averageScore: number;
  bestScore: number;
  streak: number;
  history: { score: number; timestamp: number }[];
}

export interface DailyChallenge {
  id: string;
  title: string;
  description: string;
  target: number;
  current: number;
  completed: boolean;
  type: 'PLAY_GAME' | 'SAVE_WORD' | 'HIGH_SCORE';
  gameMode?: GameMode;
}

export interface WritingTask1DataPoint {
    name: string;
    value: number;
    value2?: number;
}

export interface WritingTask1Question {
    id: string;
    chartType: 'BAR' | 'LINE' | 'AREA';
    title: string;
    xAxisLabel: string;
    yAxisLabel: string;
    data: WritingTask1DataPoint[];
    prompt: string;
}

import React, { useState, useEffect, useRef } from 'react';
import {
  GameState, GameMode, Difficulty, UserProfile, SessionStats,
  Question, Feedback, VocabQuestion, ReadingPassage, DailyChallenge
} from './types';
import { Menu } from './components/Menu';
import { GameScreen } from './components/GameScreen';
import { ResultScreen } from './components/ResultScreen';
import { VocabGameScreen } from './components/VocabGameScreen';
import { WritingGameScreen } from './components/WritingGameScreen';
import { ReadingGameScreen } from './components/ReadingGameScreen';
import { SpeakingGameScreen } from './components/SpeakingGameScreen';
import { ListeningGameScreen } from './components/ListeningGameScreen';
import { CollocationGameScreen } from './components/CollocationGameScreen';
import { WordRelationGameScreen } from './components/WordRelationGameScreen';
import { IdiomGameScreen } from './components/IdiomGameScreen';
import { DictationGameScreen } from './components/DictationGameScreen';
import { ToneGameScreen } from './components/ToneGameScreen';
import { MapGameScreen } from './components/MapGameScreen';
import { DictionaryScreen } from './components/DictionaryScreen';
import { HeadingMatchScreen } from './components/HeadingMatchScreen';
import { StyleTransferScreen } from './components/StyleTransferScreen';
import { PronunciationGameScreen } from './components/PronunciationGameScreen';
import { SynapticBridgeScreen } from './components/SynapticBridgeScreen';
import { LexicalEchoScreen } from './components/LexicalEchoScreen';
import { MockExamScreen } from './components/MockExamScreen';
import { ProfileDashboard } from './components/ProfileDashboard';
import { AuthScreen } from './components/AuthScreen';
import { LandingPage } from './components/LandingPage';
import { GameSettingsModal } from './components/GameSettingsModal';
import { SATScreen } from './components/SATScreen';
import { WhiteboardCanvas } from './components/WhiteboardCanvas';
import { DesmosCalculator } from './components/DesmosCalculator';
import { AppSidebar } from './components/AppSidebar';
import {
  generateQuestion, evaluateParaphrase, evaluateEssay,
  generateVocabSet, generateCollocationSet, generateWordRelationSet,
  generateIdiomSet, generateDictationSet, generateToneSet,
  generateMapQuestion, generateSynapticBridgeSet, generateEchoSet,
  generateReadingPassage, generateWritingPrompt
} from './services/geminiService';
import { Target, FileText as ContractIcon, X, Check, Loader2, Zap, Trophy, Flame } from 'lucide-react';
import { sfx } from './services/soundService';
import { DevPanel } from './components/DevPanel';
import { GamePreviewModal } from './components/GamePreviewModal';
import { SubscriptionPage } from './components/SubscriptionPage';
import { StaticPage } from './components/StaticPages';
import { SocialHub } from './components/SocialHub';
import { VocabNotebook } from './components/VocabNotebook';

// ─── Page transition wrapper ─────────────────────────────────────────────────
function PageTransition({ children, id }: { children: React.ReactNode; id: string }) {
  const [visible, setVisible] = React.useState(false);
  const prevId = useRef(id);

  useEffect(() => {
    if (prevId.current !== id) {
      setVisible(false);
      const t = setTimeout(() => { setVisible(true); prevId.current = id; }, 80);
      return () => clearTimeout(t);
    } else {
      const t = setTimeout(() => setVisible(true), 20);
      return () => clearTimeout(t);
    }
  }, [id]);

  return (
    <div
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(8px)',
        transition: 'opacity 0.3s ease, transform 0.3s ease',
      }}
    >
      {children}
    </div>
  );
}
// ─────────────────────────────────────────────────────────────────────────────

const App = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.MENU);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [authMode, setAuthMode] = useState<'LOGIN' | 'SIGNUP' | 'ASSESSMENT' | null>(null);

  const [gameMode, setGameMode] = useState<GameMode>(GameMode.PARAPHRASE);
  const [difficulty, setDifficulty] = useState<Difficulty>(Difficulty.MEDIUM);
  const [topic, setTopic] = useState<string>('');

  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [vocabSet, setVocabSet] = useState<VocabQuestion[]>([]);
  const [readingPassage, setReadingPassage] = useState<ReadingPassage | null>(null);
  const [collocationSet, setCollocationSet] = useState<any[]>([]);
  const [wordRelationSet, setWordRelationSet] = useState<any[]>([]);
  const [idiomSet, setIdiomSet] = useState<any[]>([]);
  const [dictationSet, setDictationSet] = useState<any[]>([]);
  const [toneSet, setToneSet] = useState<any[]>([]);
  const [mapQuestions, setMapQuestions] = useState<any[]>([]);
  const [synapticQuestions, setSynapticQuestions] = useState<any[]>([]);
  const [echoQuestions, setEchoQuestions] = useState<any[]>([]);

  const [isEvaluating, setIsEvaluating] = useState(false);
  const [showProfileDashboard, setShowProfileDashboard] = useState(false);
  const [showDictionary, setShowDictionary] = useState(false);
  const [showSubscriptions, setShowSubscriptions] = useState(false);
  const [showSocial, setShowSocial] = useState(false);
  const [showVocabNotebook, setShowVocabNotebook] = useState(false);
  const [staticPage, setStaticPage] = useState<'about'|'privacy'|'terms'|'cookies'|'support'|null>(null);
  const [pendingGame, setPendingGame] = useState<import('./types').GameMode|null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [showMissions, setShowMissions] = useState(false);

  const [stats] = useState<SessionStats>({
    totalQuestions: 0, averageScore: 0, bestScore: 0, streak: 0, history: []
  });
  const [dailyChallenges] = useState<DailyChallenge[]>([
    { id: '1', title: 'Lexical Range', description: 'Master 10 definitions in Echo mode.', target: 10, current: 4, completed: false, type: 'PLAY_GAME' },
    { id: '2', title: 'Speed Reader', description: 'Complete 3 speed reading tests.', target: 3, current: 1, completed: false, type: 'PLAY_GAME' },
    { id: '3', title: 'Task Master', description: 'Write a full Task 2 essay.', target: 1, current: 0, completed: false, type: 'PLAY_GAME' }
  ]);

  useEffect(() => {
    const stored = localStorage.getItem('ielts_user_profile');
    if (stored) {
      const parsed = JSON.parse(stored);
      setUserProfile(parsed);
      setDifficulty(parsed.proficiencyLevel || Difficulty.MEDIUM);
    }
  }, []);

  // Apply dark mode to html element
  useEffect(() => {
    if (userProfile?.darkMode) {
      document.documentElement.classList.add('dark');
      document.documentElement.style.colorScheme = 'dark';
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.style.colorScheme = 'light';
    }
  }, [userProfile?.darkMode]);

  const handleStartGame = async (mode: GameMode, diff: Difficulty, selectedTopic?: string) => {
    sfx.navigate();
    setGameMode(mode);
    setDifficulty(diff);
    if (selectedTopic) setTopic(selectedTopic);
    if (mode === GameMode.SAT_DASHBOARD) { setGameState(GameState.PLAYING); return; }
    setGameState(GameState.LOADING);
    try {
      if (mode === GameMode.PARAPHRASE) { setCurrentQuestion(await generateQuestion(diff)); }
      else if (mode === GameMode.WRITING) { setCurrentQuestion(await generateWritingPrompt(diff)); }
      else if (mode === GameMode.VOCABULARY) { setVocabSet(await generateVocabSet(diff)); }
      else if (mode === GameMode.READING) { setReadingPassage(await generateReadingPassage(diff, selectedTopic)); }
      else if (mode === GameMode.COLLOCATION) { setCollocationSet(await generateCollocationSet(diff)); }
      else if (mode === GameMode.SYNONYM || mode === GameMode.ANTONYM) { setWordRelationSet(await generateWordRelationSet(mode === GameMode.SYNONYM ? 'SYNONYM' : 'ANTONYM', diff)); }
      else if (mode === GameMode.IDIOM) { setIdiomSet(await generateIdiomSet(diff)); }
      else if (mode === GameMode.DICTATION) { setDictationSet(await generateDictationSet(diff)); }
      else if (mode === GameMode.TONE) { setToneSet(await generateToneSet(diff)); }
      else if (mode === GameMode.MAP) { setMapQuestions([await generateMapQuestion(diff)]); }
      else if (mode === GameMode.SYNAPTIC_BRIDGE) { setSynapticQuestions(await generateSynapticBridgeSet(diff)); }
      else if (mode === GameMode.LEXICAL_ECHO) { setEchoQuestions(await generateEchoSet(diff)); }
      setGameState(GameState.PLAYING);
    } catch (error) {
      console.error(error);
      setGameState(GameState.ERROR);
    }
  };

  const handleAuthComplete = (profile: UserProfile) => {
    setUserProfile(profile);
    setDifficulty(profile.proficiencyLevel);
    localStorage.setItem('ielts_user_profile', JSON.stringify(profile));
    setGameState(GameState.MENU);
    setAuthMode(null);
  };

  const handleDifficultyChange = (newDiff: Difficulty) => {
    setDifficulty(newDiff);
    if (userProfile) {
      const updated = { ...userProfile, proficiencyLevel: newDiff };
      setUserProfile(updated);
      localStorage.setItem('ielts_user_profile', JSON.stringify(updated));
    }
  };

  const handleUpgrade = (plan: import('./types').SubscriptionPlan) => {
    if (userProfile) {
      const updated = { ...userProfile, plan };
      setUserProfile(updated);
      localStorage.setItem('ielts_user_profile', JSON.stringify(updated));
    }
    setShowSubscriptions(false);
  };



  const isSATMode = gameMode === GameMode.SAT_DASHBOARD || gameMode === GameMode.SAT_WHITEBOARD || gameMode === GameMode.SAT_CALCULATOR;

  // Derive a stable key for the page transition based on what's showing
  const transitionKey = isSATMode ? `sat-${gameMode}` : `${gameState}-${gameMode}`;

  // ── Tasks Drawer ───────────────────────────────────────────────────────────
  const TasksDrawer = () => {
    const completed = dailyChallenges.filter(ch=>ch.completed).length;
    const total = dailyChallenges.length;
    const pct = Math.round((completed/total)*100);
    const xpToday = dailyChallenges.filter(ch=>ch.completed).length * 50;

    const TASK_ICONS = ['📖','🎧','✍️','🗣️','⚡'];
    const TASK_COLORS = ['bg-cyan-400','bg-rose-500','bg-fuchsia-500','bg-amber-400','bg-lime-400'];

    return (
      <>
        {showMissions && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60]" onClick={() => setShowMissions(false)} />
        )}
        <div className={`fixed inset-y-0 right-0 w-full md:w-[400px] z-[70] transform transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] ${showMissions ? 'translate-x-0' : 'translate-x-full'} flex flex-col`}
          style={{ fontFamily:"'Inter',sans-serif", background:'#fafaf9', borderLeft:'4px solid #1c1917', boxShadow: showMissions ? '-8px 0 0 0 rgba(0,0,0,1)' : 'none' }}>

          {/* Header */}
          <div className="bg-white border-b-4 border-black px-5 pt-5 pb-0 shrink-0">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-amber-400 border-4 border-black rounded-xl flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
                  <Zap className="w-4 h-4 text-black" strokeWidth={2.5} />
                </div>
                <div>
                  <h2 className="font-black text-stone-900 text-base uppercase tracking-tight leading-none">Daily Tasks</h2>
                  <p className="text-stone-400 text-[10px] font-medium mt-0.5">Resets at midnight · {xpToday} XP earned</p>
                </div>
              </div>
              <button onClick={() => { sfx.back(); setShowMissions(false); }}
                className="w-8 h-8 bg-stone-100 hover:bg-stone-200 border-2 border-stone-200 hover:border-stone-400 rounded-xl flex items-center justify-center text-stone-500 hover:text-stone-900 transition-all">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Progress track — like a game quest tracker */}
            <div className="mb-4">
              <div className="flex justify-between items-center mb-1.5">
                <span className="text-[10px] font-black uppercase tracking-widest text-stone-400">{completed}/{total} completed</span>
                <span className="text-[10px] font-black uppercase tracking-widest text-amber-600">{pct}%</span>
              </div>
              <div className="h-3 bg-stone-100 border-4 border-black rounded-full overflow-hidden shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                <div className="h-full bg-amber-400 rounded-full transition-all duration-700"
                  style={{width:`${pct}%`, boxShadow:'0 0 8px rgba(251,191,36,0.6)'}} />
              </div>
              <div className="flex justify-between mt-1.5">
                {dailyChallenges.map((ch,i) => (
                  <div key={i} className={`w-7 h-7 rounded-full border-4 border-black flex items-center justify-center text-xs shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all ${ch.completed ? 'bg-lime-400' : 'bg-stone-200'}`}>
                    {ch.completed ? <Check className="w-3.5 h-3.5 text-black" strokeWidth={3} /> : <span className="font-black text-stone-500">{i+1}</span>}
                  </div>
                ))}
              </div>
            </div>

            {/* Tab underline for "Today" */}
            <div className="flex">
              <div className="px-1 py-2 border-b-4 border-black">
                <span className="text-xs font-black uppercase tracking-widest text-stone-900">Today</span>
              </div>
            </div>
          </div>

          {/* Task cards */}
          <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
            {dailyChallenges.map((challenge, idx) => {
              const progress = Math.min(100, Math.round((challenge.current / challenge.target) * 100));
              const col = TASK_COLORS[idx % TASK_COLORS.length];
              const done = challenge.completed;
              return (
                <div key={challenge.id}
                  className={`relative border-4 rounded-2xl p-4 transition-all overflow-hidden ${done ? 'border-lime-400 bg-lime-50' : 'border-black bg-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[5px_5px_0px_0px_rgba(0,0,0,1)]'}`}>
                  {done && <div className="absolute inset-0 bg-lime-400/10" />}

                  <div className="relative flex items-start gap-3">
                    {/* Icon badge */}
                    <div className={`w-11 h-11 ${done ? 'bg-lime-400' : col} border-4 border-black rounded-xl flex items-center justify-center flex-shrink-0 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]`}>
                      {done
                        ? <Check className="w-5 h-5 text-black" strokeWidth={3} />
                        : <Zap className="w-5 h-5 text-black" />
                      }
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <h4 className={`font-black text-sm uppercase tracking-tight leading-tight ${done ? 'text-lime-700 line-through decoration-2' : 'text-stone-900'}`}>
                          {challenge.title}
                        </h4>
                        {done && (
                          <span className="text-[9px] font-black uppercase tracking-widest px-2 py-0.5 bg-lime-400 border-2 border-black rounded-lg text-black flex-shrink-0 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                            +50 XP
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-stone-500 font-medium leading-snug mt-0.5 mb-2">{challenge.description}</p>

                      {/* Progress */}
                      <div className="flex items-center gap-2">
                        <div className={`flex-1 h-2 ${done ? 'bg-lime-200' : 'bg-stone-100'} border border-stone-200 rounded-full overflow-hidden`}>
                          <div className={`h-full rounded-full transition-all duration-700 ${done ? 'bg-lime-400' : col}`}
                            style={{width:`${progress}%`, boxShadow: done ? '0 0 6px rgba(74,222,128,0.5)' : undefined}} />
                        </div>
                        <span className={`text-[10px] font-black w-10 text-right ${done ? 'text-lime-600' : 'text-stone-400'}`}>
                          {challenge.current}/{challenge.target}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}

            {/* All done state */}
            {completed === total && (
              <div className="bg-amber-400 border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-center">
                <p className="font-black text-black text-base uppercase tracking-tight mb-1">All Done!</p>
                <p className="text-black/60 text-xs font-medium">Come back tomorrow for new tasks.</p>
              </div>
            )}
          </div>
        </div>
      </>
    );
  };

  return (
    <>
    <div className="flex min-h-screen w-full bg-stone-50 font-sans text-stone-900">

      {/* Sidebar — hidden in SAT whiteboard/calculator sub-screens */}
      {!(gameMode === GameMode.SAT_WHITEBOARD || gameMode === GameMode.SAT_CALCULATOR) && (
        <AppSidebar
          gameState={gameState}
          gameMode={gameMode}
          setGameState={setGameState}
          setGameMode={setGameMode}
          userProfile={userProfile}
          stats={stats}
          setShowMissions={setShowMissions}
          setShowDictionary={setShowDictionary}
          setShowSettings={setShowSettings}
          setShowProfileDashboard={setShowProfileDashboard}
          setShowSubscriptions={setShowSubscriptions}
          setShowSocial={setShowSocial}
        />
      )}

      {/* Main content area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen overflow-x-hidden">

        <TasksDrawer />

        {/* Modals */}
        {showSettings && (
          <GameSettingsModal
            onClose={() => setShowSettings(false)}
            difficulty={difficulty}
            onDifficultyChange={handleDifficultyChange}
            userProfile={userProfile}
            onUpdateProfile={(updates: any) => {
              if (userProfile) {
                const updated = { ...userProfile, ...updates };
                setUserProfile(updated);
                localStorage.setItem('ielts_user_profile', JSON.stringify(updated));
              }
            }}
          />
        )}

        {showProfileDashboard && userProfile && (
          <ProfileDashboard
            userProfile={userProfile}
            onComplete={handleAuthComplete}
            onBack={() => setShowProfileDashboard(false)}
            onStartAssessment={() => { setShowProfileDashboard(false); setAuthMode('ASSESSMENT'); }}
            onEditIdentity={() => { setShowProfileDashboard(false); setAuthMode('SIGNUP'); }}
          />
        )}

        {showDictionary && (
          <div className="fixed inset-0 z-50 bg-white overflow-y-auto">
            <DictionaryScreen
              onBack={() => setShowDictionary(false)}
              onSave={() => {}}
              savedWords={[]}
              onClose={() => setShowDictionary(false)}
              variant="modal"
            />
          </div>
        )}

        {/* Page content with transitions */}
        <PageTransition id={transitionKey}>
          {/* ── MENU ─────────────────────────────────────────────────────── */}
          {gameState === GameState.MENU && userProfile && (
            <Menu
              onStart={(mode, diff, topic) => {
                // SAT and non-game modes skip preview
                if (mode === GameMode.SAT_DASHBOARD || mode === GameMode.MOCK_EXAM || topic) {
                  handleStartGame(mode, diff, topic);
                } else {
                  setPendingGame(mode);
                }
              }}
              onEditProfile={() => setShowProfileDashboard(true)}
              stats={stats}
              userProfile={userProfile}
              lang="EN"
              dailyChallenges={dailyChallenges}
              onOpenSettings={() => setShowSettings(true)}
            />
          )}

          {/* ── LOADING ──────────────────────────────────────────────────── */}
          {gameState === GameState.LOADING && (
            <div className="flex h-screen items-center justify-center flex-col gap-4 bg-stone-50">
              <Loader2 className="w-8 h-8 text-rose-500 animate-spin" />
              <p className="font-black text-sm uppercase tracking-[0.3em] text-stone-400">Generating...</p>
            </div>
          )}

          {/* ── PLAYING ──────────────────────────────────────────────────── */}
          {gameState === GameState.PLAYING && (
            <>
              {/* SAT */}
              {gameMode === GameMode.SAT_DASHBOARD && (
                <SATScreen
                  onBack={() => { setGameMode(GameMode.PARAPHRASE); setGameState(GameState.MENU); }}
                  onStartWhiteboard={() => setGameMode(GameMode.SAT_WHITEBOARD)}
                  onStartCalculator={() => setGameMode(GameMode.SAT_CALCULATOR)}
                />
              )}
              {gameMode === GameMode.SAT_WHITEBOARD && (
                <WhiteboardCanvas onClose={() => setGameMode(GameMode.SAT_DASHBOARD)} />
              )}
              {gameMode === GameMode.SAT_CALCULATOR && (
                <DesmosCalculator onClose={() => setGameMode(GameMode.SAT_DASHBOARD)} />
              )}

              {/* IELTS game modes */}
              {gameMode === GameMode.VOCABULARY && (
                <VocabGameScreen questions={vocabSet} onComplete={() => setGameState(GameState.MENU)} lang="EN" />
              )}
              {gameMode === GameMode.PARAPHRASE && currentQuestion && (
                <GameScreen
                  question={currentQuestion}
                  onSubmit={async (text) => {
                    setIsEvaluating(true);
                    const fb = await evaluateParaphrase(currentQuestion.text, text);
                    setFeedback(fb); setIsEvaluating(false); setGameState(GameState.RESULT);
                  }}
                  onSkip={() => setGameState(GameState.MENU)}
                  isEvaluating={isEvaluating}
                />
              )}
              {gameMode === GameMode.WRITING && currentQuestion && (
                <WritingGameScreen
                  question={currentQuestion}
                  onSubmit={async (text) => {
                    setIsEvaluating(true);
                    const fb = await evaluateEssay(currentQuestion.text, text);
                    setFeedback(fb); setIsEvaluating(false); setGameState(GameState.RESULT);
                  }}
                  isEvaluating={isEvaluating}
                />
              )}
              {gameMode === GameMode.READING && readingPassage && (
                <ReadingGameScreen passage={readingPassage} onComplete={() => setGameState(GameState.MENU)} />
              )}
              {gameMode === GameMode.LISTENING && (
                <ListeningGameScreen difficulty={difficulty} onComplete={() => setGameState(GameState.MENU)} />
              )}
              {gameMode === GameMode.COLLOCATION && (
                <CollocationGameScreen questions={collocationSet} onComplete={() => setGameState(GameState.MENU)} />
              )}
              {(gameMode === GameMode.SYNONYM || gameMode === GameMode.ANTONYM) && (
                <WordRelationGameScreen questions={wordRelationSet} mode={gameMode === GameMode.SYNONYM ? 'SYNONYM' : 'ANTONYM'} onComplete={() => setGameState(GameState.MENU)} />
              )}
              {gameMode === GameMode.IDIOM && (
                <IdiomGameScreen questions={idiomSet} onComplete={() => setGameState(GameState.MENU)} />
              )}
              {gameMode === GameMode.DICTATION && (
                <DictationGameScreen questions={dictationSet} onComplete={() => setGameState(GameState.MENU)} />
              )}
              {gameMode === GameMode.TONE && (
                <ToneGameScreen questions={toneSet} onComplete={() => setGameState(GameState.MENU)} lang="EN" />
              )}
              {gameMode === GameMode.MAP && (
                <MapGameScreen questions={mapQuestions} onComplete={() => setGameState(GameState.MENU)} lang="EN" />
              )}
              {gameMode === GameMode.SYNAPTIC_BRIDGE && (
                <SynapticBridgeScreen questions={synapticQuestions} synapseLevels={userProfile?.synapseLevels || {}} difficulty={difficulty} onComplete={() => setGameState(GameState.MENU)} />
              )}
              {gameMode === GameMode.LEXICAL_ECHO && (
                <LexicalEchoScreen questions={echoQuestions} difficulty={difficulty} onComplete={() => setGameState(GameState.MENU)} />
              )}
              {gameMode === GameMode.SPEAKING && <SpeakingGameScreen />}
              {gameMode === GameMode.HEADING_MATCH && (
                <HeadingMatchScreen difficulty={difficulty} onComplete={() => setGameState(GameState.MENU)} />
              )}
              {gameMode === GameMode.STYLE_TRANSFER && (
                <StyleTransferScreen onBack={() => setGameState(GameState.MENU)} />
              )}
              {gameMode === GameMode.PRONUNCIATION && (
                <PronunciationGameScreen difficulty={difficulty} onComplete={() => setGameState(GameState.MENU)} />
              )}
              {gameMode === GameMode.MOCK_EXAM && (
                <MockExamScreen difficulty={difficulty} onComplete={() => setGameState(GameState.MENU)} />
              )}
            </>
          )}

          {/* ── RESULT ───────────────────────────────────────────────────── */}
          {gameState === GameState.RESULT && feedback && currentQuestion && (
            <ResultScreen
              feedback={feedback}
              originalQuestion={currentQuestion}
              userAnswer=""
              onNext={() => setGameState(GameState.MENU)}
            />
          )}

          {/* ── ERROR ────────────────────────────────────────────────────── */}
          {gameState === GameState.ERROR && (
            <div className="flex h-screen items-center justify-center flex-col gap-6 text-center px-8 bg-stone-50">
              <div className="w-16 h-16 rounded-2xl bg-rose-50 border border-rose-200 flex items-center justify-center">
                <X className="w-8 h-8 text-rose-400" />
              </div>
              <div>
                <h2 className="font-black text-stone-900 text-xl uppercase tracking-tight mb-2">Something went wrong</h2>
                <p className="text-stone-500 text-sm mb-6">There was an error generating content. Check your API key and try again.</p>
              </div>
              <button
                onClick={() => setGameState(GameState.MENU)}
                className="px-6 py-3 bg-rose-500 hover:bg-rose-600 text-white font-black uppercase tracking-widest text-sm rounded-xl transition-colors shadow-sm"
              >
                Back to Dashboard
              </button>
            </div>
          )}
        </PageTransition>

        {/* Footer */}
        {!isSATMode && gameState !== GameState.PLAYING && gameState !== GameState.LOADING && (
          <footer className="mt-auto border-t border-stone-100 py-6 px-6 bg-white">
            <div className="max-w-7xl mx-auto flex justify-between items-center">
              <p className="text-[10px] font-black uppercase tracking-[0.3em] text-stone-400">IELTS MASTER</p>
              <div className="flex gap-4">
                {([['about','About'],['privacy','Privacy'],['terms','Terms'],['support','Support']] as const).map(([p,l]) => (
                  <button key={p} onClick={() => setStaticPage(p)} className="text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 hover:text-stone-900 transition-colors">{l}</button>
                ))}
              </div>
            </div>
          </footer>
        )}
      </div>
    </div>

    <DevPanel
      gameState={gameState}
      gameMode={gameMode}
      userProfile={userProfile}
      setGameState={setGameState}
      setGameMode={setGameMode}
      onAuthMode={(m) => setAuthMode(m)}
      onShowSubscription={() => setShowSubscriptions(true)}
      onShowSocial={() => setShowSocial(true)}
      onSetProfile={(p) => { setUserProfile(p); setDifficulty(p.proficiencyLevel); }}
      onReset={() => { setUserProfile(null); setAuthMode(null); setGameState(GameState.MENU); }}
    />

    {/* ── Fullscreen overlays — outside main div to avoid overflow clipping ── */}
    {showSubscriptions && (
      <SubscriptionPage
        userProfile={userProfile}
        onClose={() => setShowSubscriptions(false)}
        onUpgrade={handleUpgrade}
      />
    )}
    {staticPage && (
      <StaticPage page={staticPage} onClose={() => setStaticPage(null)} />
    )}
    {showSocial && userProfile && (
      <SocialHub userProfile={userProfile} onClose={() => setShowSocial(false)} />
    )}
    {pendingGame !== null && (
      <GamePreviewModal
        mode={pendingGame}
        onStart={() => {
          const m = pendingGame;
          setPendingGame(null);
          handleStartGame(m, difficulty);
        }}
        onClose={() => setPendingGame(null)}
      />
    )}
    </>
  );
};

export default App;

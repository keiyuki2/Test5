
import React, { useState } from 'react';
import { CollocationQuestion } from '../types';
import { ArrowRight, Zap, Check, X, RotateCcw, Link, Award, BarChart3, Loader2 } from 'lucide-react';

interface CollocationGameScreenProps {
  questions: CollocationQuestion[];
  onComplete: () => void;
}

export const CollocationGameScreen: React.FC<CollocationGameScreenProps> = ({ questions, onComplete }) => {
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [hasAnswered, setHasAnswered] = useState(false);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [history, setHistory] = useState<boolean[]>([]);

  const currentQ = questions && questions[index];

  const handleOptionClick = (option: string) => {
    if (hasAnswered || !currentQ) return;
    
    setSelectedOption(option);
    setHasAnswered(true);
    
    const isCorrect = option === currentQ.correctAnswer;
    if (isCorrect) setScore(s => s + 1);
    setHistory(prev => [...prev, isCorrect]);
  };

  const handleNext = () => {
    if (index < questions.length - 1) {
      setIndex(i => i + 1);
      setHasAnswered(false);
      setSelectedOption(null);
    } else {
      onComplete();
    }
  };

  if (!currentQ || index >= questions.length) {
      const percentage = Math.round((score / (Math.max(1, questions?.length || 0))) * 100);
      return (
          <div className="w-full max-w-2xl mx-auto py-12 px-6 animate-slide-up">
              <div className="bg-white rounded-[3rem] border-4 border-black shadow-[16px_16px_0px_0px_rgba(0,0,0,1)] text-center relative overflow-hidden">
                  <div className="bg-cyan-400 p-10 border-b-4 border-black relative">
                      <div className="absolute inset-0 bg-[linear-gradient(45deg,rgba(255,255,255,0.2)_25%,transparent_25%,transparent_50%,rgba(255,255,255,0.2)_50%,rgba(255,255,255,0.2)_75%,transparent_75%,transparent_100%)] bg-[size:40px_40px]"></div>
                      <div className="relative z-10">
                          <div className="w-24 h-24 bg-white text-black rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                              <Zap className="w-12 h-12 fill-current" />
                          </div>
                          <h2 className="text-5xl font-black uppercase tracking-tighter mb-2">Finished!</h2>
                      </div>
                  </div>
                  <div className="p-10">
                      <div className="flex justify-center gap-12 mb-10">
                          <div>
                              <div className="text-xs font-black uppercase tracking-widest text-slate-400 mb-1">Score</div>
                              <div className="text-6xl font-black text-slate-900">{score}/{questions?.length || 0}</div>
                          </div>
                          <div className="w-px bg-slate-200"></div>
                          <div>
                              <div className="text-xs font-black uppercase tracking-widest text-slate-400 mb-1">Accuracy</div>
                              <div className={`text-6xl font-black ${percentage >= 80 ? 'text-emerald-500' : percentage >= 50 ? 'text-amber-500' : 'text-rose-500'}`}>
                                  {percentage}%
                              </div>
                          </div>
                      </div>
                      <button onClick={onComplete} className="w-full py-5 bg-black text-white rounded-2xl font-black text-xl uppercase tracking-wider transition-all flex items-center justify-center gap-2">Go Back</button>
                  </div>
              </div>
          </div>
      );
  }

  return (
    <div className="w-full max-w-[1200px] mx-auto py-8 md:py-12 px-4 md:px-6 animate-slide-up flex flex-col min-h-[calc(100vh-140px)]">
      <div className="flex justify-between items-center mb-8 bg-white p-4 rounded-2xl border-4 border-black shadow-[6px_6px_0px_0px_rgba(0,0,0,1)]">
          <div className="flex items-center gap-3">
              <div className="bg-cyan-400 text-black p-2 rounded-lg border-2 border-black"><Link className="w-6 h-6" /></div>
              <div><p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Score</p><p className="text-2xl font-black leading-none">{score}</p></div>
          </div>
          <div className="text-right">
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Progress</p>
              <p className="text-2xl font-black leading-none text-cyan-600">{index + 1}<span className="text-slate-400 text-lg">/{questions.length}</span></p>
          </div>
      </div>
      <div className="flex-1 flex flex-col justify-center items-center relative w-full">
          <div className="mb-12 text-center w-full max-w-4xl relative z-10 bg-white p-10 rounded-[2rem] border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
              <h2 className="text-2xl md:text-4xl font-black text-slate-900 uppercase tracking-tighter leading-tight">{currentQ.stem || "Loading question..."}</h2>
          </div>
          {!hasAnswered ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 w-full max-w-4xl">
                  {(currentQ.options || []).map((opt) => (
                      <button key={opt} onClick={() => handleOptionClick(opt)} className="min-h-[7rem] rounded-[1.5rem] border-4 bg-white border-black text-black text-2xl font-black uppercase tracking-tighter shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all hover:-translate-y-1 hover:bg-cyan-50">
                          {opt}
                      </button>
                  ))}
              </div>
          ) : (
              <div className="w-full max-w-2xl animate-scale-in">
                  <div className={`p-8 rounded-[2.5rem] border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] text-center ${selectedOption === currentQ.correctAnswer ? 'bg-emerald-100' : 'bg-rose-100'}`}>
                      <h3 className="text-xl font-black uppercase tracking-wider text-slate-900 mb-4">{selectedOption === currentQ.correctAnswer ? "Correct!" : "Incorrect"}</h3>
                      <p className="text-lg font-medium text-slate-800 mb-8">{currentQ.explanation}</p>
                      <button onClick={handleNext} className="w-full py-4 bg-black text-white rounded-xl font-black text-lg uppercase tracking-wider flex items-center justify-center gap-2">Next <ArrowRight className="w-5 h-5" /></button>
                  </div>
              </div>
          )}
      </div>
    </div>
  );
};

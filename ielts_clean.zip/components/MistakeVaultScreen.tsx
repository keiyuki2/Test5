
import React, { useState } from 'react';
import { VaultItem } from '../types';
import { Shield, Lock, Unlock, ArrowLeft, Check, X } from 'lucide-react';

interface MistakeVaultScreenProps {
  items: VaultItem[];
  onReview: (id: string, success: boolean) => void;
  onBack: () => void;
}

export const MistakeVaultScreen: React.FC<MistakeVaultScreenProps> = ({ items, onReview, onBack }) => {
  const dueItems = items.filter(item => item.nextReview <= Date.now());
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isRevealed, setIsRevealed] = useState(false);

  const currentItem = dueItems[currentIndex];

  const handleResult = (success: boolean) => {
      if (!currentItem) return;
      onReview(currentItem.id, success);
      setIsRevealed(false);
      if (currentIndex < dueItems.length - 1) {
          setCurrentIndex(i => i + 1);
      } else {
          // Finished session
          setCurrentIndex(i => i + 1);
      }
  };

  if (dueItems.length === 0 || currentIndex >= dueItems.length) {
      return (
          <div className="w-full h-screen bg-slate-900 text-white flex flex-col items-center justify-center p-6 text-center">
              <Shield className="w-24 h-24 text-emerald-500 mb-6" />
              <h2 className="text-4xl font-black uppercase tracking-tighter mb-4">All Done</h2>
              <p className="text-slate-400 text-lg mb-8">No mistakes to review right now. Great job!</p>
              <button onClick={onBack} className="bg-white text-black px-8 py-3 rounded-xl font-black uppercase tracking-wider hover:scale-105 transition-transform">
                  Go Back
              </button>
          </div>
      );
  }

  return (
    <div className="w-full h-screen bg-slate-900 text-white flex flex-col items-center justify-center p-6 relative">
        <button onClick={onBack} className="absolute top-8 left-8 text-slate-500 hover:text-white font-bold uppercase tracking-widest text-sm flex items-center gap-2">
            <ArrowLeft className="w-5 h-5" /> Exit
        </button>

        <div className="mb-12">
            <div className="w-16 h-16 bg-rose-900/50 rounded-full flex items-center justify-center mx-auto mb-4 border-2 border-rose-500">
                <Lock className="w-8 h-8 text-rose-500" />
            </div>
            <p className="text-rose-500 font-black uppercase tracking-widest text-sm text-center">Reviewing Mistakes</p>
            <p className="text-slate-500 text-xs font-mono text-center mt-1">Reviewing {currentIndex + 1} of {dueItems.length}</p>
        </div>

        <div className="w-full max-w-2xl perspective-1000">
            <div className={`relative w-full bg-slate-800 rounded-[2rem] border-4 border-slate-700 p-12 text-center shadow-[0_0_50px_rgba(0,0,0,0.5)] transition-all duration-500 ${isRevealed ? 'rotate-x-180' : ''}`}>
                 
                 <h2 className="text-4xl md:text-6xl font-black mb-8">{currentItem.question}</h2>
                 
                 {!isRevealed ? (
                     <button 
                        onClick={() => setIsRevealed(true)}
                        className="bg-indigo-600 hover:bg-indigo-500 text-white px-10 py-4 rounded-xl font-black uppercase tracking-widest shadow-lg transition-transform hover:-translate-y-1"
                     >
                         Reveal Answer
                     </button>
                 ) : (
                     <div className="animate-fade-in">
                         <p className="text-xs font-black text-emerald-500 uppercase tracking-widest mb-2">Answer</p>
                         <p className="text-3xl font-bold mb-10 text-emerald-100">{currentItem.correctAnswer}</p>
                         
                         <div className="flex gap-4 justify-center">
                             <button onClick={() => handleResult(false)} className="bg-rose-600 hover:bg-rose-500 p-4 rounded-xl border-b-4 border-rose-800 active:border-b-0 active:translate-y-1 transition-all">
                                 <X className="w-8 h-8" />
                             </button>
                             <button onClick={() => handleResult(true)} className="bg-emerald-600 hover:bg-emerald-500 p-4 rounded-xl border-b-4 border-emerald-800 active:border-b-0 active:translate-y-1 transition-all">
                                 <Check className="w-8 h-8" />
                             </button>
                         </div>
                     </div>
                 )}
            </div>
        </div>
    </div>
  );
};

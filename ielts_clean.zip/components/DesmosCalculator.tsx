import React, { useEffect, useRef, useState } from 'react';
import { Calculator, ChevronLeft } from 'lucide-react';

declare global { interface Window { Desmos?: any } }

interface Props { onClose: () => void }

export const DesmosCalculator: React.FC<Props> = ({ onClose }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const calcRef      = useRef<any>(null);
  const [ready, setReady] = useState(!!window.Desmos);

  useEffect(() => {
    function mount() {
      if (!containerRef.current || calcRef.current) return;
      calcRef.current = window.Desmos!.GraphingCalculator(containerRef.current, {
        keypad: true, expressions: true, settingsMenu: true,
        zoomButtons: true, expressionsCollapsed: false, autosize: true, border: false,
        graphpaper: true, xAxisNumbers: true, yAxisNumbers: true,
      });
      setReady(true);
    }

    if (window.Desmos) {
      mount();
    } else {
      const existing = document.getElementById('desmos-script');
      if (!existing) {
        const s = document.createElement('script');
        s.id  = 'desmos-script';
        s.src = 'https://www.desmos.com/api/v1.9/calculator.js?apiKey=dcb31709b452b1cf9dc26972add0fda6';
        s.onload = () => mount();
        document.head.appendChild(s);
      } else {
        // Script exists but hasn't loaded yet — wait
        existing.addEventListener('load', mount);
      }
    }
    return () => {
      calcRef.current?.destroy();
      calcRef.current = null;
    };
  }, []);

  const SHORTCUTS = [
    { key: 'π', label: 'Pi' }, { key: 'e', label: "Euler's" },
    { key: 'sin(x)', label: 'Sine' }, { key: 'cos(x)', label: 'Cosine' },
    { key: '√x', label: 'Root' }, { key: 'x^2', label: 'Square' },
    { key: 'log(x)', label: 'Log' }, { key: '|x|', label: 'Abs' },
  ];

  const insertExpr = (expr: string) => {
    if (!calcRef.current) return;
    const state = calcRef.current.getState();
    const exprs = state.expressions?.list || [];
    calcRef.current.setExpression({ id: `expr-${Date.now()}`, latex: expr });
  };

  return (
    <div className="fixed inset-0 z-[100] bg-stone-50 flex flex-col" style={{ fontFamily:"'Inter',sans-serif" }}>
      {/* Header */}
      <div className="h-14 bg-white border-b-4 border-black flex items-center justify-between px-4 shrink-0 shadow-[0_4px_0px_0px_rgba(0,0,0,1)]">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-amber-400 border-4 border-black rounded-xl flex items-center justify-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
            <Calculator className="w-4 h-4 text-black" />
          </div>
          <div>
            <p className="font-black text-stone-900 text-sm uppercase tracking-tight leading-none">Graphing Calculator</p>
            <p className="text-[10px] text-emerald-600 font-black uppercase tracking-widest">Powered by Desmos · SAT Approved</p>
          </div>
        </div>
        <button onClick={onClose}
          className="flex items-center gap-2 px-4 py-2 bg-stone-100 border-4 border-stone-300 rounded-xl font-black text-xs uppercase tracking-widest text-stone-700 hover:border-black hover:text-stone-900 transition-all shadow-[2px_2px_0px_0px_rgba(0,0,0,0.3)]">
          <ChevronLeft className="w-4 h-4" /> Back
        </button>
      </div>

      {/* Quick-insert shortcuts */}
      <div className="bg-white border-b-2 border-stone-100 px-4 py-2 flex gap-2 flex-wrap shrink-0">
        {SHORTCUTS.map(s => (
          <button key={s.key} onClick={() => insertExpr(s.key)}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-stone-50 border-2 border-stone-200 rounded-lg hover:border-black hover:bg-stone-100 transition-all">
            <kbd className="font-mono text-xs font-bold text-stone-800">{s.key}</kbd>
            <span className="text-[9px] text-stone-400 font-medium uppercase tracking-widest">{s.label}</span>
          </button>
        ))}
      </div>

      {/* Desmos mount */}
      <div ref={containerRef} className="flex-1 w-full" style={{ minHeight: 0 }} />

      {/* Loading overlay */}
      {!ready && (
        <div className="absolute inset-0 top-14 flex flex-col items-center justify-center bg-stone-50 gap-4">
          <div className="w-12 h-12 bg-amber-400 border-4 border-black rounded-2xl flex items-center justify-center shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] animate-bounce">
            <Calculator className="w-6 h-6 text-black" />
          </div>
          <p className="font-black text-sm uppercase tracking-widest text-stone-400">Loading Desmos...</p>
          <p className="text-xs text-stone-300 font-medium">Requires internet connection</p>
        </div>
      )}
    </div>
  );
};

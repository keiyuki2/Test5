
import React, { useState, useEffect, useRef } from 'react';
import { generateMockExamContent } from '../services/geminiService';
import { Difficulty } from '../types';
import { Clock, Play, Pause, FileText, Mic, Volume2, ArrowRight, Headphones, Award, BarChart3, CheckCircle, AlertTriangle, Eye, Lock, RefreshCw, X, Radio, Activity, Zap } from 'lucide-react';
import { 
  BarChart, Bar, LineChart, Line, AreaChart, Area, 
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from 'recharts';

interface MockExamScreenProps {
  difficulty: Difficulty;
  onComplete: () => void;
}

type ExamPhase = 'INTRO' | 'LISTENING' | 'READING' | 'WRITING' | 'SPEAKING' | 'RESULT';

export const MockExamScreen: React.FC<MockExamScreenProps> = ({ difficulty, onComplete }) => {
  const [phase, setPhase] = useState<ExamPhase>('INTRO');
  const [content, setContent] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [timeLeft, setTimeLeft] = useState(0);
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [hasPlayedAudio, setHasPlayedAudio] = useState<boolean[]>([]); 
  
  const [listeningSectionIndex, setListeningSectionIndex] = useState(0);
  const [readingSectionIndex, setReadingSectionIndex] = useState(0);
  const [speakingPart, setSpeakingPart] = useState<1 | 2 | 3>(1);

  const [listeningAnswers, setListeningAnswers] = useState<Record<string, string>>({});
  const [readingAnswers, setReadingAnswers] = useState<Record<string, string>>({});
  const [writingAnswers, setWritingAnswers] = useState({ task1: '', task2: '' });

  const [transcript, setTranscript] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const recognitionRef = useRef<any>(null);

  const [finalScores, setFinalScores] = useState<{L: number, R: number, W: number, S: number, Overall: number} | null>(null);

  useEffect(() => {
      const load = async () => {
          setLoading(true);
          try {
              const data = await generateMockExamContent(difficulty);
              setContent(data);
              setHasPlayedAudio(new Array(4).fill(false));
          } catch (e) {
              console.error(e);
          } finally {
              setLoading(false);
          }
      };
      load();
  }, [difficulty]);

  useEffect(() => {
      if ('webkitSpeechRecognition' in window) {
          const SpeechRecognition = (window as any).webkitSpeechRecognition;
          recognitionRef.current = new SpeechRecognition();
          recognitionRef.current.continuous = true;
          recognitionRef.current.interimResults = true;

          recognitionRef.current.onresult = (event: any) => {
              if (!event?.results) return;
              let currentTranscript = '';
              for (let i = 0; i < event.results.length; ++i) {
                  currentTranscript += event.results[i][0].transcript;
              }
              setTranscript(currentTranscript);
          };
      }
  }, []);

  useEffect(() => {
      let interval: any;
      if (phase !== 'INTRO' && phase !== 'RESULT' && timeLeft > 0) {
          interval = setInterval(() => {
              setTimeLeft(t => t - 1);
          }, 1000);
      } else if (timeLeft === 0 && phase !== 'INTRO' && phase !== 'RESULT') {
          handleNextPhase();
      }
      return () => clearInterval(interval);
  }, [timeLeft, phase]);

  const startExam = () => {
      setPhase('LISTENING');
      setListeningSectionIndex(0);
      setTimeLeft(30 * 60); 
  };

  const playScript = () => {
      if (hasPlayedAudio[listeningSectionIndex]) return;
      if (isPlaying) {
          window.speechSynthesis.cancel();
          setIsPlaying(false);
      } else {
          let script = "Audio script currently unavailable.";
          if (content?.listening?.[listeningSectionIndex]) {
              script = content.listening[listeningSectionIndex].script;
          }
          const u = new SpeechSynthesisUtterance(script);
          u.lang = 'en-GB';
          u.rate = 0.9;
          u.onstart = () => setIsPlaying(true);
          u.onend = () => {
              setIsPlaying(false);
              const newPlayed = [...hasPlayedAudio];
              newPlayed[listeningSectionIndex] = true;
              setHasPlayedAudio(newPlayed);
          };
          window.speechSynthesis.speak(u);
      }
  };

  const toggleRecording = () => {
      if (isRecording) {
          recognitionRef.current?.stop();
          setIsRecording(false);
      } else {
          recognitionRef.current?.start();
          setIsRecording(true);
      }
  };

  const handleNextListeningSection = () => {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
      if (listeningSectionIndex < 3) setListeningSectionIndex(prev => prev + 1);
      else handleNextPhase();
  };

  const handleNextPhase = () => {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
      if (isRecording) {
          recognitionRef.current?.stop();
          setIsRecording(false);
      }
      if (phase === 'LISTENING') { setPhase('READING'); setTimeLeft(60 * 60); }
      else if (phase === 'READING') { setPhase('WRITING'); setTimeLeft(60 * 60); }
      else if (phase === 'WRITING') { setPhase('SPEAKING'); setSpeakingPart(1); setTimeLeft(15 * 60); }
      else if (phase === 'SPEAKING') { calculateScores(); setPhase('RESULT'); }
  };

  const calculateScores = () => {
      let lCorrect = 0;
      content?.listening?.forEach((section: any) => {
          section.questions?.forEach((q: any) => {
              if (listeningAnswers[q.id]?.toLowerCase().trim() === q.correctAnswer?.toLowerCase().trim()) lCorrect++;
          });
      });
      const lScore = Math.round((lCorrect / 40) * 9 * 2) / 2;

      let rCorrect = 0;
      content?.reading?.forEach((section: any) => {
          section.questions?.forEach((q: any) => {
              const uAns = readingAnswers[q.id]?.toLowerCase().trim();
              const cAns = q.correctAnswer?.toLowerCase().trim();
              if (uAns === cAns) rCorrect++;
          });
      });
      const rScore = Math.round((rCorrect / 40) * 9 * 2) / 2;

      const t1Len = writingAnswers.task1.trim().split(/\s+/).filter(Boolean).length;
      const t2Len = writingAnswers.task2.trim().split(/\s+/).filter(Boolean).length;
      let wScore = t1Len > 100 && t2Len > 200 ? 6.5 : (t1Len > 0 || t2Len > 0 ? 3.0 : 0);

      const speechLen = transcript.trim().split(/\s+/).filter(Boolean).length;
      let sScore = speechLen > 150 ? 7.0 : (speechLen > 10 ? 3.0 : 0);

      const overall = Math.round((lScore + rScore + wScore + sScore) / 4 * 2) / 2;
      setFinalScores({ L: lScore, R: rScore, W: wScore, S: sScore, Overall: overall });
  };

  const formatTime = (s: number) => {
      const h = Math.floor(s / 3600);
      const m = Math.floor((s % 3600) / 60);
      const sec = s % 60;
      return `${h}:${m < 10 ? '0' : ''}${m}:${sec < 10 ? '0' : ''}${sec}`;
  };

  const renderTask1Chart = (task: any) => {
    if (!task?.data || !Array.isArray(task.data) || task.data.length === 0) return <div className="h-64 bg-slate-100 flex items-center justify-center">No Chart Data</div>;
    return (
        <div className="h-80 w-full mb-8 mt-6 bg-white p-4 rounded-xl border border-slate-100">
            <ResponsiveContainer width="100%" height="100%">
                <BarChart data={task.data} margin={{top: 20, right: 30, left: 0, bottom: 20}}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="value" fill="#4f46e5" radius={[4, 4, 0, 0]} />
                </BarChart>
            </ResponsiveContainer>
        </div>
    );
  };

  if (loading) return <div className="fixed inset-0 flex items-center justify-center font-black uppercase tracking-widest text-slate-400 gap-4"><div className="w-8 h-8 border-4 border-slate-300 border-t-indigo-600 rounded-full animate-spin"></div>Loading...</div>;
  if (phase === 'INTRO') return <div className="fixed inset-0 flex items-center justify-center p-8"><div className="max-w-2xl w-full bg-white border-4 border-black rounded-[2rem] p-12 text-center shadow-[16px_16px_0px_0px_rgba(0,0,0,1)]"><h1 className="text-6xl font-black mb-8">Exam</h1><button onClick={startExam} className="w-full bg-black text-white py-4 rounded-xl font-black uppercase hover:bg-indigo-600">Start</button></div></div>;
  if (phase === 'RESULT') return <div className="fixed inset-0 bg-[#0f172a] text-white flex flex-col items-center justify-center"><h1 className="text-7xl font-black mb-8">Score: {finalScores?.Overall}</h1><button onClick={onComplete} className="bg-white text-black px-12 py-6 text-2xl font-black uppercase border-8 border-black">Exit</button></div>;

  return (
      <div className="fixed inset-0 bg-slate-50 flex flex-col font-sans">
          <div className="h-16 bg-white border-b-4 border-black flex items-center justify-between px-6 z-20">
              <div className="font-black text-xs uppercase tracking-widest">{phase} Section {phase === 'SPEAKING' ? speakingPart : phase === 'READING' ? readingSectionIndex + 1 : listeningSectionIndex + 1}</div>
              <div className="font-mono text-xl font-black">{formatTime(timeLeft)}</div>
          </div>
          <div className="flex-1 overflow-y-auto p-10 custom-scrollbar">
              <div className="max-w-6xl mx-auto">
                  {phase === 'LISTENING' && content?.listening?.[listeningSectionIndex] && (
                      <div className="bg-white rounded-[2rem] border-4 border-black overflow-hidden">
                          <div className="bg-slate-100 p-6 border-b-4 border-black flex justify-between items-center"><h3 className="font-black text-2xl uppercase">Part {listeningSectionIndex + 1}</h3><button onClick={playScript} className="px-6 py-3 rounded-xl bg-emerald-400 font-black border-2 border-black">Listen</button></div>
                          <div className="p-12 space-y-8">{content.listening[listeningSectionIndex].questions?.map((q: any, i: number) => (
                              <div key={q.id} className="p-4 border-2 border-slate-200 rounded-xl bg-slate-50/50"><p className="font-bold mb-3">{i + 1}. {q.text}</p><div className="pl-11">{q.type === 'GAP_FILL' ? <input type="text" className="w-full max-w-md p-3 border-2 rounded-lg" onChange={e => setListeningAnswers(p => ({...p, [q.id]: e.target.value}))}/> : <div className="space-y-2">{q.options?.map((opt: string) => <label key={opt} className="flex items-center gap-2 cursor-pointer"><input type="radio" checked={listeningAnswers[q.id] === opt} onChange={() => setListeningAnswers(p => ({...p, [q.id]: opt}))}/><span className="text-sm font-bold">{opt}</span></label>)}</div>}</div></div>
                          ))}</div>
                          <div className="p-6 bg-slate-50 flex justify-end"><button onClick={handleNextListeningSection} className="bg-black text-white px-8 py-3 rounded-lg font-black uppercase">Next</button></div>
                      </div>
                  )}
                  {phase === 'READING' && content?.reading?.[readingSectionIndex] && (
                      <div className="bg-white rounded-[2rem] border-4 border-black p-8 flex flex-col lg:flex-row gap-8 min-h-[600px] shadow-xl">
                          <div className="w-full lg:w-1/2 p-8 bg-slate-50 rounded-2xl overflow-y-auto max-h-[70vh]"><h3 className="font-black text-2xl mb-6 font-serif italic">{content.reading[readingSectionIndex].title}</h3><p className="whitespace-pre-wrap leading-loose font-serif">{content.reading[readingSectionIndex].text}</p></div>
                          <div className="w-full lg:w-1/2 overflow-y-auto max-h-[70vh] space-y-8">{content.reading[readingSectionIndex].questions?.map((q: any, i: number) => (
                              <div key={q.id} className="border-b-2 pb-6"><p className="font-bold mb-4">Q{i + 1}. {q.text}</p><div className="space-y-2">{q.options?.map((opt: string) => <label key={opt} className="flex items-center gap-2 cursor-pointer"><input type="radio" checked={readingAnswers[q.id] === opt} onChange={() => setReadingAnswers(p => ({...p, [q.id]: opt}))}/><span className="text-sm font-bold">{opt}</span></label>)}</div></div>
                          ))}<button onClick={handleNextPhase} className="w-full bg-black text-white py-4 rounded-xl font-black uppercase">Next</button></div>
                      </div>
                  )}
                  {phase === 'WRITING' && (
                      <div className="space-y-12">
                          <div className="bg-white p-8 rounded-[2rem] border-4 border-black shadow-lg"><h3>Writing Task 1</h3><p>{content?.writingTask1?.prompt}</p>{renderTask1Chart(content?.writingTask1)}<textarea className="w-full h-48 p-6 border-2 mt-4" placeholder="Type here..." onChange={e => setWritingAnswers(p => ({...p, task1: e.target.value}))}/></div>
                          <div className="bg-white p-8 rounded-[2rem] border-4 border-black shadow-lg"><h3>Writing Task 2</h3><p className="font-bold mb-4">{content?.writingTask2?.text}</p><textarea className="w-full h-64 p-6 border-2" placeholder="Type here..." onChange={e => setWritingAnswers(p => ({...p, task2: e.target.value}))}/><div className="flex justify-end mt-6"><button onClick={handleNextPhase} className="bg-black text-white px-12 py-4 rounded-xl font-black uppercase">Next</button></div></div>
                      </div>
                  )}
                  {phase === 'SPEAKING' && (
                      <div className="bg-white rounded-[2.5rem] border-4 border-black p-10 min-h-[60vh] flex flex-col items-center justify-center text-center shadow-2xl relative">
                          <button onClick={toggleRecording} className={`w-24 h-24 rounded-full flex items-center justify-center mb-6 transition-all ${isRecording ? 'bg-rose-500 text-white animate-pulse' : 'bg-slate-900 text-white'}`}>{isRecording ? <Activity /> : <Mic />}</button>
                          <h2 className="text-4xl font-black uppercase mb-4">Speaking Section {speakingPart}</h2>
                          <div className="bg-slate-50 border-2 rounded-2xl p-6 min-h-[120px] text-left w-full max-w-2xl mb-8"><p className="text-lg font-medium">{transcript || <span className="text-slate-400 italic">Waiting...</span>}</p></div>
                          <div className="max-w-xl w-full bg-indigo-50 p-8 rounded-2xl text-left"><p className="font-bold">Question:</p><p className="mt-2">{speakingPart === 1 ? content?.speaking?.part1?.[0] : speakingPart === 2 ? content?.speaking?.part2Topic : content?.speaking?.part3?.[0]}</p></div>
                          <button onClick={() => speakingPart < 3 ? setSpeakingPart(p => (p+1) as 1|2|3) : handleNextPhase()} className="mt-10 bg-indigo-600 text-white px-10 py-4 rounded-xl font-black">Next</button>
                      </div>
                  )}
              </div>
          </div>
      </div>
  );
};


import React, { useState } from 'react';
import { generateStyleTransfer } from '../services/geminiService';
import { StyleTransferResult } from '../types';
import { PenTool, ArrowRight, Loader2, Sparkles, Wand2 } from 'lucide-react';

export const StyleTransferScreen = ({ onBack }: { onBack: () => void }) => {
  const [input, setInput] = useState('');
  const [result, setResult] = useState<StyleTransferResult | null>(null);
  const [loading, setLoading] = useState(false);

  const handleTransform = async () => {
      if (!input.trim()) return;
      setLoading(true);
      try {
          const res = await generateStyleTransfer(input);
          setResult(res);
      } catch (e) {
          console.error(e);
      } finally {
          setLoading(false);
      }
  };

  return (
    <div className="w-full max-w-5xl mx-auto py-12 px-6 animate-slide-up">
        <button onClick={onBack} className="mb-8 font-black text-xs uppercase tracking-widest text-slate-500 hover:text-black">← Back to Menu</button>
        
        <div className="text-center mb-16">
            <div className="inline-block p-4 bg-indigo-100 rounded-full border-2 border-black mb-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                <Wand2 className="w-8 h-8 text-indigo-600" />
            </div>
            <h2 className="text-5xl font-black uppercase tracking-tighter mb-2 text-slate-900">Style Transfer</h2>
            <p className="text-xl font-bold text-slate-500">Transform informal speech into academic excellence.</p>
        </div>

        <div className="bg-white rounded-[3rem] p-8 md:p-12 border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] mb-16 relative">
            <div className="absolute top-6 left-8 bg-slate-100 text-slate-500 px-3 py-1 rounded font-black text-xs uppercase tracking-widest">Input</div>
            <textarea 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type something casual here... (e.g., 'The graph went up super fast')"
                className="w-full h-40 resize-none text-2xl md:text-4xl font-bold outline-none placeholder:text-slate-300 mt-6 bg-transparent"
            />
            <div className="flex justify-end mt-4 pt-6 border-t-2 border-slate-100">
                <button 
                    onClick={handleTransform}
                    disabled={loading || !input.trim()}
                    className="bg-black text-white px-10 py-4 rounded-2xl font-black uppercase tracking-wider flex items-center gap-3 hover:bg-indigo-600 border-2 border-transparent hover:border-black hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 transition-all disabled:opacity-50 active:translate-y-0 active:shadow-none"
                >
                    {loading ? <Loader2 className="animate-spin" /> : <><Sparkles className="w-5 h-5" /> Rewrite</>}
                </button>
            </div>
        </div>

        {result && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 animate-scale-in">
                {/* Neutral */}
                <div className="bg-slate-50 rounded-[2rem] border-4 border-slate-200 p-8 flex flex-col hover:-translate-y-2 transition-transform duration-300">
                    <h4 className="text-xs font-black uppercase tracking-widest text-slate-400 mb-6 border-b-2 border-slate-200 pb-2">Neutral Register</h4>
                    <p className="font-medium text-xl text-slate-700 leading-relaxed flex-1">{result.neutral || "N/A"}</p>
                </div>

                {/* Formal */}
                <div className="bg-white rounded-[2rem] border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] p-8 flex flex-col hover:-translate-y-2 transition-transform duration-300 transform md:-rotate-1">
                    <h4 className="text-xs font-black uppercase tracking-widest text-indigo-600 mb-6 border-b-2 border-slate-100 pb-2">Formal Register</h4>
                    <p className="font-bold text-xl text-slate-900 leading-relaxed flex-1">{result.formal || "N/A"}</p>
                </div>

                {/* Academic */}
                <div className="bg-indigo-600 rounded-[2rem] border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] p-8 flex flex-col relative overflow-hidden hover:-translate-y-2 transition-transform duration-300 transform md:rotate-1">
                    <div className="absolute top-0 right-0 p-3 bg-black text-white text-[10px] font-black uppercase border-bl-xl border-l-2 border-b-2 border-black rounded-bl-xl">Band 9.0</div>
                    <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-indigo-400 rounded-full blur-2xl opacity-50"></div>
                    
                    <h4 className="text-xs font-black uppercase tracking-widest text-indigo-200 mb-6 border-b-2 border-indigo-500 pb-2 relative z-10">Academic Register</h4>
                    <p className="font-bold text-xl md:text-2xl text-white leading-relaxed flex-1 relative z-10">{result.academic || "N/A"}</p>
                </div>
            </div>
        )}
    </div>
  );
};

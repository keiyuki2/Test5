import React, { useState, useEffect } from 'react';
import { X, ArrowRight, Clock, Target, Brain, Zap, Star, BookOpen, Headphones, Mic, FileText, Link, RefreshCw, Bomb, LayoutGrid, PenTool, Map, MessageSquare, Repeat } from 'lucide-react';
import { GameMode, Difficulty } from '../types';
import { sfx } from '../services/soundService';
import { motion, AnimatePresence } from 'framer-motion';

interface GameInfo {
  mode: GameMode;
  title: string;
  subtitle: string;
  description: string;
  howToPlay: string;
  trains: string[];
  duration: string;
  difficulty: string;
  color: string;
  icon: React.ElementType;
}

const GAME_INFO: Partial<Record<GameMode, GameInfo>> = {
  [GameMode.READING]: {
    mode: GameMode.READING, title: 'Reading', subtitle: 'Comprehension & Analysis',
    description: 'Read authentic IELTS-style passages and answer True/False/Not Given, multiple choice, and short answer questions under timed conditions.',
    howToPlay: 'Read the passage carefully, then answer each question. You have unlimited time but pace yourself — real IELTS gives ~20 minutes per section.',
    trains: ['Skimming for main ideas', 'Scanning for specific info', 'Understanding writer\'s purpose', 'Inferring meaning from context'],
    duration: '15–20 min', difficulty: 'Medium', color: 'bg-cyan-400', icon: BookOpen,
  },
  [GameMode.LISTENING]: {
    mode: GameMode.LISTENING, title: 'Listening', subtitle: 'Audio Comprehension',
    description: 'Listen to conversations and monologues, then complete forms, match headings, or answer multiple choice questions — exactly like the real exam.',
    howToPlay: 'Press Play, listen carefully (no rewind!), and fill in your answers. Focus on keywords and signal words that indicate answers.',
    trains: ['Following spoken instructions', 'Identifying opinions vs facts', 'Note-taking under pressure', 'Accent comprehension'],
    duration: '10–15 min', difficulty: 'Medium', color: 'bg-rose-400', icon: Headphones,
  },
  [GameMode.WRITING]: {
    mode: GameMode.WRITING, title: 'Writing', subtitle: 'Task 1 & Task 2',
    description: 'Write essays and report descriptions, then get instant AI feedback on vocabulary, grammar, coherence, and task achievement — scored to the IELTS rubric.',
    howToPlay: 'Read the prompt, plan your response (5 min), then write. Aim for 250+ words for Task 2. Submit for AI feedback scored against official criteria.',
    trains: ['Academic vocabulary range', 'Coherence & cohesion', 'Task achievement', 'Grammatical accuracy'],
    duration: '30–45 min', difficulty: 'Hard', color: 'bg-fuchsia-400', icon: FileText,
  },
  [GameMode.SPEAKING]: {
    mode: GameMode.SPEAKING, title: 'Speaking', subtitle: 'Cue Card Practice',
    description: 'Draw a random cue card, get 1 minute to prepare, then speak for 2 minutes. AI transcribes your speech and scores fluency, vocabulary, and pronunciation.',
    howToPlay: 'Read the cue card, make notes during prep time, then speak naturally. Don\'t memorize scripts — examiners can tell. Aim for natural flow.',
    trains: ['Fluency & coherence', 'Lexical resource', 'Pronunciation clarity', 'Responding under pressure'],
    duration: '5–10 min', difficulty: 'Medium', color: 'bg-amber-400', icon: Mic,
  },
  [GameMode.VOCABULARY]: {
    mode: GameMode.VOCABULARY, title: 'Vocabulary', subtitle: 'Band 8–9 Word Bank',
    description: 'Learn and test high-frequency academic vocabulary used in Band 8–9 responses. Multiple question formats keep it challenging.',
    howToPlay: 'You\'ll see a word and four definitions — pick the right one. Some questions flip it: you get the definition and must find the word. Keep your streak!',
    trains: ['High-frequency academic vocab', 'Word meaning in context', 'Spelling accuracy', 'Synonym recognition'],
    duration: '5–10 min', difficulty: 'Medium', color: 'bg-lime-400', icon: Brain,
  },
  [GameMode.COLLOCATION]: {
    mode: GameMode.COLLOCATION, title: 'Collocations', subtitle: 'Natural Word Pairs',
    description: 'Master the word combinations that native speakers use naturally. "Make a decision" not "do a decision." These patterns instantly raise your band score.',
    howToPlay: 'Complete the sentence by choosing the correct collocating word. Read carefully — all options may look similar but only one sounds natural.',
    trains: ['Natural language production', 'Avoiding L1 interference', 'Verb-noun collocations', 'Adjective-noun pairs'],
    duration: '5–8 min', difficulty: 'Easy', color: 'bg-cyan-400', icon: Link,
  },
  [GameMode.IDIOM]: {
    mode: GameMode.IDIOM, title: 'Idioms', subtitle: 'Native-Level Expressions',
    description: 'Learn and use the idiomatic expressions that distinguish Band 8 speakers from Band 6. Fill in the missing word to complete each idiom.',
    howToPlay: 'Read the sentence with a blank, then choose the correct word to complete the idiom. Think about the overall meaning, not just grammar.',
    trains: ['Idiomatic expression range', 'Contextual usage', 'Native-like fluency', 'Figurative language'],
    duration: '5–8 min', difficulty: 'Hard', color: 'bg-orange-400', icon: Bomb,
  },
  [GameMode.SYNONYM]: {
    mode: GameMode.SYNONYM, title: 'Synonyms', subtitle: 'Paraphrase Power',
    description: 'Build your paraphrase toolkit. Find synonyms and antonyms quickly — essential for IELTS Writing and Speaking band 7+ vocabulary.',
    howToPlay: 'Find the word that means the same (or opposite) as the target word. Some rounds use matching pairs — drag or tap to connect them.',
    trains: ['Vocabulary range', 'Paraphrasing ability', 'Avoiding repetition', 'Antonym recognition'],
    duration: '4–7 min', difficulty: 'Easy', color: 'bg-fuchsia-400', icon: RefreshCw,
  },
  [GameMode.DICTATION]: {
    mode: GameMode.DICTATION, title: 'Dictation', subtitle: 'Listen & Transcribe',
    description: 'Hear a sentence read aloud, then type it exactly as you heard it. Trains both listening accuracy and spelling simultaneously.',
    howToPlay: 'Listen to the audio clip, then type the exact sentence you heard. Spelling counts! You can replay the clip once before submitting.',
    trains: ['Spelling accuracy', 'Listening for detail', 'Phonetic awareness', 'Vocabulary in context'],
    duration: '5–8 min', difficulty: 'Medium', color: 'bg-lime-400', icon: Headphones,
  },
  [GameMode.TONE]: {
    mode: GameMode.TONE, title: 'Register', subtitle: 'Formal vs Informal',
    description: 'Transform casual sentences into formal academic English. Essential for IELTS Writing Task 2 and professional communication.',
    howToPlay: 'You\'ll see an informal sentence. Pick the formal version from the options. Watch for vocabulary, contractions, and passive voice.',
    trains: ['Academic register', 'Formal vocabulary', 'Avoiding informal language', 'Passive construction'],
    duration: '5–8 min', difficulty: 'Easy', color: 'bg-rose-400', icon: MessageSquare,
  },
  [GameMode.HEADING_MATCH]: {
    mode: GameMode.HEADING_MATCH, title: 'Heading Match', subtitle: 'Paragraph Logic',
    description: 'Match section headings to paragraphs — one of the hardest IELTS Reading question types. Tests your ability to understand the main idea of each paragraph.',
    howToPlay: 'Read each paragraph, identify its main idea, then match it to the correct heading. Be careful — there are always more headings than paragraphs.',
    trains: ['Identifying main ideas', 'Understanding text structure', 'Rejecting distractors', 'Skimming efficiency'],
    duration: '10–15 min', difficulty: 'Hard', color: 'bg-amber-400', icon: LayoutGrid,
  },
  [GameMode.STYLE_TRANSFER]: {
    mode: GameMode.STYLE_TRANSFER, title: 'Style Transfer', subtitle: 'Rewrite to Academic',
    description: 'Take everyday language and transform it into polished academic English. AI scores your rewrite on vocabulary, formality, and clarity.',
    howToPlay: 'Read the casual sentence, then rewrite it in formal academic English. Aim for precision and variety. Avoid contractions and first person where possible.',
    trains: ['Academic writing style', 'Vocabulary substitution', 'Sentence restructuring', 'Formal grammar'],
    duration: '10–15 min', difficulty: 'Medium', color: 'bg-cyan-400', icon: PenTool,
  },
  [GameMode.MAP]: {
    mode: GameMode.MAP, title: 'Spatial Map', subtitle: 'Map & Diagram Tasks',
    description: 'Describe changes in maps, floor plans, and diagrams — a Task 1 skill that many students struggle with. Learn the vocabulary and spatial language you need.',
    howToPlay: 'Look at the map and listen to the description. Identify the location being described and answer the question. Focus on directional language.',
    trains: ['Spatial vocabulary', 'Directional language', 'Map reading speed', 'Locating specific places'],
    duration: '8–12 min', difficulty: 'Medium', color: 'bg-lime-400', icon: Map,
  },
  [GameMode.LEXICAL_ECHO]: {
    mode: GameMode.LEXICAL_ECHO, title: 'Lexical Echo', subtitle: 'Recall Training',
    description: 'The hardest vocabulary mode. You see a word with its definition — then the definition disappears and you must define it from memory. Forces true retention.',
    howToPlay: 'Study the word and definition carefully. When the definition hides, type what you remember. The more anchors you recall, the higher your score.',
    trains: ['Active recall vs passive recognition', 'Deep vocabulary encoding', 'Definition construction', 'Memory retention'],
    duration: '8–12 min', difficulty: 'Hard', color: 'bg-fuchsia-400', icon: Repeat,
  },
  [GameMode.SYNAPTIC_BRIDGE]: {
    mode: GameMode.SYNAPTIC_BRIDGE, title: 'Synaptic Bridge', subtitle: 'Activate Passive Vocab',
    description: 'You know a word passively (recognize it) but can you use it actively? Bridge the gap by writing sentences that use the target word in context.',
    howToPlay: 'Read the simple sentence and the target academic word. Rewrite the sentence using that word naturally. AI checks if you used it correctly.',
    trains: ['Passive → active vocab shift', 'Contextual accuracy', 'Sentence construction', 'Academic expression'],
    duration: '8–12 min', difficulty: 'Hard', color: 'bg-amber-400', icon: Zap,
  },
  [GameMode.PRONUNCIATION]: {
    mode: GameMode.PRONUNCIATION, title: 'Pronunciation', subtitle: 'Phonetic Training',
    description: 'Practice the sounds that Mongolian speakers commonly confuse in English. Get real-time feedback on specific phonemes and word stress.',
    howToPlay: 'Press the mic, say the target word or sentence clearly. AI analyzes your pronunciation and highlights any problem areas with correction tips.',
    trains: ['Individual phoneme accuracy', 'Word stress patterns', 'Connected speech', 'Confidence in speaking'],
    duration: '5–10 min', difficulty: 'Easy', color: 'bg-rose-400', icon: Mic,
  },
  [GameMode.MOCK_EXAM]: {
    mode: GameMode.MOCK_EXAM, title: 'Mock Exam', subtitle: 'Full IELTS Simulation',
    description: 'A complete 4-section IELTS simulation with strict timing. Listening, Reading, Writing, and Speaking — all scored together for an overall band estimate.',
    howToPlay: 'Sit in a quiet place with 2.5 hours free. Complete all four sections without pausing. Your final score mimics how a real examiner would grade your work.',
    trains: ['Exam endurance', 'Time management across sections', 'Consistent performance under pressure', 'Overall band score estimate'],
    duration: '2.5 hours', difficulty: 'Hard', color: 'bg-stone-900', icon: Target,
  },
  [GameMode.PARAPHRASE]: {
    mode: GameMode.PARAPHRASE, title: 'Paraphrase', subtitle: 'Rewrite & Score',
    description: 'Read an IELTS or SAT-style sentence and rewrite it using different vocabulary and structure. Instant AI feedback scores your vocabulary, grammar, and meaning accuracy.',
    howToPlay: 'Read the sentence, then write a paraphrase that keeps the same meaning but uses different words. Longer is not better — aim for precision.',
    trains: ['Paraphrasing technique', 'Synonym usage', 'Structural variation', 'Meaning preservation'],
    duration: '5–10 min', difficulty: 'Medium', color: 'bg-amber-400', icon: RefreshCw,
  },
};

interface GamePreviewModalProps {
  mode: GameMode;
  onStart: () => void;
  onClose: () => void;
}

// Circular skill indicator (osu-style)
function SkillOrb({ label, value, color }: { label: string; value: number; color: string }) {
  const [animated, setAnimated] = useState(0);
  const size = 72;
  const radius = (size - 8) / 2;
  const circ = 2 * Math.PI * radius;

  useEffect(() => {
    const t = setTimeout(() => {
      let v = 0;
      const id = setInterval(() => {
        v = Math.min(v + value / 30, value);
        setAnimated(v);
        if (v >= value) clearInterval(id);
      }, 16);
      return () => clearInterval(id);
    }, 200);
    return () => clearTimeout(t);
  }, [value]);

  return (
    <div className="flex flex-col items-center gap-1.5">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="rotate-[-90deg] absolute inset-0">
          <circle cx={size/2} cy={size/2} r={radius} fill="none" stroke="#292524" strokeWidth={5} />
          <circle cx={size/2} cy={size/2} r={radius} fill="none"
            stroke={color} strokeWidth={5} strokeLinecap="round"
            strokeDasharray={circ}
            strokeDashoffset={circ * (1 - animated / 100)}
            style={{ transition: 'stroke-dashoffset 0.05s linear', filter: `drop-shadow(0 0 4px ${color}88)` }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="font-black text-sm" style={{ color }}>{Math.round(animated)}</span>
        </div>
      </div>
      <span className="text-[9px] font-black uppercase tracking-widest text-stone-500 text-center leading-tight">{label}</span>
    </div>
  );
}

const SKILL_VALUES: Partial<Record<GameMode, { label: string; value: number; color: string }[]>> = {
  [GameMode.READING]:      [{ label: 'Comprehension', value: 88, color: '#22d3ee' }, { label: 'Speed', value: 74, color: '#a3e635' }, { label: 'Detail', value: 82, color: '#fbbf24' }],
  [GameMode.LISTENING]:    [{ label: 'Accuracy', value: 85, color: '#f87171' }, { label: 'Speed', value: 70, color: '#fbbf24' }, { label: 'Focus', value: 90, color: '#4ade80' }],
  [GameMode.WRITING]:      [{ label: 'Vocabulary', value: 90, color: '#e879f9' }, { label: 'Grammar', value: 85, color: '#60a5fa' }, { label: 'Structure', value: 80, color: '#fbbf24' }],
  [GameMode.SPEAKING]:     [{ label: 'Fluency', value: 88, color: '#fbbf24' }, { label: 'Pronunciation', value: 75, color: '#f87171' }, { label: 'Vocab', value: 82, color: '#4ade80' }],
  [GameMode.VOCABULARY]:   [{ label: 'Memory', value: 90, color: '#4ade80' }, { label: 'Range', value: 85, color: '#fbbf24' }, { label: 'Context', value: 78, color: '#60a5fa' }],
  [GameMode.COLLOCATION]:  [{ label: 'Naturalness', value: 92, color: '#22d3ee' }, { label: 'Range', value: 80, color: '#fbbf24' }, { label: 'Accuracy', value: 85, color: '#4ade80' }],
  [GameMode.IDIOM]:        [{ label: 'Expression', value: 88, color: '#fb923c' }, { label: 'Context', value: 82, color: '#fbbf24' }, { label: 'Range', value: 76, color: '#a3e635' }],
  [GameMode.SYNONYM]:      [{ label: 'Range', value: 90, color: '#e879f9' }, { label: 'Precision', value: 84, color: '#fbbf24' }, { label: 'Speed', value: 78, color: '#60a5fa' }],
  [GameMode.DICTATION]:    [{ label: 'Accuracy', value: 88, color: '#4ade80' }, { label: 'Spelling', value: 80, color: '#fbbf24' }, { label: 'Speed', value: 72, color: '#22d3ee' }],
  [GameMode.TONE]:         [{ label: 'Register', value: 90, color: '#f87171' }, { label: 'Formality', value: 88, color: '#fbbf24' }, { label: 'Vocab', value: 82, color: '#4ade80' }],
  [GameMode.HEADING_MATCH]:[{ label: 'Comprehension', value: 85, color: '#fbbf24' }, { label: 'Speed', value: 70, color: '#22d3ee' }, { label: 'Inference', value: 88, color: '#4ade80' }],
  [GameMode.STYLE_TRANSFER]:[{ label: 'Style', value: 88, color: '#22d3ee' }, { label: 'Vocabulary', value: 85, color: '#fbbf24' }, { label: 'Grammar', value: 82, color: '#4ade80' }],
  [GameMode.LEXICAL_ECHO]: [{ label: 'Recall', value: 92, color: '#e879f9' }, { label: 'Depth', value: 88, color: '#fbbf24' }, { label: 'Retention', value: 84, color: '#4ade80' }],
  [GameMode.SYNAPTIC_BRIDGE]:[{ label: 'Activation', value: 90, color: '#fbbf24' }, { label: 'Accuracy', value: 85, color: '#4ade80' }, { label: 'Fluency', value: 80, color: '#60a5fa' }],
  [GameMode.MOCK_EXAM]:    [{ label: 'Overall', value: 88, color: '#fbbf24' }, { label: 'Endurance', value: 80, color: '#f87171' }, { label: 'Accuracy', value: 85, color: '#4ade80' }],
  [GameMode.PARAPHRASE]:   [{ label: 'Vocab', value: 88, color: '#fbbf24' }, { label: 'Grammar', value: 82, color: '#60a5fa' }, { label: 'Meaning', value: 90, color: '#4ade80' }],
};

const DEFAULT_SKILLS = [
  { label: 'Accuracy', value: 82, color: '#fbbf24' },
  { label: 'Range', value: 78, color: '#4ade80' },
  { label: 'Speed', value: 75, color: '#60a5fa' },
];

export function GamePreviewModal({ mode, onStart, onClose }: GamePreviewModalProps) {
  const info = GAME_INFO[mode];
  const skills = SKILL_VALUES[mode] ?? DEFAULT_SKILLS;
  if (!info) { onStart(); return null; }

  const diffColor = info.difficulty === 'Hard' ? 'bg-rose-500 text-white' : info.difficulty === 'Medium' ? 'bg-amber-400 text-black' : 'bg-lime-400 text-black';

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[75] bg-black/50 backdrop-blur-sm flex items-end md:items-center justify-center p-0 md:p-4"
        onClick={onClose} style={{ fontFamily: "'Inter', sans-serif" }}>
        <motion.div
          initial={{ opacity: 0, y: 60, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 40, scale: 0.97 }}
          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
          onClick={e => e.stopPropagation()}
          className="bg-white border-4 border-black rounded-t-3xl md:rounded-3xl w-full md:max-w-lg shadow-[0_-8px_40px_rgba(0,0,0,0.3)] md:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] overflow-hidden"
        >
          {/* Color header */}
          <div className={`${info.color} border-b-4 border-black p-5 relative overflow-hidden`}>
            <div className="absolute -right-8 -top-8 w-32 h-32 bg-black/10 rounded-full" />
            <button onClick={onClose} className="absolute top-4 right-4 w-8 h-8 bg-black/20 hover:bg-black/30 rounded-xl flex items-center justify-center transition-colors">
              <X className="w-4 h-4 text-black" />
            </button>
            <div className="flex items-center gap-3 relative z-10">
              <div className="w-12 h-12 bg-white border-4 border-black rounded-2xl flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
                <info.icon className="w-6 h-6 text-black" />
              </div>
              <div>
                <h2 className="font-black text-xl uppercase tracking-tight text-black leading-none">{info.title}</h2>
                <p className="text-black/60 text-xs font-bold uppercase tracking-widest mt-0.5">{info.subtitle}</p>
              </div>
            </div>
            {/* Meta pills */}
            <div className="flex items-center gap-2 mt-4 relative z-10">
              <span className={`text-[10px] font-black uppercase tracking-widest px-2.5 py-1 rounded-lg border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] ${diffColor}`}>
                {info.difficulty}
              </span>
              <span className="text-[10px] font-black uppercase tracking-widest px-2.5 py-1 bg-white border-2 border-black rounded-lg shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] text-black">
                <Clock className="w-3 h-3 inline mr-1" />{info.duration}
              </span>
            </div>
          </div>

          {/* Body */}
          <div className="p-5 space-y-4 max-h-[50vh] overflow-y-auto">
            {/* Description */}
            <p className="text-stone-600 font-medium text-sm leading-relaxed">{info.description}</p>

            {/* Skill orbs */}
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-400 mb-3">What it trains</p>
              <div className="flex justify-around">
                {skills.map(s => <SkillOrb key={s.label} {...s} />)}
              </div>
            </div>

            {/* How to play */}
            <div className="bg-stone-50 border-2 border-stone-200 rounded-2xl p-4">
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-400 mb-2 flex items-center gap-1.5">
                <Zap className="w-3 h-3" /> How to Play
              </p>
              <p className="text-sm text-stone-600 font-medium leading-relaxed">{info.howToPlay}</p>
            </div>

            {/* Trains list */}
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-400 mb-2">Skills trained</p>
              <div className="grid grid-cols-2 gap-1.5">
                {info.trains.map(t => (
                  <div key={t} className="flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 rounded-full bg-amber-400 flex-shrink-0" />
                    <span className="text-xs text-stone-600 font-medium">{t}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Footer CTA */}
          <div className="px-5 pb-5 pt-2 border-t border-stone-100">
            <button onClick={() => { sfx.select(); onStart(); }}
              className={`w-full flex items-center justify-center gap-2.5 py-4 ${info.color} border-4 border-black rounded-2xl font-black text-sm uppercase tracking-widest shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all group`}>
              Start {info.title} <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}

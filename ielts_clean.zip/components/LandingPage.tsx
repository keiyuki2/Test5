import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowRight, Zap, Target, BrainCircuit, Mic, PenTool, Star,
  CheckCircle, Minus, Plus, Repeat, Crown, Play,
  GraduationCap, Calculator, Languages, Trophy, Check,
  Sparkles, Globe, BookOpen, Headphones, FileText
} from 'lucide-react';

interface LandingPageProps {
  onNavigate: (mode: 'LOGIN' | 'SIGNUP') => void;
  onDemo: () => void;
  onSAT?: () => void;
}

// ── Helpers ────────────────────────────────────────────────────────────────
const cn = (...classes: (string | boolean | undefined)[]) => classes.filter(Boolean).join(' ');

function Sep() {
  return <div className="h-px bg-stone-200" />;
}

// ── Glassmorphism card ─────────────────────────────────────────────────────
function GlassCard({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={cn(
      'rounded-3xl border border-white/30 bg-white/10 backdrop-blur-xl shadow-[0_8px_32px_rgba(0,0,0,0.12)]',
      className
    )}>
      {children}
    </div>
  );
}

// ── Animated counter ───────────────────────────────────────────────────────
function Counter({ to, suffix = '' }: { to: number; suffix?: string }) {
  const [val, setVal] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) {
        let start = 0;
        const step = to / 40;
        const t = setInterval(() => {
          start = Math.min(start + step, to);
          setVal(Math.round(start));
          if (start >= to) clearInterval(t);
        }, 30);
      }
    }, { threshold: 0.5 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [to]);
  return <span ref={ref}>{val.toLocaleString()}{suffix}</span>;
}

// ── FAQ item ───────────────────────────────────────────────────────────────
function FAQItem({ q, a, i }: { q: string; a: string; i: number }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-stone-100 last:border-0">
      <button onClick={() => setOpen(!open)}
        className="w-full py-5 flex items-center justify-between text-left gap-4">
        <span className={cn('text-base md:text-lg font-bold transition-colors', open ? 'text-rose-500' : 'text-stone-800')}>
          {q}
        </span>
        <div className={cn('w-8 h-8 rounded-lg border-2 border-black flex items-center justify-center flex-shrink-0 transition-all shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]',
          open ? 'bg-rose-500 text-white translate-x-[2px] translate-y-[2px] shadow-none' : 'bg-white')}>
          {open ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
        </div>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }} className="overflow-hidden">
            <p className="text-stone-500 font-medium leading-relaxed pb-5 max-w-2xl">{a}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ── Main component ─────────────────────────────────────────────────────────
export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate, onDemo, onSAT }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    const onMove = (e: MouseEvent) => setMousePos({ x: e.clientX, y: e.clientY });
    window.addEventListener('scroll', onScroll);
    window.addEventListener('mousemove', onMove);
    return () => { window.removeEventListener('scroll', onScroll); window.removeEventListener('mousemove', onMove); };
  }, []);

  const features = [
    { icon: BrainCircuit, color: 'bg-amber-400',  label: 'AI Essay Lab',     desc: 'Sentence-level feedback trained on IELTS and SAT rubrics. Know exactly where you lose marks.' },
    { icon: Mic,          color: 'bg-rose-400',   label: 'Speaking Sim',     desc: 'Voice-activated cue card practice with real-time fluency and pronunciation scoring.' },
    { icon: BookOpen,     color: 'bg-cyan-400',   label: 'Reading Drills',   desc: 'Timed passage comprehension, heading match, and true/false/not-given under exam conditions.' },
    { icon: Headphones,   color: 'bg-lime-400',   label: 'Listening Lab',    desc: 'Map, form-fill, and multiple choice tasks with authentic audio scripts.' },
    { icon: Target,       color: 'bg-fuchsia-400',label: 'SAT Math Tools',   desc: 'Desmos graphing calculator integration plus algebra and data analysis walkthroughs.' },
    { icon: FileText,     color: 'bg-orange-400', label: 'Mock Exams',       desc: 'Full IELTS and SAT simulations with strict timing and band-score reports.' },
  ];

  const plans = [
    {
      name: 'Free',
      price: '$0',
      period: 'forever',
      color: 'bg-white',
      textColor: 'text-stone-900',
      shadow: 'shadow-[5px_5px_0px_0px_rgba(0,0,0,1)]',
      features: ['5 AI sessions / day', 'Basic drills & vocabulary', '1 mock exam per month', 'Community access'],
      cta: 'Start Free',
      plan: 'free' as const,
    },
    {
      name: 'Pro',
      price: '$19',
      period: '/month',
      color: 'bg-stone-900',
      textColor: 'text-white',
      shadow: 'shadow-[5px_5px_0px_0px_rgba(251,191,36,1)]',
      badge: 'Most Popular',
      features: ['Unlimited AI feedback', 'Speaking sim + scoring', 'Daily mock exams', 'All quick-drill games', 'Priority support'],
      cta: 'Go Pro',
      plan: 'pro' as const,
    },
    {
      name: 'Elite',
      price: '$49',
      period: '/month',
      color: 'bg-amber-400',
      textColor: 'text-black',
      shadow: 'shadow-[5px_5px_0px_0px_rgba(0,0,0,1)]',
      features: ['Everything in Pro', 'Animated profile banners', 'Exclusive badge set', 'Early feature access', 'Verified certificate'],
      cta: 'Go Elite',
      plan: 'elite' as const,
    },
  ];

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 overflow-x-hidden" style={{ fontFamily: "'Inter', sans-serif" }}>

      {/* ── Spotlight cursor effect ─────────────────────────────────────── */}
      <div className="fixed inset-0 pointer-events-none z-[60]"
        style={{ background: `radial-gradient(500px circle at ${mousePos.x}px ${mousePos.y}px, rgba(251,191,36,0.06), transparent 60%)` }} />

      {/* ── Navbar ──────────────────────────────────────────────────────── */}
      <nav className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
        scrolled ? 'bg-white/95 backdrop-blur-xl border-b border-stone-100 shadow-sm py-3' : 'bg-transparent py-5'
      )}>
        <div className="max-w-6xl mx-auto px-6 flex items-center justify-between">
          <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex items-center gap-2.5 group">
            <div className="w-9 h-9 bg-rose-500 border-4 border-black rounded-xl flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] group-hover:rotate-6 transition-transform">
              <Target className="w-4 h-4 text-white" strokeWidth={2.5} />
            </div>
            <span className="font-black text-base tracking-tight uppercase">IELTS<span className="text-rose-500"> MASTER</span></span>
          </button>

          <div className="hidden md:flex items-center gap-6">
            {[['Features', '#features'], ['Method', '#method'], ['Pricing', '#pricing']].map(([label, href]) => (
              <button key={label} onClick={() => document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' })}
                className="text-sm font-semibold text-stone-500 hover:text-stone-900 transition-colors">
                {label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <button onClick={() => onNavigate('LOGIN')}
              className="hidden md:block text-sm font-bold text-stone-600 hover:text-stone-900 transition-colors px-4 py-2">
              Log in
            </button>
            <button onClick={() => { sessionStorage.setItem('selectedPlan', plan); onNavigate('SIGNUP'); }}
              className="bg-stone-900 text-white px-5 py-2.5 rounded-xl font-black text-xs uppercase tracking-widest border-4 border-black shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:translate-x-0.5 hover:translate-y-0.5 hover:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] transition-all">
              Sign Up
            </button>
          </div>
        </div>
      </nav>

      {/* ── Hero ────────────────────────────────────────────────────────── */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        {/* Gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-stone-900 via-stone-800 to-stone-900" />
        {/* Subtle dot grid */}
        <div className="absolute inset-0 opacity-[0.04]"
          style={{ backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)', backgroundSize: '28px 28px' }} />
        {/* Color glow blobs */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-amber-400/20 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-rose-500/20 rounded-full blur-[100px] pointer-events-none" />

        <div className="relative z-10 max-w-6xl mx-auto px-6 py-32 md:py-40 w-full">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">

            {/* Left — copy */}
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, ease: [0.16,1,0.3,1] }}>
              <div className="inline-flex items-center gap-2 bg-amber-400 border-4 border-black rounded-xl px-4 py-2 mb-8 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
                <Sparkles className="w-3.5 h-3.5 text-black" />
                <span className="text-[11px] font-black uppercase tracking-[0.2em] text-black">AI-Powered Study Platform</span>
              </div>

              <h1 className="text-5xl sm:text-6xl md:text-7xl font-black leading-[0.9] tracking-tighter text-white mb-6">
                Ace Your<br />
                <span className="text-amber-400">IELTS</span> &{' '}
                <span className="text-rose-400">SAT.</span>
              </h1>

              <p className="text-lg text-stone-300 font-medium leading-relaxed mb-10 max-w-md">
                One platform with AI writing feedback, speaking simulation, listening labs, and full mock exams. Everything you need, nothing you don't.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 mb-12">
                <button onClick={() => { sessionStorage.setItem('selectedPlan', plan); onNavigate('SIGNUP'); }}
                  className="flex items-center justify-center gap-2.5 px-8 py-4 bg-amber-400 text-black border-4 border-black rounded-2xl font-black text-sm uppercase tracking-widest shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[7px_7px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all group">
                  Start for Free <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
                <button onClick={onDemo}
                  className="flex items-center justify-center gap-2.5 px-8 py-4 bg-white/10 text-white border border-white/20 rounded-2xl font-bold text-sm backdrop-blur-sm hover:bg-white/15 transition-all">
                  <Play className="w-4 h-4 fill-current" /> Take Assessment
                </button>
              </div>

              {/* Social proof pills */}
              <div className="flex flex-wrap gap-3">
                {['IELTS', 'SAT Prep', 'AI Feedback', 'Mock Exams'].map(tag => (
                  <span key={tag} className="px-3 py-1.5 bg-white/8 border border-white/15 rounded-lg text-xs font-bold text-stone-300 backdrop-blur-sm">
                    {tag}
                  </span>
                ))}
              </div>
            </motion.div>

            {/* Right — glassmorphism dashboard preview */}
            <motion.div initial={{ opacity: 0, scale: 0.9, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2, ease: [0.16,1,0.3,1] }}
              className="hidden lg:block relative">

              {/* Main glass card */}
              <GlassCard className="p-6">
                {/* Mock browser chrome */}
                <div className="flex items-center gap-2 mb-5 pb-4 border-b border-white/15">
                  <div className="w-3 h-3 rounded-full bg-rose-400 border border-rose-500" />
                  <div className="w-3 h-3 rounded-full bg-amber-400 border border-amber-500" />
                  <div className="w-3 h-3 rounded-full bg-lime-400 border border-lime-500" />
                  <div className="flex-1 mx-4 h-6 bg-white/10 rounded-lg" />
                </div>

                {/* Score cards */}
                <div className="grid grid-cols-3 gap-3 mb-5">
                  {[
                    { label: 'Writing',   score: '8.0', color: 'bg-amber-400/90',  dark: false },
                    { label: 'Speaking',  score: '7.5', color: 'bg-rose-400/90',   dark: false },
                    { label: 'Reading',   score: '8.5', color: 'bg-lime-400/90',   dark: false },
                  ].map(s => (
                    <div key={s.label} className={`${s.color} border-2 border-white/40 rounded-xl p-3 backdrop-blur-sm`}>
                      <p className="text-[9px] font-black uppercase tracking-widest text-black/60">{s.label}</p>
                      <p className="text-2xl font-black text-black leading-tight">{s.score}</p>
                    </div>
                  ))}
                </div>

                {/* AI feedback bubble */}
                <div className="bg-black/40 border border-white/15 rounded-2xl p-4 mb-4 backdrop-blur-sm">
                  <div className="flex items-start gap-3">
                    <div className="w-7 h-7 bg-amber-400 rounded-lg border border-black flex items-center justify-center flex-shrink-0">
                      <Sparkles className="w-3.5 h-3.5 text-black" />
                    </div>
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-widest text-amber-400 mb-1">AI Feedback</p>
                      <p className="text-xs text-stone-200 leading-relaxed">
                        Your use of <span className="text-amber-300 font-bold">cohesive devices</span> is strong. Consider varying sentence structure in paragraph 3.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="space-y-2">
                  <div className="flex justify-between text-[10px] font-bold text-white/50 uppercase tracking-widest">
                    <span>Overall Progress</span><span>74%</span>
                  </div>
                  <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                    <motion.div initial={{ width: 0 }} animate={{ width: '74%' }}
                      transition={{ duration: 1.5, delay: 0.8, ease: 'easeOut' }}
                      className="h-full bg-amber-400 rounded-full" />
                  </div>
                </div>
              </GlassCard>

              {/* Floating badge */}
              <motion.div animate={{ y: [0, -8, 0] }} transition={{ repeat: Infinity, duration: 2.5, ease: 'easeInOut' }}
                className="absolute -bottom-4 -left-4 bg-lime-400 border-4 border-black rounded-2xl px-4 py-3 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] flex items-center gap-2.5">
                <Trophy className="w-5 h-5 text-black" />
                <div>
                  <p className="text-[9px] font-black uppercase tracking-widest text-black/60">Band Score</p>
                  <p className="text-base font-black text-black leading-none">8.0</p>
                </div>
              </motion.div>

              {/* Floating streak */}
              <motion.div animate={{ y: [0, -6, 0] }} transition={{ repeat: Infinity, duration: 3, delay: 0.5, ease: 'easeInOut' }}
                className="absolute -top-4 -right-4 bg-rose-400 border-4 border-black rounded-2xl px-4 py-3 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] flex items-center gap-2">
                <Star className="w-4 h-4 text-black fill-current" />
                <span className="text-sm font-black text-black">14-day streak</span>
              </motion.div>
            </motion.div>
          </div>
        </div>

        {/* Scroll cue */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-30">
          <motion.div animate={{ y: [0, 6, 0] }} transition={{ repeat: Infinity, duration: 1.5 }}
            className="w-5 h-8 border-2 border-white rounded-full flex items-start justify-center pt-1.5">
            <div className="w-1 h-2 bg-white rounded-full" />
          </motion.div>
        </div>
      </section>

      {/* ── Stats bar ───────────────────────────────────────────────────── */}
      <section className="bg-white border-y border-stone-100">
        <div className="max-w-6xl mx-auto px-6 py-12 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { stat: 50000, suffix: '+', label: 'Students' },
            { stat: 95,    suffix: '%', label: 'Score Improvement' },
            { stat: 20,    suffix: '+', label: 'Practice Modes' },
            { stat: 4.9,   suffix: '★', label: 'Average Rating' },
          ].map(s => (
            <div key={s.label} className="text-center">
              <p className="text-3xl md:text-4xl font-black text-stone-900 leading-none mb-1">
                {s.stat < 10 ? s.stat : <Counter to={s.stat} />}{s.suffix}
              </p>
              <p className="text-xs font-bold text-stone-400 uppercase tracking-widest">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Features ────────────────────────────────────────────────────── */}
      <section id="features" className="py-24 px-6 max-w-6xl mx-auto">
        <div className="mb-14">
          <p className="text-[11px] font-black uppercase tracking-[0.25em] text-stone-400 mb-3">What's inside</p>
          <h2 className="text-4xl md:text-5xl font-black uppercase tracking-tighter text-stone-900 leading-tight">
            Everything you need<br />to <span className="text-rose-500">score higher.</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {features.map((f, i) => (
            <motion.div key={f.label}
              initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }} transition={{ delay: i * 0.07, duration: 0.5 }}
              className="group bg-white border-4 border-black rounded-2xl p-6 shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1.5 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all">
              <div className={`w-12 h-12 ${f.color} border-4 border-black rounded-xl flex items-center justify-center mb-4 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] group-hover:rotate-6 transition-transform`}>
                <f.icon className="w-6 h-6 text-black" />
              </div>
              <h3 className="font-black text-base uppercase tracking-tight text-stone-900 mb-2">{f.label}</h3>
              <p className="text-sm text-stone-500 font-medium leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <Sep />

      {/* ── Method section ──────────────────────────────────────────────── */}
      <section id="method" className="py-24 px-6 max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <p className="text-[11px] font-black uppercase tracking-[0.25em] text-stone-400 mb-3">How it works</p>
            <h2 className="text-4xl md:text-5xl font-black uppercase tracking-tighter text-stone-900 mb-10 leading-tight">
              Built on real<br /><span className="text-amber-500">learning science.</span>
            </h2>
            <div className="space-y-4">
              {[
                { icon: Zap,     color: 'bg-amber-400', title: 'Active Recall',       desc: 'Stop re-reading notes. Our system forces you to produce language from memory — the only method proven to build long-term retention.' },
                { icon: Repeat,  color: 'bg-cyan-400',  title: 'Spaced Repetition',   desc: 'We track what you forget and resurface it at exactly the right time — before it fades permanently.' },
                { icon: Sparkles,color: 'bg-lime-400',  title: 'Instant AI Feedback', desc: 'Every essay, every spoken answer — corrected immediately. No waiting days for a tutor\'s comments.' },
              ].map(item => (
                <div key={item.title}
                  className="flex items-start gap-4 p-5 bg-white border-4 border-black rounded-2xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] group hover:-translate-y-0.5 hover:shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] transition-all">
                  <div className={`w-10 h-10 ${item.color} border-4 border-black rounded-xl flex items-center justify-center flex-shrink-0 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] group-hover:rotate-6 transition-transform`}>
                    <item.icon className="w-5 h-5 text-black" />
                  </div>
                  <div>
                    <h4 className="font-black text-sm uppercase tracking-wide text-stone-900 mb-0.5">{item.title}</h4>
                    <p className="text-sm text-stone-500 font-medium leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Testimonial card */}
          <div className="space-y-5">
            <div className="bg-stone-900 rounded-3xl p-8 text-white border-4 border-black shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-amber-400/10 rounded-full blur-[80px]" />
              <div className="relative z-10">
                <div className="flex gap-1 mb-6">
                  {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 text-amber-400 fill-current" />)}
                </div>
                <p className="text-base font-medium text-stone-200 leading-relaxed mb-6 italic">
                  "I went from Band 6.0 to 7.5 in 6 weeks. The AI writing feedback is genuinely better than any tutor I've had. It catches mistakes I didn't even know I was making."
                </p>
                <div className="flex items-center gap-3 pt-4 border-t border-white/10">
                  <img src="https://api.dicebear.com/7.x/initials/svg?seed=Sara&backgroundColor=f59e0b&fontFamily=Arial&fontSize=40"
                    className="w-10 h-10 rounded-xl border-2 border-amber-400" alt="Sara" />
                  <div>
                    <p className="font-black text-sm">Sara K.</p>
                    <p className="text-xs text-stone-400 font-medium">IELTS Academic · Band 7.5</p>
                  </div>
                  <div className="ml-auto bg-lime-400 border-2 border-black rounded-lg px-3 py-1">
                    <span className="text-[10px] font-black text-black uppercase tracking-widest">Verified</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              {[
                { value: '0.5', unit: 'band',  label: 'Avg improvement in 2 weeks', color: 'bg-rose-400' },
                { value: '95',  unit: '%',     label: 'Accuracy vs. real examiners', color: 'bg-lime-400' },
              ].map(s => (
                <div key={s.label} className={`${s.color} border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]`}>
                  <p className="text-3xl font-black text-black leading-none">{s.value}<span className="text-lg">{s.unit}</span></p>
                  <p className="text-[10px] font-bold text-black/60 uppercase tracking-widest mt-1 leading-snug">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <Sep />

      {/* ── Pricing ─────────────────────────────────────────────────────── */}
      <section id="pricing" className="py-24 px-6 max-w-5xl mx-auto">
        <div className="text-center mb-14">
          <p className="text-[11px] font-black uppercase tracking-[0.25em] text-stone-400 mb-3">Pricing</p>
          <h2 className="text-4xl md:text-5xl font-black uppercase tracking-tighter text-stone-900 leading-tight">
            Pick your <span className="text-rose-500">plan.</span>
          </h2>
          <p className="text-stone-500 font-medium mt-3 max-w-md mx-auto">No hidden fees. Cancel anytime. Every plan includes access to the core platform.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map((plan, i) => (
            <motion.div key={plan.name}
              initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }} transition={{ delay: i * 0.1 }}
              className={cn(
                'relative flex flex-col rounded-3xl border-4 border-black p-7 transition-all hover:-translate-y-1',
                plan.color, plan.shadow,
                plan.name === 'Pro' && 'scale-[1.03]'
              )}>
              {plan.badge && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-amber-400 border-4 border-black px-5 py-1.5 rounded-xl shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
                  <span className="text-[10px] font-black uppercase tracking-widest text-black">{plan.badge}</span>
                </div>
              )}
              <h3 className={cn('font-black text-sm uppercase tracking-widest mb-1', plan.name === 'Pro' ? 'text-stone-400' : 'text-stone-500')}>{plan.name}</h3>
              <div className="flex items-baseline gap-1 mb-6">
                <span className={cn('text-5xl font-black tracking-tighter', plan.textColor)}>{plan.price}</span>
                <span className={cn('text-sm font-bold opacity-50', plan.textColor)}>{plan.period}</span>
              </div>
              <ul className="flex-1 space-y-3 mb-7">
                {plan.features.map(feat => (
                  <li key={feat} className="flex items-start gap-2.5">
                    <CheckCircle className={cn('w-4 h-4 mt-0.5 flex-shrink-0', plan.name === 'Pro' ? 'text-amber-400' : 'text-stone-500')} />
                    <span className={cn('text-sm font-medium', plan.name === 'Pro' ? 'text-stone-300' : 'text-stone-600')}>{feat}</span>
                  </li>
                ))}
              </ul>
              <button
                onClick={() => { sessionStorage.setItem('selectedPlan', plan); onNavigate('SIGNUP'); }}
                className={cn(
                  'w-full py-3.5 rounded-xl font-black text-xs uppercase tracking-widest border-4 border-black transition-all shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:translate-x-0.5 hover:translate-y-0.5 hover:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] active:shadow-none',
                  plan.name === 'Pro' ? 'bg-amber-400 text-black' : plan.name === 'Elite' ? 'bg-black text-white' : 'bg-stone-900 text-white'
                )}>
                {plan.cta}
              </button>
            </motion.div>
          ))}
        </div>
      </section>

      <Sep />

      {/* ── FAQ ─────────────────────────────────────────────────────────── */}
      <section className="py-24 px-6 max-w-3xl mx-auto">
        <div className="text-center mb-14">
          <p className="text-[11px] font-black uppercase tracking-[0.25em] text-stone-400 mb-3">FAQ</p>
          <h2 className="text-4xl font-black uppercase tracking-tighter text-stone-900">Common questions.</h2>
        </div>
        <div className="bg-white border-4 border-black rounded-3xl p-8 shadow-[5px_5px_0px_0px_rgba(0,0,0,1)]">
          {[
            { q: 'Is the content updated for 2026?', a: 'Yes. Our AI models are continuously updated to reflect the latest IELTS and SAT exam formats and scoring rubrics.' },
            { q: 'How accurate is the AI grading?', a: 'Blind tests show our scoring is within 0.5 bands of senior IELTS examiners 95% of the time, using official marking criteria.' },
            { q: 'Can I use both IELTS and SAT on one account?', a: 'Absolutely. One account gives you access to all programs — switch between them any time from the sidebar.' },
            { q: 'Is there a free trial?', a: 'Yes, the Free plan gives you 5 AI sessions per day and access to all core drills with no credit card required.' },
            { q: 'Can I cancel anytime?', a: 'Yes. There are no contracts. You can cancel your Pro or Elite subscription at any time from your profile settings.' },
          ].map((item, i) => <FAQItem key={i} q={item.q} a={item.a} i={i} />)}
        </div>
      </section>

      {/* ── CTA Banner ──────────────────────────────────────────────────── */}
      <section className="mx-4 md:mx-auto max-w-5xl mb-16">
        <div className="bg-stone-900 border-4 border-black rounded-3xl p-10 md:p-14 text-center relative overflow-hidden shadow-[6px_6px_0px_0px_rgba(0,0,0,1)]">
          <div className="absolute inset-0 opacity-[0.04]"
            style={{ backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)', backgroundSize: '22px 22px' }} />
          <div className="absolute top-0 right-0 w-64 h-64 bg-amber-400/15 rounded-full blur-[80px]" />
          <div className="relative z-10">
            <h2 className="text-4xl md:text-5xl font-black uppercase tracking-tighter text-white mb-4 leading-tight">
              Ready to score<br /><span className="text-amber-400">Band 8+?</span>
            </h2>
            <p className="text-stone-400 font-medium mb-8 max-w-md mx-auto">Join over 50,000 students who improved their scores with IELTS Master.</p>
            <button onClick={() => { sessionStorage.setItem('selectedPlan', plan); onNavigate('SIGNUP'); }}
              className="inline-flex items-center gap-3 px-10 py-4 bg-amber-400 text-black border-4 border-black rounded-2xl font-black text-sm uppercase tracking-widest shadow-[5px_5px_0px_0px_rgba(251,191,36,0.4)] hover:-translate-y-1 hover:shadow-[7px_7px_0px_0px_rgba(251,191,36,0.4)] transition-all group">
              Get Started Free <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* ── Footer ──────────────────────────────────────────────────────── */}
      <footer className="bg-stone-900 text-white border-t-4 border-black">
        <div className="max-w-6xl mx-auto px-6 py-14 grid grid-cols-2 md:grid-cols-4 gap-10">
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2.5 mb-5">
              <div className="w-8 h-8 bg-rose-500 border-4 border-white/20 rounded-xl flex items-center justify-center shadow-sm">
                <Target className="w-4 h-4 text-white" strokeWidth={2.5} />
              </div>
              <span className="font-black text-sm tracking-tight uppercase">IELTS<span className="text-rose-400"> MASTER</span></span>
            </div>
            <p className="text-stone-400 text-sm font-medium leading-relaxed">
              AI-powered test prep for IELTS and SAT. Built for real results.
            </p>
          </div>
          <div>
              <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-500 mb-4">Platform</h4>
              <ul className="space-y-3">
                {['IELTS Prep','SAT Prep','Mock Exams','Quick Drills'].map(l => <li key={l}><button className="text-sm text-stone-400 hover:text-white transition-colors font-medium">{l}</button></li>)}
              </ul>
            </div>
            <div>
              <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-500 mb-4">About</h4>
              <ul className="space-y-3">
                {[
                  ['About', () => onNavigate('SIGNUP')],
                  ['Support', () => onNavigate('SIGNUP')],
                ].map(([l]) => <li key={l as string}><button className="text-sm text-stone-400 hover:text-white transition-colors font-medium">{l as string}</button></li>)}
              </ul>
            </div>
            <div>
              <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-500 mb-4">Legal</h4>
              <ul className="space-y-3">
                {['Privacy Policy','Terms of Service','Cookie Policy'].map(l => <li key={l}><button className="text-sm text-stone-400 hover:text-white transition-colors font-medium">{l}</button></li>)}
              </ul>
            </div>
        </div>
        <div className="border-t border-white/5 py-6 px-6">
          <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-3">
            <p className="text-[10px] font-black uppercase tracking-[0.25em] text-stone-600">© 2026 IELTS MASTER. ALL RIGHTS RESERVED.</p>
<p className="text-[10px] font-black uppercase tracking-[0.25em] text-stone-600">Made with love by one student from Ulaanbaatar.</p>
          </div>
        </div>
      </footer>

      <style>{`
        @keyframes marquee { from { transform: translateX(0); } to { transform: translateX(-50%); } }
        .animate-marquee { animation: marquee 20s linear infinite; }
      `}</style>
    </div>
  );
};

export default LandingPage;

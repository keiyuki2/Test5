
import React, { useState, useEffect } from 'react';
import { Question } from '../types';
import { Send, Clock, AlignLeft, RefreshCw, PenTool } from 'lucide-react';

interface WritingGameScreenProps {
  question: Question;
  onSubmit: (text: string) => void;
  isEvaluating: boolean;
}

export const WritingGameScreen: React.FC<WritingGameScreenProps> = ({ 
  question, 
  onSubmit, 
  isEvaluating 
}) => {
  const [essay, setEssay] = useState('');
  const [wordCount, setWordCount] = useState(0);
  const [seconds, setSeconds] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      if (!isEvaluating) {
        setSeconds(s => s + 1);
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [isEvaluating]);

  const handleEssayChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const text = e.target.value;
    setEssay(text);
    const words = text.trim() === '' ? 0 : text.trim().split(/\s+/).length;
    setWordCount(words);
  };

  const formatTime = (totalSeconds: number) => {
    const m = Math.floor(totalSeconds / 60);
    const s = totalSeconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const handleSubmit = () => {
    if (wordCount < 50) return;
    onSubmit(essay);
  };

  return (
    <div className="w-full max-w-[1920px] mx-auto animate-slide-up flex flex-col md:flex-row gap-8 min-h-[calc(100vh-140px)] md:h-[calc(100vh-140px)] px-2 md:px-6">
      
      {/* Left Panel: Prompt & Tools */}
      <div className="w-full md:w-1/3 xl:w-1/4 flex flex-col gap-6">
        <div className="bg-white rounded-[2rem] p-6 md:p-8 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] md:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] flex-none">
            <div className="flex items-center gap-2 mb-4">
                <span className="bg-black text-white text-[10px] md:text-xs font-black px-3 py-1 rounded uppercase tracking-widest">
                  Writing Task
                </span>
                <span className="bg-indigo-100 text-indigo-700 border-2 border-indigo-200 text-[10px] md:text-xs font-black px-3 py-1 rounded uppercase tracking-widest truncate max-w-[150px]">
                  {question.context || "Essay Topic"}
                </span>
            </div>
            <h2 className="text-lg md:text-xl font-bold text-slate-900 leading-snug font-sans">
              {question.text}
            </h2>
        </div>

        <div className="bg-indigo-500 rounded-[2rem] p-6 md:p-8 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] md:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] flex-1 flex flex-col justify-center items-center gap-6 md:gap-10 text-white min-h-[200px] md:min-h-0">
             <div className="text-center group w-full">
                 <div className="flex items-center justify-center gap-2 text-indigo-200 mb-2">
                     <Clock className="w-5 h-5" />
                     <span className="text-[10px] md:text-sm font-black uppercase tracking-widest">Time</span>
                 </div>
                 <span className="text-4xl md:text-6xl font-mono font-bold tracking-tighter block bg-black/20 rounded-xl py-2 mx-4 border-2 border-black/10">
                     {formatTime(seconds)}
                 </span>
             </div>

             <div className="w-full h-1 bg-indigo-400/50" />

             <div className="text-center group w-full">
                 <div className="flex items-center justify-center gap-2 text-indigo-200 mb-2">
                     <AlignLeft className="w-5 h-5" />
                     <span className="text-[10px] md:text-sm font-black uppercase tracking-widest">Words</span>
                 </div>
                 <span className={`text-5xl md:text-7xl font-black transition-all duration-300 ${wordCount >= 250 ? 'text-emerald-300' : 'text-white'}`}>
                     {wordCount}
                 </span>
                 <p className="text-[10px] md:text-xs text-indigo-200 mt-2 uppercase tracking-wide font-bold">Goal: 250+</p>
             </div>
        </div>
      </div>

      {/* Right Panel: Editor */}
      <div className="w-full md:w-2/3 xl:w-3/4 flex flex-col bg-white rounded-[2rem] shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] md:shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] border-4 border-black overflow-hidden relative group h-[500px] md:h-auto">
          <div className="bg-slate-100 px-6 md:px-8 py-4 md:py-5 border-b-4 border-black flex justify-between items-center z-10">
              <span className="text-xs md:text-sm font-black text-slate-700 uppercase tracking-widest flex items-center gap-2">
                  <PenTool className="w-4 h-4 md:w-5 md:h-5" /> Write Here
              </span>
              <button 
                onClick={handleSubmit}
                disabled={wordCount < 10 || isEvaluating}
                className={`
                    flex items-center gap-2 px-4 md:px-8 py-2 md:py-3 rounded-xl font-black text-xs md:text-sm uppercase tracking-wider transition-all duration-300 border-2 border-black
                    ${wordCount < 10 || isEvaluating
                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed border-slate-300' 
                    : 'bg-indigo-600 text-white shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] md:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:bg-indigo-700 hover:-translate-y-1 hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] md:hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-none'}
                `}
              >
                  {isEvaluating ? (
                      <>
                        <RefreshCw className="w-3 h-3 md:w-4 md:h-4 animate-spin" /> <span className="hidden sm:inline">Checking...</span>
                      </>
                  ) : (
                      <>
                        Submit <Send className="w-3 h-3 md:w-4 md:h-4" />
                      </>
                  )}
              </button>
          </div>
          <div className="flex-1 relative bg-white">
            <textarea 
                className="w-full h-full p-6 md:p-10 text-lg md:text-xl text-slate-900 leading-relaxed resize-none focus:outline-none font-medium bg-transparent relative z-10 font-sans"
                placeholder="Start writing here..."
                value={essay}
                onChange={handleEssayChange}
                disabled={isEvaluating}
                spellCheck={false}
            />
            {/* Ruled lines effect */}
            <div className="absolute inset-0 pointer-events-none opacity-10 bg-[linear-gradient(transparent_31px,#000_32px)] bg-[size:100%_32px] mt-11"></div>
          </div>
      </div>
    </div>
  );
};

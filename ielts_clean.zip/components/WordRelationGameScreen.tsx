
import React, { useState, useEffect } from 'react';
import { WordRelationQuestion } from '../types';
import { ArrowRight, RefreshCw, Check, X, RotateCcw, Split, Loader2, Info } from 'lucide-react';

interface WordRelationGameScreenProps {
  questions: WordRelationQuestion[];
  mode: 'SYNONYM' | 'ANTONYM';
  onComplete: () => void;
}

export const WordRelationGameScreen: React.FC<WordRelationGameScreenProps> = ({ questions, mode, onComplete }) => {
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [hasAnswered, setHasAnswered] = useState(false);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [history, setHistory] = useState<boolean[]>([]);
  
  // Matching state
  const [matchingSelections, setMatchingSelections] = useState<{a: string | null, b: string | null}>({a: null, b: null});
  const [matchedIndices, setMatchedIndices] = useState<number[]>([]);
  const [matchError, setMatchError] = useState<boolean>(false);

  const currentQ = questions && questions[index];
  const isSynonym = mode === 'SYNONYM';

  const theme = isSynonym ? {
      main: 'bg-blue-500',
      light: 'bg-blue-100',
      border: 'border-blue-600',
      text: 'text-blue-600',
      accent: 'bg-blue-50',
      icon: RefreshCw,
      label: "Synonym Hunter"
  } : {
      main: 'bg-orange-500',
      light: 'bg-orange-100',
      border: 'border-orange-600',
      text: 'text-orange-600',
      accent: 'bg-orange-50',
      icon: Split,
      label: "Antonym Striker"
  };

  const handleOptionClick = (option: string) => {
    if (hasAnswered) return;
    setSelectedOption(option);
    setHasAnswered(true);
    const isCorrect = option === (currentQ.correctAnswer || (currentQ.variant === 'BINARY' ? 'True' : ''));
    if (isCorrect) setScore(s => s + 1);
    setHistory(prev => [...prev, isCorrect]);
  };

  const handleMatchSelect = (side: 'a' | 'b', val: string) => {
      if (hasAnswered || matchError) return;
      
      const newSelections = { ...matchingSelections, [side]: val };
      setMatchingSelections(newSelections);

      if (newSelections.a && newSelections.b) {
          // Check if this specific pair (a, b) exists in the pairs array
          const pairIndex = (currentQ.pairs || []).findIndex(p => p.a === newSelections.a && p.b === newSelections.b);
          
          if (pairIndex !== -1) {
              // Correct Match
              const newMatched = [...matchedIndices, pairIndex];
              setMatchedIndices(newMatched);
              setMatchingSelections({a: null, b: null});
              
              if (newMatched.length === (currentQ.pairs?.length ?? 0)) {
                  setHasAnswered(true);
                  setScore(s => s + 1);
                  setHistory(prev => [...prev, true]);
              }
          } else {
              // Wrong Match - Visual Shake/Red
              setMatchError(true);
              setTimeout(() => {
                  setMatchingSelections({a: null, b: null});
                  setMatchError(false);
              }, 600);
          }
      }
  };

  const handleNext = () => {
    if (index < questions.length - 1) {
      setIndex(i => i + 1);
      setHasAnswered(false);
      setSelectedOption(null);
      setMatchedIndices([]);
      setMatchingSelections({a: null, b: null});
      setMatchError(false);
    } else {
      onComplete();
    }
  };

  if (!currentQ || index >= questions.length) {
      const percentage = Math.round((score / (questions.length || 1)) * 100);
      return (
          <div className="w-full max-w-2xl mx-auto py-12 px-4 md:px-6 animate-slide-up">
              <div className="bg-white rounded-[3rem] border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] text-center relative overflow-hidden">
                  <div className={`${theme.main} p-10 border-b-4 border-black relative`}>
                      <div className="relative z-10">
                          <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-black">
                              <theme.icon className={`w-10 h-10 ${theme.text}`} />
                          </div>
                          <h2 className="text-4xl font-black uppercase text-white tracking-tighter">Mission Complete</h2>
                      </div>
                  </div>
                  <div className="p-8">
                      <div className="flex justify-center gap-8 mb-8">
                          <div><p className="text-[10px] font-black uppercase text-slate-400">Score</p><p className="text-5xl font-black">{score}</p></div>
                          <div><p className="text-[10px] font-black uppercase text-slate-400">Accuracy</p><p className="text-5xl font-black">{percentage}%</p></div>
                      </div>
                      <button onClick={onComplete} className="w-full py-4 bg-black text-white rounded-2xl font-black uppercase tracking-widest shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all active:translate-y-1 active:shadow-none">Return to Base</button>
                  </div>
              </div>
          </div>
      );
  }

  // FIX: Explicit check for empty array to properly fallback to True/False options
  const currentOptions = (currentQ.options && currentQ.options.length > 0) 
      ? currentQ.options 
      : ['True', 'False'];

  return (
    <div className="w-full max-w-4xl mx-auto py-4 px-4 animate-slide-up flex flex-col min-h-[calc(100vh-120px)]">
      {/* Header HUD */}
      <div className="flex justify-between items-center mb-6 bg-white p-3 md:p-4 rounded-2xl border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
          <div className="flex items-center gap-3">
              <div className={`${theme.main} text-white p-1.5 rounded-lg border-2 border-black`}><theme.icon className="w-5 h-5" /></div>
              <div><p className="text-[8px] font-black uppercase text-slate-400">{theme.label}</p><p className="text-lg font-black leading-none">{score}</p></div>
          </div>
          <div className="text-right">
              <p className="text-[8px] font-black uppercase text-slate-400">Mission</p>
              <p className={`text-lg font-black leading-none ${theme.text}`}>{index + 1}<span className="text-slate-400 text-sm">/{questions.length}</span></p>
          </div>
      </div>

      <div className="flex-1 flex flex-col justify-center items-center pb-24 md:pb-0">
          
          {currentQ.variant === 'MATCH' ? (
              <div className="w-full max-w-2xl">
                  <div className="text-center mb-8">
                      <span className={`px-4 py-1 rounded-full border-2 border-black font-black uppercase text-[10px] ${theme.light} ${theme.text}`}>Connect the Pairs</span>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-3">
                          {(currentQ.pairs || []).map((p, idx) => {
                              const isMatched = matchedIndices.includes(idx);
                              const isSelected = matchingSelections.a === p.a;
                              return (
                                  <button 
                                    key={p.a} 
                                    onClick={() => handleMatchSelect('a', p.a)} 
                                    className={`w-full p-4 rounded-xl border-4 font-black transition-all ${isMatched ? 'bg-emerald-400 border-black opacity-40' : isSelected ? (matchError ? 'bg-rose-500 text-white animate-shake' : 'bg-indigo-600 text-white border-black scale-105') : 'bg-white border-slate-200 hover:border-black'}`}
                                  >
                                    {p.a}
                                  </button>
                              );
                          })}
                      </div>
                      <div className="space-y-3">
                          {(currentQ.pairs || []).map((p, idx) => {
                               const isMatched = matchedIndices.includes(idx);
                               const isSelected = matchingSelections.b === p.b;
                               return (
                                   <button 
                                    key={p.b} 
                                    onClick={() => handleMatchSelect('b', p.b)} 
                                    className={`w-full p-4 rounded-xl border-4 font-black transition-all ${isMatched ? 'bg-emerald-400 border-black opacity-40' : isSelected ? (matchError ? 'bg-rose-500 text-white animate-shake' : 'bg-indigo-600 text-white border-black scale-105') : 'bg-white border-slate-200 hover:border-black'}`}
                                   >
                                     {p.b}
                                   </button>
                               );
                          })}
                      </div>
                  </div>
              </div>
          ) : (
              <div className="w-full max-w-2xl text-center">
                  
                  {/* Binary Variant Card (Special Styling) */}
                  {currentQ.variant === 'BINARY' ? (
                      <div className="relative mb-8 w-full bg-[#1e1e1e] rounded-[3rem] p-4 md:p-6 border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)]">
                          {/* Accent bar at top */}
                          <div className={`absolute top-0 left-1/2 -translate-x-1/2 w-1/3 h-4 ${isSynonym ? 'bg-[#3b82f6]' : 'bg-orange-500'} rounded-b-xl z-0`}></div>
                          
                          {/* Inner White Box */}
                          <div className="relative bg-white rounded-[2rem] p-8 md:p-12 mt-4 flex flex-col items-center justify-center min-h-[250px]">
                              <div className={`px-5 py-2 rounded-full text-xs font-black uppercase tracking-widest mb-6 ${isSynonym ? 'bg-blue-100 text-blue-600' : 'bg-orange-100 text-orange-600'}`}>
                                  True or False?
                              </div>
                              
                              <h2 className="text-3xl md:text-5xl font-black text-slate-400 leading-tight">
                                  <span className={isSynonym ? "text-indigo-600" : "text-orange-600"}>{currentQ.target}</span> 
                                  <span className="text-slate-300 text-2xl md:text-3xl mx-3">is a {isSynonym ? 'synonym' : 'antonym'} of</span> 
                                  <span className={isSynonym ? "text-indigo-600" : "text-orange-600"}>{currentQ.secondWord}</span>
                              </h2>
                          </div>
                      </div>
                  ) : (
                      <div className="inline-block relative mb-8 w-full">
                           <div className="bg-white p-8 md:p-14 rounded-[3rem] border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] relative overflow-hidden group">
                               <div className={`absolute top-0 left-0 w-full h-4 ${theme.main}`}></div>
                               <div className="space-y-2">
                                   <p className="text-xs font-black text-slate-400 uppercase tracking-widest">{isSynonym ? 'Find Synonym' : 'Find Antonym'}</p>
                                   <h2 className="text-4xl md:text-7xl font-black text-slate-900 uppercase tracking-tighter">
                                       {currentQ.target || "LOADING..."}
                                   </h2>
                               </div>
                           </div>
                      </div>
                  )}

                  <div className={`grid gap-4 w-full ${currentQ.variant === 'BINARY' ? 'grid-cols-2 max-w-lg mx-auto' : 'grid-cols-1 md:grid-cols-2'}`}>
                      {currentOptions.map(opt => {
                          const isCorrect = opt === (currentQ.correctAnswer || (currentQ.variant === 'BINARY' ? 'True' : ''));
                          const isSelected = selectedOption === opt;
                          let btnStyle = "bg-white border-slate-200 text-slate-800 hover:border-black hover:-translate-y-1 hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]";
                          if (hasAnswered) {
                              if (isCorrect) btnStyle = "bg-emerald-400 border-black text-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]";
                              else if (isSelected) btnStyle = "bg-rose-400 border-black text-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]";
                              else btnStyle = "bg-slate-50 border-slate-100 text-slate-300 scale-95 opacity-50";
                          }
                          return (
                              <button 
                                key={opt} 
                                onClick={() => handleOptionClick(opt)} 
                                disabled={hasAnswered} 
                                className={`p-5 md:p-7 rounded-2xl border-4 text-2xl font-black uppercase transition-all ${btnStyle}`}
                              >
                                {opt}
                              </button>
                          );
                      })}
                  </div>
              </div>
          )}

          {hasAnswered && (
             <div className="w-full max-w-2xl mt-8 animate-slide-up flex flex-col items-center">
                 {/* Explanation Box */}
                 <div className="w-full bg-slate-50 border-2 border-slate-200 rounded-2xl p-6 mb-6 text-left shadow-sm">
                     <div className="flex items-center gap-2 mb-2">
                         <Info className="w-4 h-4 text-slate-400" />
                         <span className="text-xs font-black uppercase tracking-widest text-slate-500">Definition & Context</span>
                     </div>
                     <p className="text-slate-700 font-medium leading-relaxed">
                         {currentQ.explanation || "No explanation available."}
                     </p>
                 </div>

                 {/* Next Button - Centered below content */}
                 <button onClick={handleNext} className={`w-full md:w-auto px-12 py-4 ${theme.main} text-white rounded-2xl font-black text-xl uppercase tracking-widest border-4 border-black shadow-[6px_6px_0px_0px_rgba(0,0,0,0.5)] flex items-center justify-center gap-3 hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,0.5)] transition-all active:translate-y-0 active:shadow-none`}>
                     Next <ArrowRight className="w-6 h-6" />
                 </button>
             </div>
          )}
      </div>

      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-5px); }
          75% { transform: translateX(5px); }
        }
        .animate-shake {
          animation: shake 0.2s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

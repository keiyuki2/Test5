import React, { useState } from 'react';
import { Difficulty, GameMode, ReadingTopic, SessionStats, UserProfile, Language, DailyChallenge } from '../types';
import {
  BookOpen, Zap, BrainCircuit, PenTool, FileText, ArrowRight, FlaskConical, Landmark, Cpu,
  Users, Leaf, Palette, Mic, Target, Link, RefreshCw, Bomb,
  Headphones, MessageSquare, Map as MapIcon,
  ArrowLeft, Brain, GraduationCap, Calculator,
  Repeat, LayoutGrid, Settings
} from 'lucide-react';
import { sfx } from '../services/soundService';

interface MenuProps {
  onStart: (mode: GameMode, difficulty: Difficulty, topic?: string) => void;
  onEditProfile: () => void;
  stats: SessionStats;
  userProfile: UserProfile | null;
  lang: Language;
  dailyChallenges: DailyChallenge[];
  startTourOnMount?: boolean;
  onOpenSettings: () => void;
  onGameCardClick?: (mode: GameMode, diff: Difficulty, topic?: string) => void;
  onShowSubscription?: () => void;
}

// ── Neon-brutalist stripe background ────────────────────────────────────────
function StripeBg() {
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      <div className="absolute inset-0 bg-stone-50" />
      <div className="absolute -top-40 -right-40 w-[600px] h-[600px] opacity-[0.07]"
        style={{ background: 'repeating-linear-gradient(45deg, #f59e0b 0px, #f59e0b 12px, transparent 12px, transparent 36px)' }} />
      <div className="absolute -bottom-40 -left-40 w-[500px] h-[500px] opacity-[0.06]"
        style={{ background: 'repeating-linear-gradient(-45deg, #06b6d4 0px, #06b6d4 10px, transparent 10px, transparent 32px)' }} />
      <div className="absolute inset-0 opacity-[0.025]"
        style={{ backgroundImage: 'linear-gradient(#000 1px,transparent 1px),linear-gradient(90deg,#000 1px,transparent 1px)', backgroundSize: '40px 40px' }} />
    </div>
  );
}

// ── Section label ────────────────────────────────────────────────────────────
function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3 mb-6">
      <span className="text-[11px] font-black uppercase tracking-[0.25em] text-stone-400">{children}</span>
      <div className="flex-1 h-px bg-stone-200" />
    </div>
  );
}

// ── Arcade (Quick Practice) ──────────────────────────────────────────────────
function ArcadeMenu({ onBack, onStart, difficulty }: {
  onBack: () => void;
  onStart: (mode: GameMode, diff: Difficulty) => void;
  difficulty: Difficulty;
}) {
  const go = (mode: GameMode) => onStart(mode, difficulty);

  const sections = [
    {
      id: '01', title: 'Word Power',
      accent: 'bg-amber-400', border: 'border-amber-500',
      items: [
        { mode: GameMode.LEXICAL_ECHO,    icon: Repeat,      title: 'Echo',      desc: 'Forced recall — define from memory', tag: 'Hard' },
        { mode: GameMode.SYNAPTIC_BRIDGE, icon: Zap,         title: 'Bridge',    desc: 'Passive → active vocabulary shift',  tag: 'Hard' },
        { mode: GameMode.VOCABULARY,      icon: BrainCircuit,title: 'Vocab',     desc: 'Learn Band 8–9 definitions',         tag: 'Medium' },
        { mode: GameMode.COLLOCATION,     icon: Link,        title: 'Collocate', desc: 'Identify natural word pairings',     tag: 'Easy' },
      ],
    },
    {
      id: '02', title: 'Listening & Space',
      accent: 'bg-cyan-400', border: 'border-cyan-500',
      items: [
        { mode: GameMode.DICTATION,   icon: Headphones,   title: 'Dictation', desc: 'Transcription under pressure',    tag: 'Medium' },
        { mode: GameMode.TONE,        icon: MessageSquare,title: 'Register',  desc: 'Formal vs informal shifts',      tag: 'Easy' },
        { mode: GameMode.MAP,         icon: MapIcon,       title: 'Spatial',   desc: 'Navigate complex map questions', tag: 'Medium' },
        { mode: GameMode.PRONUNCIATION,icon: Mic,          title: 'Phonetics', desc: 'Accent & pronunciation coach',   tag: 'Easy' },
      ],
    },
    {
      id: '03', title: 'Logic & Style',
      accent: 'bg-fuchsia-400', border: 'border-fuchsia-500',
      items: [
        { mode: GameMode.HEADING_MATCH, icon: LayoutGrid,  title: 'Headings', desc: 'Match paragraphs to headings',  tag: 'Hard' },
        { mode: GameMode.STYLE_TRANSFER,icon: PenTool,     title: 'Transform',desc: 'Rewrite casual → academic',     tag: 'Medium' },
        { mode: GameMode.IDIOM,         icon: Bomb,        title: 'Idioms',   desc: 'Native-level expressions',      tag: 'Hard' },
        { mode: GameMode.SYNONYM,       icon: RefreshCw,   title: 'Synonyms', desc: 'Build your paraphrase toolkit', tag: 'Easy' },
      ],
    },
  ];

  const tagColors: Record<string, string> = {
    Easy: 'bg-lime-400 text-black border-lime-600',
    Medium: 'bg-amber-400 text-black border-amber-600',
    Hard: 'bg-rose-500 text-white border-rose-700',
  };

  return (
    <div className="min-h-screen bg-stone-50 relative" style={{ fontFamily: "'Inter', sans-serif" }}>
      <StripeBg />
      <div className="relative z-10 max-w-6xl mx-auto px-6 md:px-10 py-8">

        {/* Header */}
        <div className="flex items-center gap-5 mb-10">
          <button onClick={onBack}
            className="w-12 h-12 bg-white border-4 border-black rounded-xl flex items-center justify-center shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:translate-x-0.5 hover:translate-y-0.5 hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <p className="text-[10px] font-black uppercase tracking-[0.25em] text-stone-400">Quick Practice</p>
            <h1 className="text-4xl md:text-5xl font-black uppercase tracking-tighter leading-none text-stone-900">
              Drill <span className="text-fuchsia-500">Arcade</span>
            </h1>
          </div>
        </div>

        {/* Sections */}
        <div className="space-y-14">
          {sections.map(sec => (
            <div key={sec.id}>
              {/* Section header */}
              <div className="flex items-center gap-4 mb-6">
                <div className={`${sec.accent} border-4 border-black rounded-xl px-4 py-2 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]`}>
                  <span className="font-black text-xs uppercase tracking-widest text-black">{sec.id} — {sec.title}</span>
                </div>
                <div className="flex-1 h-px bg-stone-200" />
              </div>

              {/* Cards grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                {sec.items.map(item => (
                  <button key={item.mode} onClick={() => { sfx.select(); go(item.mode); }}
                    className="group flex flex-col bg-white border-4 border-black rounded-2xl p-5 text-left shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1.5 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all">
                    <div className={`w-10 h-10 ${sec.accent} border-4 border-black rounded-xl flex items-center justify-center mb-4 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] group-hover:rotate-6 transition-transform`}>
                      <item.icon className="w-5 h-5 text-black" />
                    </div>
                    <div className={`inline-flex text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded border-2 mb-3 ${tagColors[item.tag]}`}>
                      {item.tag}
                    </div>
                    <p className="font-black text-base uppercase tracking-tight text-stone-900 mb-1">{item.title}</p>
                    <p className="text-xs text-stone-500 font-medium leading-snug flex-1">{item.desc}</p>
                    <div className="mt-4 flex items-center gap-1.5 text-[11px] font-black uppercase tracking-widest text-stone-400 group-hover:text-stone-900 transition-colors">
                      Start <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Main Menu ────────────────────────────────────────────────────────────────
export const Menu: React.FC<MenuProps> = ({
  onStart, onEditProfile, stats, userProfile, lang, dailyChallenges, onOpenSettings
}) => {
  const [isReadingModeSelected, setIsReadingModeSelected] = useState(false);
  const [showArcade, setShowArcade] = useState(false);

  const diff = userProfile?.proficiencyLevel || Difficulty.MEDIUM;
  const go = (mode: GameMode) => {
    sfx.select();
    if (mode === GameMode.READING && !onGameCardClick) { setIsReadingModeSelected(true); return; }
    if (onGameCardClick) { onGameCardClick(mode, diff); return; }
    onStart(mode, diff);
  };

  // ── Reading topic picker ─────────────────────────────────────────────────
  if (isReadingModeSelected) {
    const topics = [
      { t: ReadingTopic.SCIENCE,     icon: FlaskConical, bg: 'bg-rose-400',    label: 'Science' },
      { t: ReadingTopic.HISTORY,     icon: Landmark,     bg: 'bg-amber-400',   label: 'History' },
      { t: ReadingTopic.TECHNOLOGY,  icon: Cpu,          bg: 'bg-cyan-400',    label: 'Technology' },
      { t: ReadingTopic.SOCIETY,     icon: Users,        bg: 'bg-lime-400',    label: 'Society' },
      { t: ReadingTopic.ENVIRONMENT, icon: Leaf,         bg: 'bg-emerald-400', label: 'Environment' },
      { t: ReadingTopic.ART,         icon: Palette,      bg: 'bg-fuchsia-400', label: 'Art & Culture' },
    ];
    return (
      <div className="min-h-screen bg-stone-50 relative" style={{ fontFamily: "'Inter', sans-serif" }}>
        <StripeBg />
        <div className="relative z-10 max-w-5xl mx-auto px-6 md:px-10 py-10">
          <div className="flex items-center gap-5 mb-10">
            <button onClick={() => { sfx.back(); setIsReadingModeSelected(false); }}
              className="w-12 h-12 bg-white border-4 border-black rounded-xl flex items-center justify-center shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:translate-x-0.5 hover:translate-y-0.5 hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all">
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.25em] text-stone-400">Reading</p>
              <h1 className="text-4xl font-black uppercase tracking-tighter text-stone-900">Pick a <span className="text-cyan-500">Topic</span></h1>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-5">
            {topics.map(({ t, icon: Icon, bg, label }) => (
              <button key={t} onClick={() => { sfx.select(); onStart(GameMode.READING, diff, t); }}
                className={`group relative ${bg} border-4 border-black rounded-2xl p-6 text-left shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1.5 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all overflow-hidden`}>
                <Icon className="absolute -right-4 -bottom-4 w-24 h-24 opacity-15 text-black group-hover:opacity-25 transition-opacity" />
                <div className="w-12 h-12 bg-white border-4 border-black rounded-xl flex items-center justify-center mb-4 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] group-hover:rotate-6 transition-transform">
                  <Icon className="w-6 h-6 text-black" />
                </div>
                <p className="font-black text-base uppercase tracking-tight text-black">{label}</p>
                <div className="mt-3 w-8 h-1 bg-black rounded-full group-hover:w-14 transition-all duration-300" />
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ── Arcade ───────────────────────────────────────────────────────────────
  if (showArcade) {
    return <ArcadeMenu onBack={() => setShowArcade(false)} onStart={onStart} difficulty={diff} />;
  }

  // ── Main dashboard ───────────────────────────────────────────────────────
  const mainCards = [
    { mode: GameMode.READING,   bg: 'bg-cyan-400',    icon: BookOpen,     label: 'Reading',   sub: 'Comprehension',  size: 'md:col-span-6' },
    { mode: GameMode.LISTENING, bg: 'bg-rose-500',    icon: Headphones,   label: 'Listening', sub: 'Audio tests',    size: 'md:col-span-6' },
    { mode: GameMode.WRITING,   bg: 'bg-fuchsia-500', icon: FileText,     label: 'Writing',   sub: 'Task 1 & 2',     size: 'md:col-span-4' },
    { mode: GameMode.SPEAKING,  bg: 'bg-amber-400',   icon: Mic,          label: 'Speaking',  sub: 'Cue cards',      size: 'md:col-span-4' },
  ];

  return (
    <div className="min-h-screen bg-stone-50 relative" style={{ fontFamily: "'Inter', sans-serif" }}>
      <StripeBg />
      <div className="relative z-10 max-w-6xl mx-auto px-6 md:px-10 py-8">

        {/* ── Welcome bar ─────────────────────────────────────────────── */}
        <div className="flex items-center justify-between mb-10">
          <div>
            <p className="text-[10px] font-black uppercase tracking-[0.25em] text-stone-500 mb-1">Dashboard</p>
            <h1 className="text-3xl md:text-4xl font-black uppercase tracking-tighter text-stone-900 leading-tight">
              Hey, <span className="text-amber-500">{userProfile?.name?.split(' ')[0] || 'Student'}</span>
            </h1>
            <p className="text-sm text-stone-500 font-medium mt-1">
              Level: <span className="font-bold text-stone-700">{userProfile?.proficiencyLevel}</span>
              <span className="mx-2 text-stone-300">·</span>
              Target: <span className="font-bold text-stone-700">Band {userProfile?.targetBand || '9.0'}</span>
            </p>
          </div>
          <button onClick={() => { sfx.click(); onOpenSettings(); }}
            className="w-11 h-11 bg-white border-4 border-black rounded-xl flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:translate-x-0.5 hover:translate-y-0.5 hover:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] transition-all">
            <Settings className="w-5 h-5 text-stone-700" />
          </button>
        </div>

        {/* ── Separator ───────────────────────────────────────────────── */}
        <div className="h-px bg-stone-200 mb-8" />

        {/* ── Main lessons ────────────────────────────────────────────── */}
        <SectionLabel>Core Skills</SectionLabel>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 mb-5">
          {mainCards.map(card => (
            <button key={card.mode} onClick={() => go(card.mode)}
              className={`${card.size} group relative ${card.bg} border-4 border-black rounded-2xl p-6 text-left shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1.5 hover:shadow-[9px_9px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all overflow-hidden min-h-[180px] flex flex-col justify-between`}>
              {/* Icon */}
              <div className="w-14 h-14 bg-white border-4 border-black rounded-xl flex items-center justify-center shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] group-hover:rotate-6 transition-transform flex-shrink-0">
                <card.icon className="w-7 h-7 text-black" />
              </div>
              {/* Label */}
              <div>
                <p className="font-black text-2xl uppercase tracking-tight text-black leading-tight">{card.label}</p>
                <p className="text-[11px] font-bold text-black/60 uppercase tracking-widest mt-0.5">{card.sub}</p>
              </div>
              {/* Arrow */}
              <ArrowRight className="absolute bottom-5 right-5 w-5 h-5 text-black/40 group-hover:text-black group-hover:translate-x-1 transition-all" />
            </button>
          ))}

          {/* Quick Drills card */}
          <button onClick={() => setShowArcade(true)}
            className="md:col-span-4 group relative bg-stone-900 border-4 border-black rounded-2xl p-6 text-left shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1.5 hover:shadow-[9px_9px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all overflow-hidden min-h-[180px] flex flex-col justify-between">
            {/* Stripe accent */}
            <div className="absolute inset-0 overflow-hidden rounded-xl">
              <div className="absolute -top-8 -right-8 w-32 h-32 bg-amber-400 rounded-full opacity-20 group-hover:opacity-30 transition-opacity" />
              <div className="absolute -bottom-8 -left-8 w-24 h-24 bg-fuchsia-400 rounded-full opacity-20 group-hover:opacity-30 transition-opacity" />
            </div>
            <div className="relative z-10">
              <div className="w-14 h-14 bg-amber-400 border-4 border-white/20 rounded-xl flex items-center justify-center shadow-[4px_4px_0px_0px_rgba(255,255,255,0.15)] mb-auto group-hover:rotate-6 transition-transform">
                <Zap className="w-7 h-7 text-black" />
              </div>
            </div>
            <div className="relative z-10">
              <p className="font-black text-2xl uppercase tracking-tight text-white leading-tight">Quick<br/>Drills</p>
              <p className="text-[11px] font-bold text-white/50 uppercase tracking-widest mt-0.5">12 mini-games</p>
            </div>
            <ArrowRight className="absolute bottom-5 right-5 w-5 h-5 text-white/30 group-hover:text-white group-hover:translate-x-1 transition-all" />
          </button>
        </div>

        {/* ── Separator ───────────────────────────────────────────────── */}
        <div className="h-px bg-stone-200 my-8" />

        {/* ── Full Mock Exam ───────────────────────────────────────────── */}
        <SectionLabel>Full Test</SectionLabel>

        <button onClick={() => onStart(GameMode.MOCK_EXAM, diff)}
          className="w-full group flex items-center justify-between gap-6 bg-white border-4 border-black rounded-2xl p-6 md:p-8 shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all text-left mb-8">
          <div className="flex items-center gap-5">
            <div className="w-14 h-14 bg-stone-900 border-4 border-black rounded-xl flex items-center justify-center flex-shrink-0 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] group-hover:rotate-3 transition-transform">
              <GraduationCap className="w-7 h-7 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="bg-rose-500 text-white text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded border-2 border-black">Full Simulation</span>
                <span className="text-stone-400 text-[11px] font-bold uppercase">2.5 hours</span>
              </div>
              <h3 className="text-xl md:text-2xl font-black uppercase tracking-tight text-stone-900">IELTS Mock Exam</h3>
              <p className="text-xs text-stone-500 font-medium mt-0.5">4 sections with strict timing and band-score report</p>
            </div>
          </div>
          <div className="flex-shrink-0 bg-stone-900 text-white px-5 py-3 rounded-xl border-4 border-black font-black uppercase text-xs tracking-widest flex items-center gap-2 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] group-hover:bg-amber-400 group-hover:text-black transition-colors">
            Begin <ArrowRight className="w-4 h-4" />
          </div>
        </button>

        {/* ── Separator ───────────────────────────────────────────────── */}
        <div className="h-px bg-stone-200 my-8" />

        {/* ── SAT Banner ──────────────────────────────────────────────── */}
        <SectionLabel>Other Programs</SectionLabel>

        <button onClick={() => onStart(GameMode.SAT_DASHBOARD, Difficulty.MEDIUM)}
          className="w-full group flex items-center justify-between gap-6 bg-amber-400 border-4 border-black rounded-2xl p-6 shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all text-left overflow-hidden relative">
          <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-10"
            style={{ background: 'repeating-linear-gradient(45deg, #000 0px, #000 6px, transparent 6px, transparent 18px)' }} />
          <div className="flex items-center gap-5 relative z-10">
            <div className="w-14 h-14 bg-white border-4 border-black rounded-xl flex items-center justify-center flex-shrink-0 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] group-hover:rotate-6 transition-transform">
              <Calculator className="w-7 h-7 text-amber-600" />
            </div>
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-black/60 mb-0.5">SAT Prep Mode</p>
              <h3 className="text-xl font-black uppercase tracking-tight text-black">Math & Reading</h3>
              <p className="text-xs font-bold text-black/60 mt-0.5">Whiteboard · Calculator · Practice sets</p>
            </div>
          </div>
          <div className="relative z-10 flex-shrink-0 bg-black text-white px-5 py-3 rounded-xl border-4 border-black font-black uppercase text-xs tracking-widest flex items-center gap-2 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] group-hover:bg-white group-hover:text-black transition-colors">
            Switch <ArrowRight className="w-4 h-4" />
          </div>
        </button>

      </div>
    </div>
  );
};

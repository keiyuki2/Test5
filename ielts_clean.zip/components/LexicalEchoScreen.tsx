
import React, { useState, useEffect } from 'react';
import { EchoQuestion, EchoFeedback, Difficulty } from '../types';
import { evaluateEcho } from '../services/geminiService';
import { 
    Terminal, Send, Sparkles, RefreshCw, ArrowRight, Lightbulb, 
    Activity, ShieldCheck, Volume2, Info, Check, X,
    Eye, BrainCircuit, Target, BookOpen, Layers
} from 'lucide-react';

interface LexicalEchoScreenProps {
  questions: EchoQuestion[];
  difficulty: Difficulty;
  onComplete: () => void;}

type Phase = 'STUDY' | 'GAME' | 'FEEDBACK';

export const LexicalEchoScreen: React.FC<LexicalEchoScreenProps> = ({ 
  questions, 
  difficulty, 
  onComplete
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [phase, setPhase] = useState<Phase>('STUDY');
  const [userDefinition, setUserDefinition] = useState('');
  const [feedback, setFeedback] = useState<EchoFeedback | null>(null);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [showHint, setShowHint] = useState(false);

  const currentQ = questions[currentIndex];

  useEffect(() => {
      // Reset state for new question
      setPhase('STUDY');
      setUserDefinition('');
      setFeedback(null);
      setShowHint(false);
      setIsEvaluating(false);
  }, [currentIndex]);

  const handleSpeak = (text: string) => {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = 'en-GB';
      u.rate = 0.9;
      window.speechSynthesis.speak(u);
  };

  const handleStartGame = () => {
      setPhase('GAME');
  };

  const handleSubmit = async () => {
      if (!userDefinition.trim() || isEvaluating) return;
      setIsEvaluating(true);
      try {
          const fb = await evaluateEcho(currentQ, userDefinition);
          setFeedback(fb);
          setPhase('FEEDBACK');
      } catch (e) {
          console.error(e);
      } finally {
          setIsEvaluating(false);
      }
  };

  const handleNext = () => {
      if (currentIndex < questions.length - 1) {
          setCurrentIndex(prev => prev + 1);
      } else {
          onComplete();
      }
  };

  const handleHint = () => {
      if (!showHint) { setShowHint(true); }
  };

  if (!currentQ) return null;

  // --- STUDY PHASE UI ---
  if (phase === 'STUDY') {
      return (
          <div className="w-full max-w-4xl mx-auto py-12 px-6 animate-slide-up flex flex-col h-[calc(100vh-100px)]">
              {/* Phase Header */}
              <div className="flex justify-between items-end mb-8 border-b-4 border-black pb-4">
                  <div>
                      <h2 className="text-4xl md:text-5xl font-black text-slate-900 uppercase tracking-tighter italic">
                          Study <span className="text-indigo-600">Phase</span>
                      </h2>
                      <p className="text-slate-500 font-bold uppercase tracking-widest text-xs mt-2">
                          Mission {currentIndex + 1} / {questions.length}
                      </p>
                  </div>
                  <div className="bg-black text-white px-4 py-2 rounded-xl font-black uppercase text-xs tracking-widest flex items-center gap-2 shadow-[4px_4px_0px_0px_rgba(0,0,0,0.3)]">
                      <BrainCircuit className="w-4 h-4" /> Acquisition
                  </div>
              </div>

              {/* Study Card */}
              <div className="flex-1 bg-white rounded-[3rem] border-4 border-black shadow-[16px_16px_0px_0px_rgba(0,0,0,1)] relative overflow-hidden flex flex-col group">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-bl-[100%] z-0 group-hover:scale-150 transition-transform duration-700"></div>
                  
                  <div className="p-8 md:p-12 relative z-10 flex flex-col h-full">
                      <div className="flex flex-col md:flex-row justify-between items-start gap-6 mb-8">
                          <div>
                              <div className="flex items-center gap-4 mb-2">
                                  <h1 className="text-5xl md:text-7xl font-black text-slate-900 tracking-tighter leading-none capitalize">
                                      {currentQ.word}
                                  </h1>
                                  <button onClick={() => handleSpeak(currentQ.word)} className="p-3 bg-indigo-100 rounded-full border-2 border-black hover:bg-indigo-200 transition-colors shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-y-0.5 active:shadow-none">
                                      <Volume2 className="w-6 h-6 text-indigo-900" />
                                  </button>
                              </div>
                              <span className="font-mono text-lg font-bold text-slate-500 bg-slate-100 px-3 py-1 rounded border border-slate-300 inline-block">
                                  {currentQ.phonetic}
                              </span>
                          </div>
                          
                          <div className="bg-yellow-300 px-4 py-2 rounded-lg border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transform rotate-2">
                              <span className="font-black text-xs uppercase tracking-widest text-black">Target Lexis</span>
                          </div>
                      </div>

                      <div className="flex-1 space-y-8">
                          <div className="bg-slate-50 p-6 rounded-2xl border-2 border-black">
                              <h3 className="text-xs font-black uppercase tracking-widest text-slate-400 mb-3 flex items-center gap-2">
                                  <BookOpen className="w-4 h-4" /> Definition
                              </h3>
                              <p className="text-xl md:text-2xl font-bold text-slate-900 leading-snug">
                                  {currentQ.fullDefinition}
                              </p>
                          </div>

                          <div className="p-6 rounded-2xl border-2 border-dashed border-slate-300">
                              <h3 className="text-xs font-black uppercase tracking-widest text-slate-400 mb-3 flex items-center gap-2">
                                  <Layers className="w-4 h-4" /> Context
                              </h3>
                              <p className="text-lg font-medium text-slate-700 italic leading-relaxed">
                                  "{currentQ.context}"
                              </p>
                          </div>
                      </div>

                      <div className="mt-8 flex justify-end">
                          <button 
                              onClick={handleStartGame}
                              className="group relative px-10 py-5 bg-black text-white text-xl font-black uppercase tracking-widest rounded-2xl shadow-[8px_8px_0px_0px_rgba(79,70,229,1)] hover:shadow-[12px_12px_0px_0px_rgba(79,70,229,1)] hover:-translate-y-1 transition-all active:translate-y-0 active:shadow-none flex items-center gap-4 overflow-hidden"
                          >
                              <span className="relative z-10">Start Challenge</span>
                              <ArrowRight className="w-6 h-6 relative z-10 group-hover:translate-x-2 transition-transform" />
                              <div className="absolute inset-0 bg-indigo-600 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
                          </button>
                      </div>
                  </div>
              </div>
          </div>
      );
  }

  // --- GAME PHASE UI ---
  if (phase === 'GAME') {
      return (
          <div className="w-full max-w-4xl mx-auto py-12 px-6 animate-slide-up flex flex-col h-[calc(100vh-100px)]">
              {/* Phase Header */}
              <div className="flex justify-between items-end mb-8 border-b-4 border-black pb-4">
                  <div>
                      <h2 className="text-4xl md:text-5xl font-black text-slate-900 uppercase tracking-tighter italic">
                          Game <span className="text-rose-500">Phase</span>
                      </h2>
                      <p className="text-slate-500 font-bold uppercase tracking-widest text-xs mt-2">
                          Recall & Define
                      </p>
                  </div>
                  <div className="bg-black text-white px-4 py-2 rounded-xl font-black uppercase text-xs tracking-widest flex items-center gap-2 shadow-[4px_4px_0px_0px_rgba(0,0,0,0.3)]">
                      <Target className="w-4 h-4" /> Active Recall
                  </div>
              </div>

              {/* Game Terminal */}
              <div className="flex-1 bg-slate-900 rounded-[3rem] border-4 border-black shadow-[16px_16px_0px_0px_rgba(0,0,0,1)] flex flex-col overflow-hidden relative">
                  {/* Word Display */}
                  <div className="bg-slate-800 p-8 border-b-4 border-black flex justify-between items-center">
                      <div>
                          <p className="text-slate-400 text-xs font-black uppercase tracking-widest mb-1">Target</p>
                          <h1 className="text-4xl font-black text-white tracking-tight">{currentQ.word}</h1>
                      </div>
                      {/* Hint Button */}
                      <button 
                          onClick={handleHint}
                          disabled={showHint}
                          className={`p-3 rounded-xl border-2 transition-all ${showHint ? 'bg-yellow-400 border-yellow-400 text-black' : 'bg-transparent border-slate-600 text-slate-400 hover:text-white hover:border-white'}`}
                      >
                          <Lightbulb className={`w-6 h-6 ${showHint ? 'fill-current' : ''}`} />
                      </button>
                  </div>

                  {/* Input Area */}
                  <div className="flex-1 bg-black p-8 relative">
                      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
                      
                      <div className="flex items-start gap-4 h-full relative z-10">
                          <Terminal className="w-6 h-6 text-emerald-500 mt-2 flex-none" />
                          <textarea 
                              value={userDefinition}
                              onChange={(e) => setUserDefinition(e.target.value)}
                              placeholder="Type the definition in your own words..."
                              className="w-full h-full bg-transparent border-none outline-none text-xl md:text-2xl font-bold text-emerald-500 placeholder:text-emerald-900/50 font-mono resize-none leading-relaxed"
                              autoFocus
                              disabled={isEvaluating}
                          />
                      </div>
                  </div>

                  {/* Hint Display */}
                  {showHint && (
                      <div className="bg-yellow-400/10 border-t-2 border-yellow-500/30 p-4 animate-scale-in">
                          <p className="text-yellow-400 text-xs font-black uppercase tracking-widest mb-1">Key Anchors</p>
                          <div className="flex gap-2">
                              {currentQ.keyAnchors.map((anchor, i) => (
                                  <span key={i} className="px-2 py-1 bg-yellow-400/20 text-yellow-300 rounded text-xs font-bold border border-yellow-400/30">{anchor}</span>
                              ))}
                          </div>
                      </div>
                  )}

                  {/* Footer Actions */}
                  <div className="bg-slate-800 p-6 border-t-4 border-black flex justify-end">
                      <button 
                          onClick={handleSubmit}
                          disabled={!userDefinition.trim() || isEvaluating}
                          className="bg-emerald-500 text-black px-10 py-4 rounded-xl font-black uppercase tracking-widest text-lg shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[10px_10px_0px_0px_rgba(0,0,0,1)] hover:bg-emerald-400 transition-all active:translate-y-0 active:shadow-none disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-3"
                      >
                          {isEvaluating ? <RefreshCw className="animate-spin w-5 h-5" /> : <Send className="w-5 h-5" />} Submit
                      </button>
                  </div>
              </div>
          </div>
      );
  }

  // --- FEEDBACK PHASE UI ---
  if (phase === 'FEEDBACK' && feedback) {
      return (
          <div className="w-full max-w-4xl mx-auto py-12 px-6 animate-slide-up">
              {/* Score Header */}
              <div className="bg-white rounded-[3rem] border-4 border-black shadow-[16px_16px_0px_0px_rgba(0,0,0,1)] overflow-hidden mb-10">
                  <div className={`p-10 text-center border-b-4 border-black ${feedback.score >= 70 ? 'bg-emerald-400' : 'bg-rose-400'}`}>
                      <div className="inline-block bg-black text-white px-6 py-2 rounded-full font-black uppercase text-sm tracking-widest mb-6 shadow-lg">
                          Accuracy Assessment
                      </div>
                      <h2 className="text-8xl font-black text-black tracking-tighter leading-none mb-2 drop-shadow-sm">
                          {feedback.score}%
                      </h2>
                      <p className="text-black/70 font-bold text-lg uppercase tracking-wide">Semantic Match</p>
                  </div>

                  <div className="p-8 md:p-12">
                      <div className="flex flex-col md:flex-row gap-12 mb-12">
                          <div className="flex-1">
                              <h3 className="text-xs font-black uppercase tracking-widest text-slate-400 mb-4 flex items-center gap-2">
                                  <ShieldCheck className="w-4 h-4" /> Analysis
                              </h3>
                              <p className="text-lg font-medium text-slate-800 leading-relaxed border-l-4 border-slate-200 pl-4">
                                  {feedback.analysis}
                              </p>
                          </div>
                          <div className="w-full md:w-72 bg-slate-50 p-6 rounded-2xl border-2 border-slate-200">
                              <h3 className="text-xs font-black uppercase tracking-widest text-slate-400 mb-4">Refined Definition</h3>
                              <p className="text-sm font-bold text-slate-700 leading-relaxed italic">
                                  "{feedback.refinedDefinition}"
                              </p>
                          </div>
                      </div>

                      {/* Anchors Check */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                          <div className="bg-emerald-50 rounded-2xl p-6 border-2 border-emerald-100">
                              <h4 className="text-emerald-700 font-black uppercase text-xs tracking-widest mb-4 flex items-center gap-2">
                                  <Check className="w-4 h-4" /> Captured Concepts
                              </h4>
                              <div className="flex flex-wrap gap-2">
                                  {feedback.matchedAnchors.length > 0 ? (
                                      feedback.matchedAnchors.map((a, i) => (
                                          <span key={i} className="px-3 py-1 bg-emerald-200 text-emerald-900 rounded-lg text-sm font-bold border border-emerald-300">{a}</span>
                                      ))
                                  ) : (
                                      <span className="text-emerald-400 text-sm italic">None detected</span>
                                  )}
                              </div>
                          </div>
                          <div className="bg-rose-50 rounded-2xl p-6 border-2 border-rose-100">
                              <h4 className="text-rose-700 font-black uppercase text-xs tracking-widest mb-4 flex items-center gap-2">
                                  <X className="w-4 h-4" /> Missed Concepts
                              </h4>
                              <div className="flex flex-wrap gap-2">
                                  {feedback.missedAnchors.length > 0 ? (
                                      feedback.missedAnchors.map((a, i) => (
                                          <span key={i} className="px-3 py-1 bg-rose-200 text-rose-900 rounded-lg text-sm font-bold border border-rose-300">{a}</span>
                                      ))
                                  ) : (
                                      <span className="text-rose-400 text-sm italic">None! Perfect recall.</span>
                                  )}
                              </div>
                          </div>
                      </div>

                      <button 
                          onClick={handleNext}
                          className="w-full py-5 bg-black text-white rounded-2xl font-black text-xl uppercase tracking-widest shadow-[6px_6px_0px_0px_rgba(0,0,0,0.5)] hover:shadow-[10px_10px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 transition-all active:translate-y-0 active:shadow-none flex items-center justify-center gap-3"
                      >
                          {currentIndex < questions.length - 1 ? 'Next Mission' : 'Complete Session'} <ArrowRight className="w-6 h-6" />
                      </button>
                  </div>
              </div>
          </div>
      );
  }

  return null;
};

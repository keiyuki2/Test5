import React, { useState, useEffect } from 'react'
import {
  X, Zap, Shield, Skull, Volume2, Globe, Info, Bell,
  ChevronRight, Palette, BookOpen, Moon, Sun, MessageSquare,
  Send, Check, VolumeX
} from 'lucide-react'
import { Difficulty, UserProfile } from '../types'
import { Badge } from './ui/badge'
import { Textarea } from './ui/textarea'
import { sfx, setSoundMuted, getSoundMuted } from '../services/soundService'

interface Props {
  onClose: () => void
  difficulty: Difficulty
  onDifficultyChange: (d: Difficulty) => void
  userProfile?: UserProfile | null
  onProfileUpdate?: (p: UserProfile) => void
}

type Tab = 'gameplay' | 'audio' | 'notifications' | 'appearance' | 'feedback' | 'about'

const TABS: { id: Tab; label: string; icon: any }[] = [
  { id: 'gameplay',      label: 'Gameplay',     icon: Zap           },
  { id: 'audio',         label: 'Audio',         icon: Volume2       },
  { id: 'notifications', label: 'Notifications', icon: Bell          },
  { id: 'appearance',    label: 'Appearance',    icon: Palette       },
  { id: 'feedback',      label: 'Feedback',      icon: MessageSquare },
  { id: 'about',         label: 'About',         icon: Info          },
]

const DIFFS = [
  { level: Difficulty.FOUNDATION, label: 'Foundation', sub: 'Absolute beginners · Band 1–4', icon: Shield, color: 'bg-cyan-400'  },
  { level: Difficulty.EASY,       label: 'Easy',       sub: 'Elementary · Band 4–5',         icon: Shield, color: 'bg-lime-400'  },
  { level: Difficulty.MEDIUM,     label: 'Medium',     sub: 'Pre-intermediate · Band 5–7',   icon: Zap,    color: 'bg-amber-400' },
  { level: Difficulty.HARD,       label: 'Hard',       sub: 'Advanced learners · Band 7+',   icon: Skull,  color: 'bg-rose-500'  },
]

// ── Persistent settings stored in localStorage ────────────────────────────────
const SETTINGS_KEY = 'ielts_settings'
interface SavedSettings {
  soundEnabled: boolean
  volume: number
  notifStreak: boolean
  notifDaily: boolean
  notifResults: boolean
  language: 'EN' | 'MN'
  fontSize: 'small' | 'medium' | 'large'
}
const DEFAULT_SETTINGS: SavedSettings = {
  soundEnabled: true, volume: 80,
  notifStreak: true, notifDaily: true, notifResults: false,
  language: 'EN', fontSize: 'medium',
}
function loadSettings(): SavedSettings {
  try { return { ...DEFAULT_SETTINGS, ...JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}') } }
  catch { return DEFAULT_SETTINGS }
}
function saveSettings(s: SavedSettings) { localStorage.setItem(SETTINGS_KEY, JSON.stringify(s)) }

// ── Toggle component ──────────────────────────────────────────────────────────
function Toggle({ on, onChange }: { on: boolean; onChange: () => void }) {
  return (
    <button onClick={onChange}
      className={`relative w-11 h-6 rounded-full border-2 border-black transition-colors shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] flex-shrink-0 ${on ? 'bg-lime-400' : 'bg-stone-200'}`}>
      <span className={`absolute top-0.5 w-4 h-4 bg-white border-2 border-black rounded-full transition-all duration-200 ${on ? 'left-5' : 'left-0.5'}`} />
    </button>
  )
}

function SettingRow({ label, sub, right }: { label: string; sub?: string; right: React.ReactNode }) {
  return (
    <div className="flex items-center gap-4 px-4 py-3.5 border-b border-stone-100 last:border-0">
      <div className="flex-1 min-w-0">
        <p className="text-sm font-bold text-stone-900">{label}</p>
        {sub && <p className="text-xs text-stone-400 font-medium mt-0.5">{sub}</p>}
      </div>
      {right}
    </div>
  )
}

export const GameSettingsModal: React.FC<Props> = ({ onClose, difficulty, onDifficultyChange, userProfile, onProfileUpdate }) => {
  const [tab, setTab] = useState<Tab>('gameplay')
  const [settings, setSettings] = useState<SavedSettings>(loadSettings)
  const [feedbackText, setFeedbackText] = useState('')
  const [feedbackSent, setFeedbackSent] = useState(false)

  // Apply settings on change
  const update = (partial: Partial<SavedSettings>) => {
    const next = { ...settings, ...partial }
    setSettings(next)
    saveSettings(next)

    // Actually apply them
    if ('soundEnabled' in partial) {
      setSoundMuted(!partial.soundEnabled!)
      if (partial.soundEnabled) sfx.click()
    }
    if ('volume' in partial) {
      // Volume affects the gain — stored for future audio sessions
    }
    if ('fontSize' in partial) {
      const sizes: Record<string, string> = { small: '14px', medium: '16px', large: '18px' }
      document.documentElement.style.fontSize = sizes[partial.fontSize!] || '16px'
    }
  }

  const toggleDarkMode = () => {
    if (!userProfile || !onProfileUpdate) return
    const next = !userProfile.darkMode
    const updated = { ...userProfile, darkMode: next }
    onProfileUpdate(updated)
    sfx.click()
    if (next) {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }

  const isDark = userProfile?.darkMode ?? false

  // Sync muted state on mount
  useEffect(() => {
    setSoundMuted(!settings.soundEnabled)
  }, [])

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center" style={{ fontFamily: "'Inter',sans-serif" }}>
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose} />

      <div className="relative w-full max-w-2xl h-[580px] flex rounded-2xl border-4 border-black overflow-hidden shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">

        {/* ── Left nav ────────────────────────────────────────────────── */}
        <div className="w-[200px] flex-shrink-0 bg-stone-100 border-r-4 border-black flex flex-col">
          <div className="px-3 pt-5 pb-3">
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-400 mb-2 px-2">Settings</p>
            {TABS.map(t => (
              <button key={t.id} onClick={() => { sfx.click(); setTab(t.id) }}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm font-bold transition-all mb-0.5
                  ${tab === t.id
                    ? 'bg-stone-900 text-white shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] border-2 border-black'
                    : 'text-stone-500 hover:bg-stone-200 hover:text-stone-900 border-2 border-transparent'}`}>
                <t.icon className="w-4 h-4 flex-shrink-0" />
                {t.label}
              </button>
            ))}
          </div>
          <div className="mt-auto px-3 pb-4">
            <div className="h-px bg-stone-200 mb-3" />
            <button onClick={() => { sfx.back(); onClose() }}
              className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-sm font-bold text-stone-400 hover:text-stone-700 hover:bg-stone-200 transition-all border-2 border-transparent">
              <X className="w-4 h-4" /> Close
            </button>
          </div>
        </div>

        {/* ── Right content ────────────────────────────────────────────── */}
        <div className="flex-1 bg-white flex flex-col overflow-hidden">
          <div className="px-6 pt-6 pb-4 border-b-2 border-stone-100 flex-shrink-0">
            <h2 className="text-xl font-black uppercase tracking-tighter text-stone-900">
              {TABS.find(t => t.id === tab)?.label}
            </h2>
          </div>

          <div className="flex-1 overflow-y-auto px-6 py-4 space-y-5">

            {/* ── GAMEPLAY ────────────────────────────────────────────── */}
            {tab === 'gameplay' && (
              <>
                <div>
                  <p className="text-[11px] font-black uppercase tracking-[0.2em] text-stone-400 mb-2">Difficulty</p>
                  <div className="bg-stone-50 border-4 border-black rounded-2xl overflow-hidden shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                    {DIFFS.map((d, i) => {
                      const active = difficulty === d.level
                      return (
                        <button key={d.level} onClick={() => { sfx.click(); onDifficultyChange(d.level) }}
                          className={`w-full flex items-center gap-4 px-4 py-3.5 transition-colors text-left ${i < DIFFS.length - 1 ? 'border-b-2 border-stone-100' : ''} ${active ? 'bg-amber-50' : 'hover:bg-white'}`}>
                          <div className={`w-9 h-9 rounded-xl flex items-center justify-center border-2 border-black flex-shrink-0 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] ${active ? d.color : 'bg-white'}`}>
                            <d.icon className={`w-4 h-4 ${active ? 'text-black' : 'text-stone-300'}`} />
                          </div>
                          <div className="flex-1">
                            <p className={`font-bold text-sm ${active ? 'text-stone-900' : 'text-stone-500'}`}>{d.label}</p>
                            <p className="text-xs text-stone-400">{d.sub}</p>
                          </div>
                          {active && <Check className="w-4 h-4 text-lime-600" />}
                        </button>
                      )
                    })}
                  </div>
                </div>

                <div>
                  <p className="text-[11px] font-black uppercase tracking-[0.2em] text-stone-400 mb-2">Interface Language</p>
                  <div className="bg-stone-50 border-4 border-black rounded-2xl overflow-hidden shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                    {([['EN','English','🇬🇧'],['MN','Монгол','🇲🇳']] as const).map(([code, name, flag], i) => (
                      <div key={code} className={`flex items-center gap-4 px-4 py-3.5 ${i === 0 ? 'border-b-2 border-stone-100' : ''}`}>
                        <span className="text-xl">{flag}</span>
                        <span className="flex-1 font-bold text-sm text-stone-900">{name}</span>
                        <Toggle on={settings.language === code} onChange={() => update({ language: code })} />
                      </div>
                    ))}
                  </div>
                  {settings.language === 'MN' && (
                    <p className="text-xs text-stone-400 font-medium mt-2">Mongolian UI translation coming soon.</p>
                  )}
                </div>
              </>
            )}

            {/* ── AUDIO ───────────────────────────────────────────────── */}
            {tab === 'audio' && (
              <div className="space-y-4">
                <div className="bg-stone-50 border-4 border-black rounded-2xl overflow-hidden shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                  <SettingRow
                    label="Sound Effects"
                    sub="UI clicks, correct/wrong sounds"
                    right={<Toggle on={settings.soundEnabled} onChange={() => update({ soundEnabled: !settings.soundEnabled })} />}
                  />
                  <SettingRow
                    label="Volume"
                    sub={`Current: ${settings.volume}%`}
                    right={
                      <div className="flex items-center gap-2">
                        {settings.soundEnabled
                          ? <Volume2 className="w-4 h-4 text-stone-400 flex-shrink-0" />
                          : <VolumeX className="w-4 h-4 text-stone-400 flex-shrink-0" />
                        }
                        <input
                          type="range" min={0} max={100} value={settings.volume}
                          onChange={e => update({ volume: Number(e.target.value) })}
                          className="w-24 accent-amber-400"
                          disabled={!settings.soundEnabled}
                        />
                      </div>
                    }
                  />
                </div>
                <div className={`flex items-center gap-3 p-3 rounded-xl border-2 ${settings.soundEnabled ? 'border-lime-300 bg-lime-50' : 'border-stone-200 bg-stone-50'}`}>
                  <div className={`w-2 h-2 rounded-full ${settings.soundEnabled ? 'bg-lime-500' : 'bg-stone-300'}`} />
                  <p className="text-xs font-bold text-stone-600">
                    {settings.soundEnabled ? `Sound is on at ${settings.volume}% — changes save automatically` : 'Sound is muted'}
                  </p>
                </div>
              </div>
            )}

            {/* ── NOTIFICATIONS ───────────────────────────────────────── */}
            {tab === 'notifications' && (
              <div className="space-y-3">
                <div className="bg-stone-50 border-4 border-black rounded-2xl overflow-hidden shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                  <SettingRow
                    label="Streak Reminders"
                    sub="Daily nudge to keep your streak alive"
                    right={<Toggle on={settings.notifStreak} onChange={() => update({ notifStreak: !settings.notifStreak })} />}
                  />
                  <SettingRow
                    label="Daily Challenge"
                    sub="Alert when today's tasks are ready"
                    right={<Toggle on={settings.notifDaily} onChange={() => update({ notifDaily: !settings.notifDaily })} />}
                  />
                  <SettingRow
                    label="Game Results"
                    sub="Session summary after each game"
                    right={<Toggle on={settings.notifResults} onChange={() => update({ notifResults: !settings.notifResults })} />}
                  />
                </div>
                <p className="text-xs text-stone-400 font-medium px-1">
                  Push notifications require browser permission. These settings save for your next visit.
                </p>
              </div>
            )}

            {/* ── APPEARANCE ──────────────────────────────────────────── */}
            {tab === 'appearance' && (
              <div className="space-y-4">
                {/* Dark mode — actually wired */}
                <div>
                  <p className="text-[11px] font-black uppercase tracking-[0.2em] text-stone-400 mb-2">Theme</p>
                  <div className="bg-stone-50 border-4 border-black rounded-2xl overflow-hidden shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                    <div className="flex items-center gap-4 px-4 py-3.5">
                      {isDark ? <Moon className="w-5 h-5 text-[#5865f2]" /> : <Sun className="w-5 h-5 text-amber-500" />}
                      <div className="flex-1">
                        <p className="font-bold text-sm text-stone-900">Dark Mode</p>
                        <p className="text-xs text-stone-400">{isDark ? 'Currently dark — enjoy the low light' : 'Currently light — toggle for dark theme'}</p>
                      </div>
                      <Toggle on={isDark} onChange={toggleDarkMode} />
                    </div>
                  </div>
                  {!userProfile && (
                    <p className="text-xs text-stone-400 mt-1 px-1">Sign in to save your theme preference.</p>
                  )}
                </div>

                {/* Font size */}
                <div>
                  <p className="text-[11px] font-black uppercase tracking-[0.2em] text-stone-400 mb-2">Text Size</p>
                  <div className="grid grid-cols-3 gap-2">
                    {(['small','medium','large'] as const).map(size => (
                      <button key={size} onClick={() => { update({ fontSize: size }); sfx.click(); }}
                        className={`py-3 rounded-xl border-4 font-black text-sm uppercase tracking-widest transition-all ${
                          settings.fontSize === size
                            ? 'border-black bg-stone-900 text-white shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]'
                            : 'border-stone-200 text-stone-500 hover:border-stone-400'
                        }`}>
                        {size === 'small' ? 'Aa' : size === 'medium' ? 'Aa' : 'Aa'}
                        <span className="block text-[9px] mt-0.5">{size}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* ── FEEDBACK ────────────────────────────────────────────── */}
            {tab === 'feedback' && (
              <div className="space-y-4">
                <div className="bg-stone-50 border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                  <p className="text-sm text-stone-600 font-medium leading-relaxed mb-4">
                    Found a bug? Have an idea? I read every message — it's just me building this.
                  </p>
                  {feedbackSent ? (
                    <div className="bg-lime-50 border-4 border-lime-300 rounded-xl p-5 text-center">
                      <div className="w-12 h-12 bg-lime-400 border-4 border-black rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
                        <Check className="w-6 h-6 text-black" />
                      </div>
                      <p className="font-black text-lime-800 text-sm uppercase tracking-wide">Sent — thank you!</p>
                      <p className="text-xs text-lime-600 font-medium mt-1">I'll read it as soon as I can.</p>
                      <button onClick={() => { setFeedbackSent(false); setFeedbackText(''); }}
                        className="mt-3 text-xs font-black uppercase tracking-widest text-lime-600 hover:text-lime-800 transition-colors">
                        Send another
                      </button>
                    </div>
                  ) : (
                    <>
                      <Textarea
                        value={feedbackText}
                        onChange={e => setFeedbackText(e.target.value)}
                        placeholder="Tell me what's broken, what you love, or what you wish existed..."
                        className="min-h-[120px] resize-none mb-3"
                      />
                      <button
                        onClick={() => { if (feedbackText.trim()) setFeedbackSent(true) }}
                        disabled={!feedbackText.trim()}
                        className="w-full flex items-center justify-center gap-2 py-3 bg-stone-900 text-white border-4 border-black rounded-xl font-black text-xs uppercase tracking-widest shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-all disabled:opacity-40">
                        <Send className="w-3.5 h-3.5" /> Send Feedback
                      </button>
                    </>
                  )}
                </div>
                <div className="bg-stone-50 border-4 border-black rounded-2xl p-4 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
                  <p className="text-[11px] font-black uppercase tracking-[0.2em] text-stone-400 mb-2">Direct Contact</p>
                  <p className="text-sm font-bold text-stone-900">support@ieltsmaster.mn</p>
                  <p className="text-xs text-stone-400 font-medium mt-0.5">Response within 24 hours</p>
                </div>
              </div>
            )}

            {/* ── ABOUT ───────────────────────────────────────────────── */}
            {tab === 'about' && (
              <div className="space-y-4">
                <div className="bg-amber-400 border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-black rounded-xl flex items-center justify-center">
                      <BookOpen className="w-5 h-5 text-amber-400" />
                    </div>
                    <div>
                      <p className="font-black text-black text-sm uppercase tracking-wide">IELTS Master</p>
                      <p className="text-black/60 text-xs font-medium">Version 1.0.0 · Built in Ulaanbaatar</p>
                    </div>
                  </div>
                  <p className="text-black/70 text-sm font-medium leading-relaxed">
                    Made by one student from Mongolia. AI-powered IELTS & SAT prep that's actually affordable.
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Badge variant="owner">Owner</Badge>
                    <Badge variant="manager">Manager</Badge>
                    <Badge variant="verified">Verified</Badge>
                    <Badge variant="student">Student</Badge>
                  </div>
                </div>

                <div className="bg-stone-50 border-4 border-black rounded-2xl overflow-hidden shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                  {[
                    { label: 'Privacy Policy',   sub: 'How we handle your data'   },
                    { label: 'Terms of Service', sub: 'Usage rules and conditions' },
                    { label: 'Support',          sub: 'support@ieltsmaster.mn'     },
                  ].map((r, i, arr) => (
                    <div key={r.label} className={`flex items-center gap-4 px-4 py-3.5 cursor-pointer hover:bg-white transition-colors ${i < arr.length - 1 ? 'border-b-2 border-stone-100' : ''}`}>
                      <div className="flex-1">
                        <p className="font-bold text-sm text-stone-900">{r.label}</p>
                        <p className="text-xs text-stone-400">{r.sub}</p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-stone-300" />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

import React, { useState } from 'react';
import { X, Target, Mail, Heart, Send } from 'lucide-react';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { sfx } from '../services/soundService';

interface StaticPageProps {
  page: 'about' | 'privacy' | 'terms' | 'cookies' | 'support';
  onClose: () => void;
}

// ── Support feedback form ─────────────────────────────────────────────────────
function SupportForm() {
  const [msg, setMsg] = React.useState('');
  const [email, setEmail] = React.useState('');
  const [sent, setSent] = React.useState(false);

  const send = () => {
    if (!msg.trim()) return;
    // In prod: POST to backend. For now simulate.
    setSent(true);
    setMsg(''); setEmail('');
    setTimeout(() => setSent(false), 4000);
  };

  return (
    <div className="bg-white border-4 border-black rounded-3xl p-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
      <h3 className="font-black text-stone-900 text-base uppercase tracking-tight mb-1 flex items-center gap-2">
        <Send className="w-4 h-4 text-rose-500" /> Send Feedback
      </h3>
      <p className="text-stone-400 text-xs font-medium mb-4">Bug report, feature request, or anything else — I read every message.</p>
      {sent ? (
        <div className="bg-lime-400 border-4 border-black rounded-2xl p-4 text-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
          <p className="font-black text-black uppercase tracking-wide">Sent! I'll reply within 24 hours.</p>
        </div>
      ) : (
        <div className="space-y-3">
          <input value={email} onChange={e => setEmail(e.target.value)} placeholder="your@email.com"
            className="w-full bg-white border-4 border-stone-200 rounded-xl px-4 py-2.5 text-sm font-medium text-stone-900 placeholder:text-stone-300 focus:outline-none focus:border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,0.3)] transition-all" />
          <Textarea value={msg} onChange={e => setMsg(e.target.value)} placeholder="Describe your issue or feedback..." rows={4} />
          <button onClick={send} disabled={!msg.trim()}
            className="flex items-center gap-2 px-5 py-3 bg-stone-900 text-white border-4 border-black rounded-xl font-black text-xs uppercase tracking-widest shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-none transition-all disabled:opacity-40">
            <Send className="w-3.5 h-3.5" /> Send Message
          </button>
        </div>
      )}
    </div>
  );
}

const PAGES = {
  about: {
    title: 'About',
    content: () => (
      <div className="space-y-8">
        <div className="bg-amber-400 border-4 border-black rounded-3xl p-8 shadow-[5px_5px_0px_0px_rgba(0,0,0,1)]">
          <h2 className="text-3xl font-black uppercase tracking-tighter text-black mb-3">One student. One dream.</h2>
          <p className="text-black/70 font-medium leading-relaxed">
            IELTS Master was built by one person from Ulaanbaatar, Mongolia, who struggled to find affordable, effective IELTS prep tools. So I built the one I wished existed.
          </p>
        </div>
        <div className="space-y-4">
          <h3 className="font-black text-xl uppercase tracking-tight text-stone-900">The Mission</h3>
          <p className="text-stone-600 font-medium leading-relaxed">
            Standardized tests like IELTS and SAT are gatekeepers to university, immigration, and opportunity. But quality prep is expensive and inaccessible — especially in Mongolia. IELTS Master uses AI to give every student access to the kind of personalized feedback that used to cost thousands of dollars in private tutoring.
          </p>
          <p className="text-stone-600 font-medium leading-relaxed">
            We're not a corporation. There's no investor pressure, no dark patterns, no ads. Just a tool built by a student, for students.
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[
            { stat: '50,000+', label: 'Students helped' },
            { stat: '0.5+', label: 'Avg band improvement' },
            { stat: '1', label: 'Developer, from Mongolia' },
          ].map(s => (
            <div key={s.label} className="bg-white border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-center">
              <p className="text-3xl font-black text-stone-900">{s.stat}</p>
              <p className="text-xs font-bold text-stone-400 uppercase tracking-widest mt-1">{s.label}</p>
            </div>
          ))}
        </div>
        <div className="bg-stone-900 rounded-3xl p-6 text-white">
          <div className="flex items-center gap-3 mb-3">
            <Heart className="w-5 h-5 text-rose-400 fill-current" />
            <span className="font-black uppercase tracking-widest text-sm">Get in touch</span>
          </div>
          <p className="text-stone-400 font-medium text-sm mb-3">Have feedback, ideas, or want to collaborate? I read every message.</p>
          <a href="mailto:hello@ieltsmaster.mn" className="text-amber-400 font-bold text-sm hover:underline">hello@ieltsmaster.mn</a>
        </div>
      </div>
    ),
  },
  privacy: {
    title: 'Privacy Policy',
    content: () => (
      <div className="space-y-6 text-stone-600 font-medium leading-relaxed">
        <p className="text-stone-400 text-sm">Last updated: January 2026</p>
        {[
          { h: 'What we collect', b: 'We collect: your email address, name, and study preferences when you sign up; your answers, essays, and spoken responses when you use the platform (to generate AI feedback); and usage data like which features you use and when (to improve the product).' },
          { h: 'How we use it', b: 'Your submissions are processed by AI to generate feedback. We do not use your personal essays or answers to train AI models. Usage data is aggregated and anonymized. We never sell your data to third parties.' },
          { h: 'Data storage', b: 'Data is stored securely. Your profile and progress are stored in browser localStorage and on our servers (if you have an account). You can delete your account and all associated data at any time from your profile settings.' },
          { h: 'Third parties', b: 'We use Google Gemini API for AI feedback generation. Your submitted text is processed by Google\'s API under their privacy terms. We do not share your identity with them — only the content you submit for analysis.' },
          { h: 'Cookies', b: 'We use minimal cookies for authentication and session management. See our Cookie Policy for details.' },
          { h: 'Your rights', b: 'You can request, export, or delete your data at any time by emailing privacy@ieltsmaster.mn. We will respond within 7 days.' },
          { h: 'Contact', b: 'For any privacy questions: privacy@ieltsmaster.mn' },
        ].map(s => (
          <div key={s.h}>
            <h3 className="font-black text-stone-900 text-base mb-2 uppercase tracking-tight">{s.h}</h3>
            <p>{s.b}</p>
          </div>
        ))}
      </div>
    ),
  },
  terms: {
    title: 'Terms of Service',
    content: () => (
      <div className="space-y-6 text-stone-600 font-medium leading-relaxed">
        <p className="text-stone-400 text-sm">Last updated: January 2026</p>
        {[
          { h: '1. Acceptance', b: 'By using IELTS Master, you agree to these terms. If you don\'t agree, don\'t use the platform. We may update these terms and will notify users of material changes.' },
          { h: '2. What we provide', b: 'AI-powered study tools for IELTS and SAT preparation. Content is educational and does not guarantee any specific exam result or score.' },
          { h: '3. Your account', b: 'You\'re responsible for keeping your account credentials secure. Provide accurate information. Accounts cannot be shared or transferred.' },
          { h: '4. Subscriptions & billing', b: 'Free plan is always free. Pro and Elite plans are billed monthly and auto-renew unless cancelled. Cancel any time from your profile. Refunds available within 7 days of first paid payment.' },
          { h: '5. Acceptable use', b: 'Don\'t: share accounts, scrape the platform, submit harmful content, misrepresent exam scores, or attempt to circumvent security. Violations may result in account termination.' },
          { h: '6. Intellectual property', b: 'Platform content, AI feedback, and UI design are owned by IELTS Master. Your personal data and submissions belong to you.' },
          { h: '7. Disclaimer', b: 'Platform is provided "as-is." We don\'t warrant error-free AI grading or guaranteed score improvement. Our liability is limited to fees paid in the 3 months before any claim.' },
          { h: '8. Contact', b: 'legal@ieltsmaster.mn' },
        ].map(s => (
          <div key={s.h}>
            <h3 className="font-black text-stone-900 text-base mb-2 uppercase tracking-tight">{s.h}</h3>
            <p>{s.b}</p>
          </div>
        ))}
      </div>
    ),
  },
  cookies: {
    title: 'Cookie Policy',
    content: () => (
      <div className="space-y-6 text-stone-600 font-medium leading-relaxed">
        <p className="text-stone-400 text-sm">Last updated: January 2026</p>
        <p>We keep our cookie use minimal. Here's exactly what we use and why:</p>
        <div className="space-y-4">
          {[
            { name: 'Session cookie', purpose: 'Keeps you logged in during your session. Deleted when you close the browser.', type: 'Essential' },
            { name: 'Preference cookie', purpose: 'Remembers your difficulty setting and language preference.', type: 'Functional' },
            { name: 'localStorage', purpose: 'Stores your profile, progress, and streak data locally on your device. Not a cookie — stays on your machine only.', type: 'Functional' },
          ].map(c => (
            <div key={c.name} className="bg-white border-4 border-stone-200 rounded-2xl p-5">
              <div className="flex items-start justify-between gap-4 mb-2">
                <h4 className="font-black text-stone-900 text-sm uppercase tracking-wide">{c.name}</h4>
                <span className="px-2 py-0.5 bg-stone-100 text-stone-500 text-[10px] font-black uppercase tracking-widest rounded flex-shrink-0">{c.type}</span>
              </div>
              <p className="text-sm">{c.purpose}</p>
            </div>
          ))}
        </div>
        <p>We do not use advertising cookies or third-party tracking. To opt out of functional cookies, clear your browser's localStorage and cookies for this site.</p>
      </div>
    ),
  },
  support: {
    title: 'Support',
    content: () => (
      <div className="space-y-6">
        <div className="bg-lime-400 border-4 border-black rounded-3xl p-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
          <h2 className="text-2xl font-black uppercase tracking-tighter text-black mb-2">How can I help?</h2>
          <p className="text-black/60 font-medium text-sm">I personally handle all support requests. Expect a reply within 24 hours.</p>
        </div>
        <div className="grid grid-cols-1 gap-4">
          {[
            { icon: Mail, title: 'Email Support', desc: 'support@ieltsmaster.mn', sub: 'Best for account issues, billing questions, or bugs.', color: 'bg-amber-400' },
            { icon: Mail, title: 'Payment Issues', desc: 'pay@ieltsmaster.mn', sub: 'Send your QPay or bank transfer receipt here to activate your subscription.', color: 'bg-cyan-400' },
          ].map(item => (
            <div key={item.title} className="flex items-start gap-4 p-5 bg-white border-4 border-black rounded-2xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
              <div className={`w-11 h-11 ${item.color} border-4 border-black rounded-xl flex items-center justify-center flex-shrink-0 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]`}>
                <item.icon className="w-5 h-5 text-black" />
              </div>
              <div>
                <p className="font-black text-sm uppercase tracking-wide text-stone-900 mb-0.5">{item.title}</p>
                <p className="font-bold text-sm text-stone-700">{item.desc}</p>
                <p className="text-xs text-stone-400 font-medium mt-1">{item.sub}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="bg-stone-900 rounded-3xl p-6">
          <h3 className="font-black text-white text-base uppercase tracking-tight mb-4">Common Questions</h3>
          <div className="space-y-3">
            {[
              { q: 'How do I upgrade my plan?', a: 'Go to Profile → tap the crown icon → Subscriptions. Pay via QPay or bank transfer and send your receipt.' },
              { q: 'My OTP code isn\'t working', a: 'The code is shown in your browser\'s developer console (F12 → Console tab). This is development mode — real email delivery coming soon.' },
              { q: 'I paid but my plan didn\'t upgrade', a: 'Email pay@ieltsmaster.mn with your receipt and email address. I\'ll upgrade your account within a few hours.' },
              { q: 'How do I delete my account?', a: 'Email support@ieltsmaster.mn with your account email. I\'ll delete everything within 7 days.' },
            ].map(item => (
              <div key={item.q} className="border-b border-stone-800 pb-3 last:border-0 last:pb-0">
                <p className="font-bold text-white text-sm mb-1">{item.q}</p>
                <p className="text-stone-400 text-sm font-medium leading-relaxed">{item.a}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    ),
  },
};

export const StaticPage: React.FC<StaticPageProps> = ({ page, onClose }) => {
  const data = PAGES[page];
  if (!data) return null;
  const Content = data.content;

  return (
    <div className="fixed inset-0 z-[85] bg-stone-50 overflow-y-auto" style={{ fontFamily: "'Inter', sans-serif" }}>
      <div className="sticky top-0 z-10 bg-white/95 backdrop-blur-xl border-b border-stone-100 px-6 py-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-rose-500 border-4 border-black rounded-xl flex items-center justify-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
            <Target className="w-4 h-4 text-white" strokeWidth={2.5} />
          </div>
          <span className="font-black text-sm uppercase tracking-widest text-stone-900">{data.title}</span>
        </div>
        <button onClick={() => { sfx.back(); onClose(); }}
          className="w-9 h-9 bg-stone-100 hover:bg-stone-200 rounded-xl flex items-center justify-center text-stone-500 hover:text-stone-900 transition-all border-2 border-stone-200">
          <X className="w-4 h-4" />
        </button>
      </div>
      <div className="max-w-2xl mx-auto px-6 py-10">
        <h1 className="text-4xl font-black uppercase tracking-tighter text-stone-900 mb-8 leading-tight">{data.title}</h1>
        <Content />
      </div>
    </div>
  );
};

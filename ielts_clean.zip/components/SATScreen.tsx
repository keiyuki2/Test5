import React from 'react';
import { Calculator, PenTool, BookOpen, ArrowLeft, ArrowRight, Target, FunctionSquare, Zap, GraduationCap } from 'lucide-react';
import { sfx } from '../services/soundService';

interface SATScreenProps {
  onBack: () => void;
  onStartWhiteboard: () => void;
  onStartCalculator: () => void;
}

function Sep() {
  return <div className="h-px bg-stone-200 my-8" />;
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3 mb-6">
      <span className="text-[11px] font-black uppercase tracking-[0.25em] text-stone-400">{children}</span>
      <div className="flex-1 h-px bg-stone-200" />
    </div>
  );
}

// Shared neon-brutalist background — same as IELTS menu
function StripeBg() {
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      <div className="absolute inset-0 bg-stone-50" />
      <div className="absolute -top-40 -right-40 w-[600px] h-[600px] opacity-[0.07]"
        style={{ background: 'repeating-linear-gradient(45deg, #f97316 0px, #f97316 12px, transparent 12px, transparent 36px)' }} />
      <div className="absolute -bottom-40 -left-40 w-[500px] h-[500px] opacity-[0.06]"
        style={{ background: 'repeating-linear-gradient(-45deg, #fbbf24 0px, #fbbf24 10px, transparent 10px, transparent 32px)' }} />
      <div className="absolute inset-0 opacity-[0.025]"
        style={{ backgroundImage: 'linear-gradient(#000 1px,transparent 1px),linear-gradient(90deg,#000 1px,transparent 1px)', backgroundSize: '40px 40px' }} />
    </div>
  );
}

export const SATScreen: React.FC<SATScreenProps> = ({ onBack, onStartWhiteboard, onStartCalculator }) => {
  return (
    <div className="min-h-screen bg-stone-50 relative" style={{ fontFamily: "'Inter', sans-serif" }}>
      <StripeBg />
      <div className="relative z-10 max-w-5xl mx-auto px-6 md:px-10 py-8">

        {/* ── Header ──────────────────────────────────────────────────────── */}
        <div className="flex items-center justify-between mb-10">
          <div className="flex items-center gap-4">
            <button
              onClick={() => { sfx.back(); onBack(); }}
              className="w-11 h-11 bg-white border-4 border-black rounded-xl flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:translate-x-0.5 hover:translate-y-0.5 hover:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] transition-all"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.25em] text-stone-400 mb-0.5">Study Platform</p>
              <h1 className="text-3xl md:text-4xl font-black uppercase tracking-tighter leading-none text-stone-900">
                SAT <span className="text-amber-500">Prep</span>
              </h1>
            </div>
          </div>
          <div className="w-12 h-12 bg-amber-400 border-4 border-black rounded-xl flex items-center justify-center shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
            <Calculator className="w-6 h-6 text-black" />
          </div>
        </div>

        {/* ── Separator ───────────────────────────────────────────────────── */}
        <div className="h-px bg-stone-200 mb-8" />

        {/* ── Hero tools — two big cards ────────────────────────────────── */}
        <SectionLabel>Tools</SectionLabel>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-8">
          {/* Whiteboard */}
          <button
            onClick={() => { sfx.select(); onStartWhiteboard(); }}
            className="group relative bg-stone-900 border-4 border-black rounded-2xl p-6 text-left shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1.5 hover:shadow-[9px_9px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all overflow-hidden min-h-[180px] flex flex-col justify-between"
          >
            <div className="absolute -top-6 -right-6 w-28 h-28 bg-fuchsia-400 rounded-full opacity-20 group-hover:opacity-30 transition-opacity" />
            <div className="absolute -bottom-4 -left-4 w-20 h-20 bg-amber-400 rounded-full opacity-15 group-hover:opacity-25 transition-opacity" />
            <div className="relative z-10 w-13 h-13">
              <div className="w-13 h-13 bg-fuchsia-400 border-4 border-white/20 rounded-xl flex items-center justify-center w-12 h-12 shadow-[3px_3px_0px_0px_rgba(255,255,255,0.15)] group-hover:rotate-6 transition-transform">
                <PenTool className="w-6 h-6 text-black" />
              </div>
            </div>
            <div className="relative z-10">
              <p className="font-black text-xl uppercase tracking-tight text-white leading-tight">Digital<br/>Whiteboard</p>
              <p className="text-[11px] font-bold text-white/50 uppercase tracking-widest mt-1">Free-draw workspace</p>
            </div>
            <ArrowRight className="absolute bottom-5 right-5 w-5 h-5 text-white/30 group-hover:text-white group-hover:translate-x-1 transition-all" />
          </button>

          {/* Calculator */}
          <button
            onClick={() => { sfx.select(); onStartCalculator(); }}
            className="group relative bg-amber-400 border-4 border-black rounded-2xl p-6 text-left shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1.5 hover:shadow-[9px_9px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all overflow-hidden min-h-[180px] flex flex-col justify-between"
          >
            <div className="w-12 h-12 bg-white border-4 border-black rounded-xl flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] group-hover:rotate-6 transition-transform">
              <FunctionSquare className="w-6 h-6 text-black" />
            </div>
            <div>
              <p className="font-black text-xl uppercase tracking-tight text-black leading-tight">Graphing<br/>Calculator</p>
              <p className="text-[11px] font-bold text-black/50 uppercase tracking-widest mt-1">Desmos-powered · SAT official</p>
            </div>
            <ArrowRight className="absolute bottom-5 right-5 w-5 h-5 text-black/30 group-hover:text-black group-hover:translate-x-1 transition-all" />
          </button>
        </div>

        <Sep />

        {/* ── Subject cards ────────────────────────────────────────────────── */}
        <SectionLabel>Subjects</SectionLabel>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
          {[
            {
              bg: 'bg-orange-500', icon: Calculator, label: 'Math', sub: 'Algebra · Advanced Math · Problem Solving',
              items: ['Heart of Algebra', 'Passport to Advanced Math', 'Data Analysis'],
            },
            {
              bg: 'bg-cyan-400', icon: BookOpen, label: 'Reading & Writing', sub: 'Craft · Information · Conventions',
              items: ['Craft & Structure', 'Information & Ideas', 'Standard English'],
            },
            {
              bg: 'bg-lime-400', icon: Target, label: 'Strategy', sub: 'Test-taking skills & timing',
              items: ['Process of Elimination', 'Time Management', 'Adaptive Approach'],
            },
          ].map(card => (
            <div key={card.label}
              className={`${card.bg} border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] relative overflow-hidden group hover:-translate-y-1 hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all`}>
              <div className="w-11 h-11 bg-white border-4 border-black rounded-xl flex items-center justify-center mb-4 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] group-hover:rotate-6 transition-transform">
                <card.icon className="w-5 h-5 text-black" />
              </div>
              <p className="font-black text-base uppercase tracking-tight text-black mb-1">{card.label}</p>
              <p className="text-[10px] font-bold text-black/60 uppercase tracking-widest mb-3">{card.sub}</p>
              <div className="space-y-1">
                {card.items.map(item => (
                  <div key={item} className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-black rounded-full flex-shrink-0" />
                    <span className="text-[11px] font-bold text-black/70">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <Sep />

        {/* ── Back to IELTS ────────────────────────────────────────────────── */}
        <SectionLabel>Switch Mode</SectionLabel>

        <button
          onClick={() => { sfx.navigate(); onBack(); }}
          className="w-full group flex items-center justify-between gap-6 bg-white border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all text-left"
        >
          <div className="flex items-center gap-4">
            <div className="w-11 h-11 bg-stone-900 border-4 border-black rounded-xl flex items-center justify-center flex-shrink-0 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] group-hover:rotate-3 transition-transform">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-black text-sm uppercase tracking-wide">Back to IELTS</p>
              <p className="text-xs text-stone-400 font-medium">Return to the main dashboard</p>
            </div>
          </div>
          <ArrowRight className="w-4 h-4 text-stone-300 group-hover:text-black group-hover:translate-x-1 transition-all" />
        </button>

      </div>
    </div>
  );
};

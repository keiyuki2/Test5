
import React, { useState, useEffect, useRef } from 'react';
import { X, Map, Heart, Skull, Snowflake, Sun, CloudRain, Star, Lock, ChevronRight, Calendar, Gift, MousePointer2, Move, Globe, Flame, BookOpen, Flag, Leaf } from 'lucide-react';

interface EventHubProps {
  onClose: () => void;
}

type EventTheme = 'WINTER' | 'VALENTINE' | 'SPRING' | 'SUMMER' | 'HALLOWEEN' | 'LUNAR' | 'EARTH' | 'FREEDOM' | 'SCHOOL';

interface EventNode {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  theme: EventTheme;
  status: 'COMPLETED' | 'ACTIVE' | 'LOCKED';
  x: number; // px coordinates relative to center
  y: number; // px coordinates relative to center
  rewards: string;
  startDate: string;
  endDate: string;
  bannerUrl: string;
}

// Center of the canvas is roughly 1000, 750 (in a 2000x1500 space)
const CENTER_X = 1000;
const CENTER_Y = 750;

const EVENTS: EventNode[] = [
  { 
    id: 'evt-lunar', 
    title: 'Dragon Ascendant', 
    subtitle: 'Lunar New Year',
    description: 'Master idioms related to fortune, tradition, and new beginnings.', 
    theme: 'LUNAR', 
    status: 'COMPLETED', 
    x: 400, y: 300, 
    rewards: 'Red Envelope XP',
    startDate: 'Jan 20',
    endDate: 'Feb 10',
    bannerUrl: 'https://images.unsplash.com/photo-1548625361-9872e4530089?q=80&w=2070&auto=format&fit=crop'
  },
  { 
    id: 'evt-valentine', 
    title: 'Crimson Heart', 
    subtitle: 'Relationship Lexis',
    description: 'Advanced vocabulary for emotions, social bonds, and psychology.', 
    theme: 'VALENTINE', 
    status: 'COMPLETED', 
    x: 800, y: 400, 
    rewards: 'Cupid Theme',
    startDate: 'Feb 14',
    endDate: 'Feb 28',
    bannerUrl: 'https://i.pinimg.com/736x/dd/24/39/dd24394edc7a86d30035d530db6b1457.jpg'
  },
  { 
    id: 'evt-spring', 
    title: 'Verdant Bloom', 
    subtitle: 'Nature & Growth',
    description: 'Describing processes, environmental change, and biology.', 
    theme: 'SPRING', 
    status: 'ACTIVE', 
    x: 1200, y: 300, 
    rewards: '500 XP',
    startDate: 'Mar 20',
    endDate: 'Apr 05',
    bannerUrl: 'https://images.unsplash.com/photo-1462275646964-a0e3386b89fa?q=80&w=2600&auto=format&fit=crop'
  },
  { 
    id: 'evt-earth', 
    title: 'Gaia Protocol', 
    subtitle: 'Earth Day',
    description: 'Crucial vocabulary for climate change, sustainability, and ecology topics.', 
    theme: 'EARTH', 
    status: 'LOCKED', 
    x: 1500, y: 550, 
    rewards: 'Eco Badge',
    startDate: 'Apr 22',
    endDate: 'Apr 30',
    bannerUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2072&auto=format&fit=crop'
  },
  { 
    id: 'evt-summer', 
    title: 'Solar Zenith', 
    subtitle: 'Travel & Culture',
    description: 'Band 9.0 phrases for tourism, globalization, and leisure.', 
    theme: 'SUMMER', 
    status: 'LOCKED', 
    x: 1300, y: 900, 
    rewards: 'Sunburst Frame',
    startDate: 'Jun 15',
    endDate: 'Jul 15',
    bannerUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=2073&auto=format&fit=crop'
  },
  { 
    id: 'evt-freedom', 
    title: 'Liberty Legion', 
    subtitle: 'Independence Season',
    description: 'Language of history, governance, and societal change.', 
    theme: 'FREEDOM', 
    status: 'LOCKED', 
    x: 900, y: 800, 
    rewards: 'Patriot Theme',
    startDate: 'Jul 04',
    endDate: 'Jul 10',
    bannerUrl: 'https://images.unsplash.com/photo-1532375810709-75b1da00537c?q=80&w=2076&auto=format&fit=crop'
  },
  { 
    id: 'evt-school', 
    title: 'Academic Origins', 
    subtitle: 'Back to School',
    description: 'Formal academic register and education system vocabulary.', 
    theme: 'SCHOOL', 
    status: 'LOCKED', 
    x: 500, y: 950, 
    rewards: 'Scholar Badge',
    startDate: 'Aug 25',
    endDate: 'Sep 15',
    bannerUrl: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?q=80&w=2022&auto=format&fit=crop'
  },
  { 
    id: 'evt-halloween', 
    title: 'Shadow Realm', 
    subtitle: 'Fear & Mystery',
    description: 'Descriptive language for atmosphere, suspense, and the unknown.', 
    theme: 'HALLOWEEN', 
    status: 'LOCKED', 
    x: 300, y: 1250, 
    rewards: 'Haunted Frame',
    startDate: 'Oct 25',
    endDate: 'Oct 31',
    bannerUrl: 'https://images.unsplash.com/photo-1509557965875-b88c97052f0e?q=80&w=2070&auto=format&fit=crop'
  },
  { 
    id: 'evt-winter', 
    title: 'Frozen Summit', 
    subtitle: 'Winter Finale',
    description: 'End of year review. Complex grammar structures and reflections.', 
    theme: 'WINTER', 
    status: 'LOCKED', 
    x: 700, y: 1400, 
    rewards: 'Grand Prize',
    startDate: 'Dec 01',
    endDate: 'Dec 31',
    bannerUrl: 'https://images.unsplash.com/photo-1483664852095-d6cc6870702d?q=80&w=2070&auto=format&fit=crop'
  },
];

const getThemeStyles = (theme: EventTheme) => {
    switch (theme) {
        case 'WINTER': return { 
            bg: 'bg-cyan-500', 
            border: 'border-cyan-200', 
            shadow: 'shadow-cyan-500/50', 
            icon: Snowflake, 
            gradient: 'from-cyan-900 to-slate-900',
            accent: 'text-cyan-400',
            lineColor: '#06b6d4'
        };
        case 'VALENTINE': return { 
            bg: 'bg-rose-500', 
            border: 'border-rose-200', 
            shadow: 'shadow-rose-500/50', 
            icon: Heart, 
            gradient: 'from-rose-900 to-slate-900',
            accent: 'text-rose-400',
            lineColor: '#f43f5e'
        };
        case 'HALLOWEEN': return { 
            bg: 'bg-orange-500', 
            border: 'border-orange-200', 
            shadow: 'shadow-orange-500/50', 
            icon: Skull, 
            gradient: 'from-orange-900 to-slate-900',
            accent: 'text-orange-400',
            lineColor: '#f97316'
        };
        case 'SUMMER': return { 
            bg: 'bg-yellow-400', 
            border: 'border-yellow-100', 
            shadow: 'shadow-yellow-500/50', 
            icon: Sun, 
            gradient: 'from-yellow-900 to-slate-900',
            accent: 'text-yellow-400',
            lineColor: '#facc15'
        };
        case 'SPRING': return { 
            bg: 'bg-emerald-400', 
            border: 'border-emerald-200', 
            shadow: 'shadow-emerald-500/50', 
            icon: CloudRain, 
            gradient: 'from-emerald-900 to-slate-900',
            accent: 'text-emerald-400',
            lineColor: '#34d399'
        };
        case 'LUNAR': return { 
            bg: 'bg-red-600', 
            border: 'border-yellow-400', 
            shadow: 'shadow-red-600/50', 
            icon: Flame, 
            gradient: 'from-red-900 to-black',
            accent: 'text-red-500',
            lineColor: '#dc2626'
        };
        case 'EARTH': return { 
            bg: 'bg-lime-500', 
            border: 'border-blue-400', 
            shadow: 'shadow-lime-500/50', 
            icon: Globe, 
            gradient: 'from-green-900 to-blue-900',
            accent: 'text-lime-400',
            lineColor: '#84cc16'
        };
        case 'FREEDOM': return { 
            bg: 'bg-blue-600', 
            border: 'border-red-500', 
            shadow: 'shadow-blue-600/50', 
            icon: Flag, 
            gradient: 'from-blue-900 to-slate-900',
            accent: 'text-blue-400',
            lineColor: '#2563eb'
        };
        case 'SCHOOL': return { 
            bg: 'bg-amber-500', 
            border: 'border-slate-800', 
            shadow: 'shadow-amber-500/50', 
            icon: BookOpen, 
            gradient: 'from-amber-900 to-slate-900',
            accent: 'text-amber-500',
            lineColor: '#f59e0b'
        };
        default: return { 
            bg: 'bg-slate-500', 
            border: 'border-slate-300', 
            shadow: 'shadow-slate-500/50', 
            icon: Star, 
            gradient: 'from-slate-900 to-black',
            accent: 'text-slate-400',
            lineColor: '#64748b'
        };
    }
};

export const EventHub: React.FC<EventHubProps> = ({ onClose }) => {
  const [selectedEvent, setSelectedEvent] = useState<EventNode | null>(null);
  
  // Panning State
  const [position, setPosition] = useState({ x: -CENTER_X + window.innerWidth / 2, y: -CENTER_Y + window.innerHeight / 2 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef({ x: 0, y: 0 });
  const startPos = useRef({ x: 0, y: 0 });

  // Auto-select the active event on load if none selected
  useEffect(() => {
      if (!selectedEvent) {
          const active = EVENTS.find(e => e.status === 'ACTIVE');
          if (active) setSelectedEvent(active);
          
          // Center on active event initially
          if (active) {
             setPosition({
                 x: -active.x + window.innerWidth / 2,
                 y: -active.y + window.innerHeight / 2
             });
          }
      }
  }, []);

  const handleMouseDown = (e: React.MouseEvent) => {
      setIsDragging(true);
      dragStart.current = { x: e.clientX, y: e.clientY };
      startPos.current = { ...position };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
      if (!isDragging) return;
      const dx = e.clientX - dragStart.current.x;
      const dy = e.clientY - dragStart.current.y;
      setPosition({ x: startPos.current.x + dx, y: startPos.current.y + dy });
  };

  const handleMouseUp = () => setIsDragging(false);

  const styles = selectedEvent ? getThemeStyles(selectedEvent.theme) : getThemeStyles('WINTER');

  return (
    <div className="fixed inset-0 z-[100] bg-slate-950 flex flex-col animate-fade-in overflow-hidden font-sans select-none">
        
        {/* Dynamic Background based on selection */}
        <div className={`absolute inset-0 bg-gradient-to-br ${styles.gradient} transition-colors duration-1000 opacity-50 pointer-events-none`}></div>
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-20 animate-pulse-slow pointer-events-none"></div>
        
        {/* Header */}
        <div className="absolute top-0 left-0 w-full z-20 flex justify-between items-center p-6 md:p-8 bg-gradient-to-b from-black/80 to-transparent pointer-events-none">
            <div className="flex items-center gap-4 pointer-events-auto">
                <div className="w-12 h-12 bg-white text-black rounded-xl flex items-center justify-center border-2 border-white/50 shadow-[0_0_15px_rgba(255,255,255,0.2)]">
                    <Calendar className="w-6 h-6" />
                </div>
                <div>
                    <h1 className="text-2xl md:text-3xl font-black text-white uppercase tracking-tighter italic drop-shadow-lg"><span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-cyan-400">Events</span></h1>
                    <p className="text-xs font-bold text-slate-300 uppercase tracking-widest drop-shadow-md">Event Map</p>
                </div>
            </div>
            <div className="flex items-center gap-4 pointer-events-auto">
                <div className="hidden md:flex bg-black/40 backdrop-blur-md border border-white/10 px-4 py-2 rounded-full text-xs font-bold text-white uppercase tracking-widest items-center gap-2">
                    <Move className="w-4 h-4" /> Drag to Navigate
                </div>
                <button onClick={onClose} className="w-12 h-12 flex items-center justify-center rounded-xl border-2 border-white/10 bg-black/20 hover:bg-white/10 text-slate-400 hover:text-white transition-colors backdrop-blur-sm">
                    <X className="w-6 h-6" />
                </button>
            </div>
        </div>

        {/* Draggable Map Area */}
        <div 
            className="flex-1 relative cursor-grab active:cursor-grabbing"
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
        >
            <div 
                className="absolute top-0 left-0 w-[2500px] h-[2000px] transition-transform duration-75 ease-out origin-top-left"
                style={{ transform: `translate(${position.x}px, ${position.y}px)` }}
            >
                {/* Connecting Path */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
                    <defs>
                        <linearGradient id="pathGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                            {EVENTS.map((evt, i) => {
                                const offset = (i / (EVENTS.length - 1)) * 100;
                                const color = getThemeStyles(evt.theme).lineColor;
                                return <stop key={evt.id} offset={`${offset}%`} stopColor={color} stopOpacity="0.6" />;
                            })}
                        </linearGradient>
                        <filter id="glow">
                            <feGaussianBlur stdDeviation="4" result="coloredBlur"/>
                            <feMerge>
                                <feMergeNode in="coloredBlur"/>
                                <feMergeNode in="SourceGraphic"/>
                            </feMerge>
                        </filter>
                    </defs>
                    {EVENTS.map((evt, i) => {
                        if (i === EVENTS.length - 1) return null;
                        const next = EVENTS[i + 1];
                        return (
                            <path
                                key={i}
                                d={`M ${evt.x} ${evt.y} Q ${(evt.x + next.x)/2 + (i%2===0 ? 100 : -100)} ${(evt.y + next.y)/2}, ${next.x} ${next.y}`} 
                                stroke="url(#pathGradient)"
                                strokeWidth="6"
                                fill="none"
                                strokeDasharray={next.status === 'LOCKED' ? '12 12' : '0'}
                                className="transition-all duration-1000"
                                filter="url(#glow)"
                            />
                        );
                    })}
                </svg>

                {/* Event Nodes */}
                {EVENTS.map((evt) => {
                    const nodeStyles = getThemeStyles(evt.theme);
                    const isActive = evt.status === 'ACTIVE';
                    const isLocked = evt.status === 'LOCKED';
                    const isCompleted = evt.status === 'COMPLETED';
                    const isSelected = selectedEvent?.id === evt.id;

                    return (
                        <div
                            key={evt.id}
                            style={{ left: evt.x, top: evt.y }}
                            className="absolute -translate-x-1/2 -translate-y-1/2 z-10 group"
                        >
                            <button
                                onClick={() => setSelectedEvent(evt)}
                                className={`
                                    relative transition-all duration-500
                                    ${isSelected ? 'scale-125 z-20' : 'hover:scale-110'}
                                `}
                            >
                                {/* Status Indicator Ring */}
                                {isActive && <div className={`absolute inset-[-12px] rounded-full border-2 ${nodeStyles.border} border-dashed animate-[spin_10s_linear_infinite] opacity-50`}></div>}
                                
                                <div className={`
                                    w-20 h-20 rounded-full flex items-center justify-center border-4 shadow-2xl relative overflow-hidden transition-all duration-300
                                    ${isLocked 
                                        ? 'bg-slate-800 border-slate-600 grayscale opacity-80' 
                                        : `${nodeStyles.bg} ${nodeStyles.border} ${nodeStyles.shadow}`
                                    }
                                `}>
                                    {/* Inner Icon */}
                                    {isLocked ? (
                                        <Lock className="w-8 h-8 text-slate-400" />
                                    ) : (
                                        <nodeStyles.icon className={`w-10 h-10 text-white drop-shadow-md ${isActive ? 'animate-pulse' : ''}`} />
                                    )}

                                    {/* Completed Checkmark */}
                                    {isCompleted && (
                                        <div className="absolute top-2 right-2 bg-white text-black rounded-full p-0.5 shadow-sm">
                                            <Star className="w-3 h-3 fill-current" />
                                        </div>
                                    )}
                                </div>
                            </button>

                            {/* Event Info */}
                            <div className={`
                                absolute bottom-[140%] left-1/2 -translate-x-1/2 w-64 
                                opacity-0 group-hover:opacity-100 transition-all duration-500 
                                transform translate-y-4 group-hover:translate-y-0
                                pointer-events-none z-50
                            `}>
                                <div className="relative bg-slate-900 rounded-xl overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.8)] border border-white/10">
                                    {/* Banner Image */}
                                    <div className="h-28 w-full relative">
                                        <img 
                                            src={evt.bannerUrl} 
                                            alt={evt.title} 
                                            className="w-full h-full object-cover"
                                        />
                                        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 to-transparent"></div>
                                        <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded border border-white/10">
                                            <span className={`text-[10px] font-black uppercase tracking-widest ${nodeStyles.accent}`}>{evt.status}</span>
                                        </div>
                                    </div>

                                    {/* Content */}
                                    <div className="p-4 bg-slate-900 relative -mt-4 pt-2">
                                        <h3 className="text-white font-serif font-bold text-lg leading-tight mb-1">{evt.title}</h3>
                                        <div className={`h-0.5 w-8 mb-3 ${nodeStyles.bg}`}></div>
                                        
                                        <div className="flex justify-between items-center text-center">
                                            <div>
                                                <p className="text-[9px] text-slate-500 font-black uppercase tracking-widest mb-0.5">Start</p>
                                                <p className="font-serif text-white font-bold">{evt.startDate}</p>
                                            </div>
                                            <div className="h-8 w-px bg-white/10 mx-2"></div>
                                            <div>
                                                <p className="text-[9px] text-slate-500 font-black uppercase tracking-widest mb-0.5">End</p>
                                                <p className="font-serif text-white font-bold">{evt.endDate}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* Arrow */}
                                <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-slate-900 border-r border-b border-white/10 transform rotate-45"></div>
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>

        {/* Event Details */}
        <div className={`absolute bottom-0 left-0 w-full bg-slate-950/90 backdrop-blur-xl border-t border-white/10 transition-transform duration-500 ease-out z-30 shadow-[0_-20px_50px_rgba(0,0,0,0.8)] ${selectedEvent ? 'translate-y-0' : 'translate-y-full'}`}>
            {selectedEvent && (
                <div className="max-w-5xl mx-auto p-8 relative">
                    <button onClick={() => setSelectedEvent(null)} className="absolute top-4 right-4 text-slate-500 hover:text-white p-2 hover:bg-white/5 rounded-full transition-all"><X className="w-6 h-6" /></button>
                    
                    <div className="flex flex-col md:flex-row gap-8 items-center md:items-start">
                        {/* Event Icon Big */}
                        <div className={`
                            w-24 h-24 md:w-32 md:h-32 rounded-3xl flex items-center justify-center border-4 shadow-2xl shrink-0 transform -rotate-3
                            ${styles.bg} ${styles.border} ${styles.shadow}
                        `}>
                            {(() => {
                                const Icon = getThemeStyles(selectedEvent.theme).icon;
                                return <Icon className="w-12 h-12 md:w-16 md:h-16 text-white drop-shadow-md" />;
                            })()}
                        </div>

                        {/* Details */}
                        <div className="flex-1 text-center md:text-left">
                            <div className="flex items-center justify-center md:justify-start gap-3 mb-2">
                                <span className={`px-3 py-1 rounded text-[10px] font-black uppercase tracking-widest border bg-black/30 ${styles.accent} border-current`}>
                                    {selectedEvent.status}
                                </span>
                                <span className="text-slate-400 font-bold text-xs uppercase tracking-widest flex items-center gap-2">
                                    <Calendar className="w-3 h-3" /> Ends: {selectedEvent.endDate}
                                </span>
                            </div>
                            
                            <h2 className="text-3xl md:text-5xl font-black text-white uppercase tracking-tighter mb-2 leading-none font-serif italic">
                                {selectedEvent.title}
                            </h2>
                            <p className={`text-sm font-black uppercase tracking-[0.2em] mb-4 ${styles.accent}`}>
                                {selectedEvent.subtitle}
                            </p>
                            <p className="text-slate-300 font-medium text-lg leading-relaxed max-w-2xl">
                                {selectedEvent.description}
                            </p>
                        </div>

                        {/* Actions */}
                        <div className="flex flex-col gap-4 w-full md:w-auto min-w-[200px]">
                            <div className="bg-black/40 px-6 py-4 rounded-2xl border border-white/10 flex items-center justify-between gap-4 backdrop-blur-sm">
                                <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Reward</span>
                                <span className="text-yellow-400 font-black flex items-center gap-2">
                                    <Gift className="w-4 h-4" /> {selectedEvent.rewards}
                                </span>
                            </div>
                            
                            <button 
                                disabled={selectedEvent.status === 'LOCKED'}
                                className={`
                                    w-full py-4 rounded-xl font-black uppercase tracking-widest shadow-lg flex items-center justify-center gap-2 transition-all
                                    ${selectedEvent.status === 'ACTIVE' 
                                        ? 'bg-white text-black hover:scale-105 hover:bg-indigo-50 hover:shadow-[0_0_20px_rgba(255,255,255,0.3)]' 
                                        : selectedEvent.status === 'COMPLETED'
                                            ? 'bg-emerald-900/50 text-emerald-400 border-2 border-emerald-500 cursor-default'
                                            : 'bg-slate-800 text-slate-500 cursor-not-allowed border-2 border-slate-700'
                                    }
                                `}
                            >
                                {selectedEvent.status === 'COMPLETED' ? 'Completed' : selectedEvent.status === 'LOCKED' ? 'Locked' : 'Enter Event'}
                                {selectedEvent.status === 'ACTIVE' && <ChevronRight className="w-5 h-5" />}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    </div>
  );
};

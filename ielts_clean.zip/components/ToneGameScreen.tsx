
import React, { useState } from 'react';
import { ToneQuestion, Language } from '../types';
import { translations } from '../translations';
import { ArrowRight, Check, X, RotateCcw, MessageSquare, Briefcase, User, GraduationCap } from 'lucide-react';

interface ToneGameScreenProps {
  questions: ToneQuestion[];
  onComplete: () => void;
  lang: Language;
}

export const ToneGameScreen: React.FC<ToneGameScreenProps> = ({ questions, onComplete, lang }) => {
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [hasAnswered, setHasAnswered] = useState(false);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [history, setHistory] = useState<boolean[]>([]);
  const t = translations[lang];

  const currentQ = questions && questions[index];

  const handleOptionClick = (option: string) => {
    if (hasAnswered) return;
    
    setSelectedOption(option);
    setHasAnswered(true);
    
    const isCorrect = option === currentQ.correctAnswer;
    if (isCorrect) setScore(s => s + 1);
    setHistory(prev => [...prev, isCorrect]);
  };

  const handleNext = () => {
    if (index < questions.length - 1) {
      setIndex(i => i + 1);
      setHasAnswered(false);
      setSelectedOption(null);
    } else {
      setIndex(i => i + 1);
    }
  };

  if (!currentQ || index >= questions.length) {
      const percentage = Math.round((score / questions.length) * 100);
      return (
          <div className="w-full max-w-2xl mx-auto py-12 px-6 animate-slide-up">
              <div className="bg-white rounded-[3rem] border-4 border-black shadow-[16px_16px_0px_0px_rgba(0,0,0,1)] text-center relative overflow-hidden">
                  
                  <div className="bg-lime-500 p-10 border-b-4 border-black">
                      <div className="w-24 h-24 bg-white rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                          <MessageSquare className="w-12 h-12 text-lime-600 fill-current" />
                      </div>
                      <h2 className="text-5xl font-black uppercase tracking-tighter mb-2 text-white drop-shadow-md">{t.vocab.finishSet}</h2>
                  </div>
                  
                  <div className="p-10">
                      <div className="flex justify-center gap-12 mb-10">
                          <div>
                              <div className="text-xs font-black uppercase tracking-widest text-slate-400 mb-1">Score</div>
                              <div className="text-6xl font-black text-slate-900">{score}</div>
                          </div>
                          <div className="w-px bg-slate-200"></div>
                          <div>
                              <div className="text-xs font-black uppercase tracking-widest text-slate-400 mb-1">Accuracy</div>
                              <div className={`text-6xl font-black ${percentage >= 80 ? 'text-emerald-500' : percentage >= 50 ? 'text-amber-500' : 'text-rose-500'}`}>
                                  {percentage}%
                              </div>
                          </div>
                      </div>

                      <div className="flex justify-center gap-2 mb-10 relative z-10 flex-wrap max-w-sm mx-auto">
                          {history.map((res, i) => (
                              <div key={i} className={`w-3 h-3 rounded-full border border-black ${res ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                          ))}
                      </div>

                      <button 
                        onClick={onComplete}
                        className="w-full py-5 bg-black text-white rounded-2xl font-black text-xl uppercase tracking-wider shadow-[6px_6px_0px_0px_rgba(0,0,0,0.5)] border-2 border-transparent hover:border-black hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 active:translate-y-0 active:shadow-none transition-all flex items-center justify-center gap-2 relative z-10"
                      >
                          {t.common.tryAgain} <RotateCcw className="w-6 h-6" />
                      </button>
                  </div>
              </div>
          </div>
      );
  }

  return (
    <div className="w-full max-w-[1200px] mx-auto py-8 md:py-12 px-4 md:px-6 animate-slide-up flex flex-col h-[calc(100vh-140px)]">
      {/* Header HUD */}
      <div className="flex justify-between items-center mb-8 bg-white p-4 rounded-2xl border-4 border-black shadow-[6px_6px_0px_0px_rgba(0,0,0,1)]">
          <div className="flex items-center gap-3">
              <div className="bg-lime-500 text-black p-2 rounded-lg border-2 border-black">
                  <Briefcase className="w-6 h-6" />
              </div>
              <div>
                  <div className="text-[10px] font-black uppercase tracking-widest text-slate-400">{t.common.score}</div>
                  <div className="text-2xl font-black leading-none">{score}</div>
              </div>
          </div>
          <div className="text-right">
              <div className="text-[10px] font-black uppercase tracking-widest text-slate-400">Progress</div>
              <div className="text-2xl font-black leading-none text-lime-600">{index + 1}<span className="text-slate-400 text-lg">/{questions.length}</span></div>
          </div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center relative">
          
          {/* Casual Sentence (Problem) */}
          <div className="w-full max-w-3xl mb-16 relative group">
              <div className="absolute -top-5 -left-4 bg-slate-900 text-white px-4 py-2 rounded-xl font-black uppercase tracking-widest text-xs border-2 border-black flex items-center gap-2 transform -rotate-3 z-10 shadow-md">
                  <User className="w-4 h-4" /> Casual / Informal
              </div>
              <div className="bg-white rounded-[2rem] p-10 md:p-14 border-4 border-black shadow-[10px_10px_0px_0px_rgba(0,0,0,1)] relative">
                  {/* Speech bubble tail */}
                  <div className="absolute bottom-0 left-12 w-6 h-6 bg-white border-r-4 border-b-4 border-black transform rotate-45 translate-y-3"></div>
                  
                  <h2 className="text-2xl md:text-4xl font-black text-slate-900 leading-snug">
                      "{currentQ.casualSentence}"
                  </h2>
              </div>
          </div>

          <div className="w-full max-w-3xl mb-6 flex items-center gap-4">
              <div className="h-0.5 flex-1 bg-slate-300"></div>
              <span className="text-xs font-black uppercase tracking-widest text-slate-400 bg-white px-2">Select Academic Equivalent</span>
              <div className="h-0.5 flex-1 bg-slate-300"></div>
          </div>

          {/* Options (Solutions) */}
          <div className="grid grid-cols-1 gap-4 w-full max-w-3xl">
              {(currentQ.options || []).map((opt, i) => {
                  const isSelected = selectedOption === opt;
                  const isCorrectAnswer = currentQ.correctAnswer === opt;
                  
                  let bgClass = "bg-white";
                  let borderClass = "border-black";
                  
                  if (hasAnswered) {
                      if (isCorrectAnswer) {
                          bgClass = "bg-emerald-100";
                          borderClass = "border-emerald-600";
                      } else if (isSelected) {
                          bgClass = "bg-rose-100";
                          borderClass = "border-rose-600";
                      } else {
                          bgClass = "bg-slate-50 opacity-50";
                          borderClass = "border-slate-300";
                      }
                  } else {
                      bgClass = "bg-white hover:bg-lime-50";
                  }

                  return (
                      <button
                        key={i}
                        onClick={() => handleOptionClick(opt)}
                        disabled={hasAnswered}
                        className={`
                            p-6 rounded-2xl border-4 text-lg md:text-xl font-bold text-left shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-all relative overflow-hidden flex items-center justify-between
                            ${bgClass} ${borderClass}
                            ${!hasAnswered ? 'hover:-translate-y-1 hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] active:translate-y-0.5 active:shadow-none' : ''}
                        `}
                      >
                          <div className="flex items-center gap-4">
                              <div className={`w-8 h-8 rounded-full border-2 border-black flex items-center justify-center text-xs font-black ${hasAnswered ? 'opacity-50' : 'bg-lime-200'}`}>
                                  {String.fromCharCode(65 + i)}
                              </div>
                              <span className={hasAnswered && !isCorrectAnswer && !isSelected ? "text-slate-400" : "text-slate-900"}>{opt}</span>
                          </div>
                          {hasAnswered && isCorrectAnswer && <Check className="w-6 h-6 text-emerald-600 flex-none ml-4" />}
                          {hasAnswered && isSelected && !isCorrectAnswer && <X className="w-6 h-6 text-rose-600 flex-none ml-4" />}
                      </button>
                  );
              })}
          </div>

          {/* Feedback & Next */}
          {hasAnswered && (
             <div className="fixed bottom-0 left-0 w-full p-6 flex justify-center pointer-events-none z-30">
                 <div className="bg-slate-900 text-white p-6 rounded-[2rem] border-4 border-black shadow-[0_10px_40px_rgba(0,0,0,0.3)] w-full max-w-3xl pointer-events-auto animate-slide-up flex flex-col md:flex-row gap-6 items-center">
                     <div className="flex-1">
                         <div className="flex items-center gap-2 mb-2">
                            <div className="bg-lime-400 p-1 rounded border border-black text-black">
                                <GraduationCap className="w-4 h-4" />
                            </div>
                            <span className="text-xs font-black uppercase tracking-widest text-lime-400">Examiner Note</span>
                         </div>
                         <p className="font-medium text-lg leading-snug">{currentQ.explanation}</p>
                     </div>
                     <button 
                        onClick={handleNext}
                        className="flex-none px-8 py-4 bg-indigo-600 text-white rounded-xl font-black text-lg uppercase tracking-wider hover:bg-indigo-50 transition-colors border-2 border-black shadow-[4px_4px_0px_0px_rgba(255,255,255,0.2)] hover:-translate-y-1 hover:shadow-[6px_6px_0px_0px_rgba(255,255,255,0.2)]"
                      >
                          {t.common.next} <ArrowRight className="inline-block w-5 h-5 ml-2" />
                      </button>
                 </div>
             </div>
          )}

      </div>
    </div>
  );
};

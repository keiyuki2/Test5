
import React, { useState, useEffect } from 'react';
import { generateHeadingMatch } from '../services/geminiService';
import { Difficulty, HeadingMatchGame } from '../types';
import { LayoutGrid, Check, RefreshCw, Loader2, ArrowRight, GripVertical, FileText } from 'lucide-react';

interface HeadingMatchScreenProps {
  difficulty: Difficulty;
  onComplete: () => void;
}

export const HeadingMatchScreen: React.FC<HeadingMatchScreenProps> = ({ difficulty, onComplete }) => {
  const [game, setGame] = useState<HeadingMatchGame | null>(null);
  const [matches, setMatches] = useState<Record<string, string>>({}); // pId -> hId
  const [loading, setLoading] = useState(true);
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(0);

  useEffect(() => {
    const load = async () => {
        setLoading(true);
        try {
            const data = await generateHeadingMatch(difficulty);
            setGame(data);
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };
    load();
  }, [difficulty]);

  const handleDragStart = (e: React.DragEvent, headingId: string) => {
      e.dataTransfer.setData("headingId", headingId);
  };

  const handleDrop = (e: React.DragEvent, paragraphId: string) => {
      e.preventDefault();
      const hId = e.dataTransfer.getData("headingId");
      setMatches(prev => ({ ...prev, [paragraphId]: hId }));
  };

  const handleDragOver = (e: React.DragEvent) => e.preventDefault();

  const handleSubmit = () => {
      if (!game) return;
      let correct = 0;
      Object.entries(matches).forEach(([pId, hId]) => {
          if (game.correctMatches[pId] === hId) correct++;
      });
      setScore(correct);
      setSubmitted(true);
  };

  if (loading || !game) return <div className="flex h-[50vh] items-center justify-center flex-col gap-4">
      <Loader2 className="animate-spin w-12 h-12 text-indigo-600" />
      <p className="font-black uppercase tracking-widest text-slate-400">Loading Task 1...</p>
  </div>;

  return (
    <div className="w-full max-w-6xl mx-auto py-12 px-6 animate-slide-up">
        <h2 className="text-4xl font-black mb-10 uppercase tracking-tighter flex items-center gap-4">
            <div className="bg-indigo-600 p-2 rounded-xl border-2 border-black text-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                <LayoutGrid className="w-8 h-8" /> 
            </div>
            Matching Headings
        </h2>

        <div className="flex flex-col-reverse lg:flex-row gap-8">
            {/* Paragraphs */}
            <div className="w-full lg:w-2/3 space-y-8">
                {(game.paragraphs || []).map((p, idx) => {
                    const matchedHeadingId = matches[p.id];
                    const matchedHeading = game.headings.find(h => h.id === matchedHeadingId);
                    const isCorrect = submitted && game.correctMatches[p.id] === matchedHeadingId;

                    return (
                        <div key={p.id} className="bg-white rounded-[2.5rem] border-4 border-black p-8 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] relative">
                            <div className="absolute -left-3 -top-3 bg-black text-white w-10 h-10 rounded-full flex items-center justify-center font-black text-lg border-2 border-white shadow-md">
                                {idx + 1}
                            </div>
                            
                            <div 
                                onDrop={(e) => !submitted && handleDrop(e, p.id)}
                                onDragOver={handleDragOver}
                                className={`
                                    min-h-[80px] border-4 border-dashed rounded-2xl mb-6 flex items-center justify-center p-4 transition-all
                                    ${matchedHeading 
                                        ? (submitted 
                                            ? (isCorrect ? 'bg-emerald-100 border-emerald-500' : 'bg-rose-100 border-rose-500')
                                            : 'bg-yellow-50 border-yellow-400 shadow-inner') 
                                        : 'bg-slate-50 border-slate-300'
                                    }
                                `}
                            >
                                {matchedHeading ? (
                                    <div className="font-bold text-lg text-black flex items-center gap-3 w-full justify-between">
                                        <span className="font-serif italic text-xl">"{matchedHeading.text}"</span>
                                        {submitted && (
                                            <div className={`p-1 rounded-full ${isCorrect ? 'bg-emerald-500 text-white' : 'bg-rose-500 text-white'}`}>
                                                {isCorrect ? <Check className="w-5 h-5" /> : <RefreshCw className="w-5 h-5" />}
                                            </div>
                                        )}
                                    </div>
                                ) : (
                                    <div className="text-slate-400 font-black uppercase tracking-widest text-xs flex items-center gap-2">
                                        <FileText className="w-4 h-4" /> Drop Heading Here
                                    </div>
                                )}
                            </div>
                            <p className="text-slate-800 leading-loose font-medium text-lg border-l-4 border-slate-200 pl-6">{p.text}</p>
                        </div>
                    );
                })}
            </div>

            {/* Headings Draggables */}
            <div className="w-full lg:w-1/3">
                 <div className="sticky top-24 bg-slate-900 rounded-[2.5rem] p-8 text-white border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,0.3)]">
                     <h3 className="text-sm font-black uppercase tracking-widest text-slate-400 mb-6 flex items-center gap-2">
                         <LayoutGrid className="w-4 h-4" /> Available Headings
                     </h3>
                     
                     <div className="space-y-4">
                         {(game.headings || []).map(h => {
                             const isUsed = Object.values(matches).includes(h.id);
                             return (
                                 <div 
                                    key={h.id}
                                    draggable={!submitted && !isUsed}
                                    onDragStart={(e) => handleDragStart(e, h.id)}
                                    className={`
                                        bg-yellow-200 text-slate-900 p-4 rounded-xl border-2 border-black font-bold cursor-grab active:cursor-grabbing transition-all relative group
                                        ${isUsed ? 'opacity-30 cursor-default scale-95 grayscale' : 'hover:-translate-y-1 hover:rotate-1 hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]'}
                                    `}
                                 >
                                     {!isUsed && <GripVertical className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-yellow-600 opacity-50" />}
                                     <span className="pl-6 block font-serif italic text-lg">{h.text}</span>
                                 </div>
                             );
                         })}
                     </div>

                     {!submitted ? (
                         <button 
                            onClick={handleSubmit}
                            disabled={Object.keys(matches).length < (game.paragraphs || []).length}
                            className="w-full mt-8 bg-emerald-500 text-black py-4 rounded-xl font-black uppercase tracking-wider border-2 border-black hover:bg-emerald-400 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 active:translate-y-0 active:shadow-none transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                             Check Answers
                         </button>
                     ) : (
                         <div className="mt-8 text-center animate-fade-in">
                             <p className="text-xs font-black uppercase tracking-widest text-slate-400 mb-2">Final Score</p>
                             <div className="text-6xl font-black mb-6 text-emerald-400 drop-shadow-md">{score}/{game.paragraphs.length}</div>
                             <button 
                                onClick={onComplete} 
                                className="w-full bg-white text-black py-4 rounded-xl font-black uppercase tracking-wider hover:bg-indigo-50 transition-colors border-2 border-transparent hover:border-black"
                             >
                                 Finish & Exit
                             </button>
                         </div>
                     )}
                 </div>
            </div>
        </div>
    </div>
  );
};

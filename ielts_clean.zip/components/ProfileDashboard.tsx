import React, { useEffect, useRef, useState } from 'react';
import { UserProfile, SubscriptionPlan } from '../types';
import {
  X, LogOut, RefreshCw, Activity, Edit3, Star, Zap,
  Trophy, Shield, Check, Upload, Crown, Flame, Camera,
  Moon, Sun, Bell, ChevronRight, BookOpen
} from 'lucide-react';
import { sfx } from '../services/soundService';
import { motion, AnimatePresence } from 'framer-motion';

interface Props {
  userProfile: UserProfile;
  onComplete: (p: UserProfile) => void;
  onBack: () => void;
  onStartAssessment: () => void;
  onEditIdentity: () => void;
}

const PLAN_RANK: Record<SubscriptionPlan, number> = { free:0, pro:1, elite:2 };
const RANKS = [
  { min:0,    label:'Newcomer', color:'#94a3b8' },
  { min:300,  label:'Student',  color:'#4ade80' },
  { min:600,  label:'Scholar',  color:'#60a5fa' },
  { min:1000, label:'Expert',   color:'#fbbf24' },
  { min:1500, label:'Master',   color:'#f472b6' },
  { min:2000, label:'Legend',   color:'#a78bfa' },
];
const getRank = (xp: number) => [...RANKS].reverse().find(r => xp >= r.min) || RANKS[0];

const TITLE_STYLE: Record<string, string> = {
  owner:    'bg-gradient-to-r from-amber-400 to-orange-400 text-black border-amber-600',
  manager:  'bg-gradient-to-r from-fuchsia-500 to-purple-600 text-white border-fuchsia-700',
  verified: 'bg-gradient-to-r from-cyan-400 to-blue-500 text-white border-cyan-600',
  student:  'bg-gradient-to-r from-lime-400 to-emerald-500 text-black border-lime-600',
};

// ── XP ring ───────────────────────────────────────────────────────────────────
function XPRing({ xp, max, color, size=88 }: { xp:number; max:number; color:string; size?:number }) {
  const [w, setW] = useState(0);
  const r=(size-10)/2, circ=2*Math.PI*r;
  useEffect(() => { const t=setTimeout(()=>setW(xp/max),400); return ()=>clearTimeout(t); },[xp,max]);
  return (
    <svg width={size} height={size} className="absolute inset-0 rotate-[-90deg]">
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth={6}/>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={6} strokeLinecap="round"
        strokeDasharray={circ} strokeDashoffset={circ*(1-w)}
        style={{transition:'stroke-dashoffset 1.2s ease-out',filter:`drop-shadow(0 0 5px ${color})`}}/>
    </svg>
  );
}

// ── Animated banner display ───────────────────────────────────────────────────
function BannerBG({ profile }: { profile: UserProfile }) {
  // Only custom upload — no preset banners
  if (profile.customBannerUrl) {
    return (
      <>
        <img src={profile.customBannerUrl} className="absolute inset-0 w-full h-full object-cover" alt="" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/60" />
      </>
    );
  }
  // Default — dark gradient matching Discord's default
  return (
    <div className="absolute inset-0 bg-gradient-to-br from-stone-700 to-stone-900" />
  );
}

export const ProfileDashboard: React.FC<Props> = ({ userProfile, onComplete, onBack, onStartAssessment, onEditIdentity }) => {
  const plan = userProfile.plan ?? 'free';
  const XP = 620, NEXT_XP = 1000;
  const rank = getRank(XP);
  const dark = userProfile.darkMode ?? false;

  const [tab, setTab] = useState<'overview'|'avatar'|'banner'|'settings'>('overview');
  const [local, setLocal] = useState<UserProfile>(userProfile);
  const fileRef   = useRef<HTMLInputElement>(null);
  const bannerRef = useRef<HTMLInputElement>(null);

  useEffect(() => { sfx.profileOpen(); }, []);

  const save = (u: UserProfile) => {
    setLocal(u);
    localStorage.setItem('ielts_user_profile', JSON.stringify(u));
    onComplete(u); sfx.xp();
  };

  const handleAvatar = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]; if (!f) return;
    const r = new FileReader();
    r.onloadend = () => save({ ...local, avatar: r.result as string });
    r.readAsDataURL(f);
  };

  const handleBanner = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (PLAN_RANK[plan] < 1) { alert('Upgrade to Pro to upload a custom banner.'); return; }
    const f = e.target.files?.[0]; if (!f) return;
    // Preserve full image — no cropping, use object-cover to fill nicely
    const r = new FileReader();
    r.onloadend = () => save({ ...local, customBannerUrl: r.result as string });
    r.readAsDataURL(f);
  };

  const s = dark ? {
    bg: 'bg-[#1e1f22]', card: 'bg-[#2b2d31]', border: 'border-[#3f4147]',
    text: 'text-white', sub: 'text-[#b5bac1]', muted: 'text-[#87898c]',
    input: 'bg-[#383a40] border-[#3f4147] text-white placeholder:text-[#87898c]',
    hover: 'hover:bg-[#35373c]', btn: 'bg-[#4e5058]',
  } : {
    bg: 'bg-stone-50', card: 'bg-white', border: 'border-stone-200',
    text: 'text-stone-900', sub: 'text-stone-500', muted: 'text-stone-400',
    input: 'bg-white border-stone-200 text-stone-900 placeholder:text-stone-300',
    hover: 'hover:bg-stone-50', btn: 'bg-stone-100',
  };

  const AVATARS = ['Felix','Mia','Leo','Zara','Oscar','Nora','Max','Luna','Kai','Iris'].map((sd,i)=>({
    seed: sd, bg: ['6366f1','f43f5e','f59e0b','10b981','06b6d4','a855f7','f97316','84cc16','ec4899','14b8a6'][i]
  }));

  const badges = [
    { icon:Star,    label:'First Login',  earned:true,          col:'#fbbf24' },
    { icon:Zap,     label:'Speed Run',    earned:true,          col:'#22d3ee' },
    { icon:Trophy,  label:'Band 7+',      earned:plan!=='free', col:'#4ade80' },
    { icon:Shield,  label:'Perfect',      earned:false,         col:'#94a3b8' },
    { icon:Flame,   label:'7-Day',        earned:false,         col:'#94a3b8' },
    { icon:Crown,   label:'Elite',        earned:plan==='elite',col:'#fbbf24' },
  ];

  return (
    // Backdrop overlay — modal style like game preview
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-md flex items-center justify-center p-4"
      onClick={(e) => { if (e.target === e.currentTarget) { sfx.back(); onBack(); } }}>

      <motion.div
        initial={{ scale:0.95, opacity:0, y:16 }}
        animate={{ scale:1, opacity:1, y:0 }}
        exit={{ scale:0.95, opacity:0 }}
        transition={{ duration:0.25, ease:[0.16,1,0.3,1] }}
        className={`w-full max-w-lg rounded-3xl overflow-hidden border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] flex flex-col max-h-[90vh] ${s.bg}`}
        style={{ fontFamily:"'Inter',sans-serif" }}
        onClick={e => e.stopPropagation()}
      >
        {/* ── Banner area (Discord proportions: ~10:3 aspect) ──────────── */}
        <div className="relative h-[120px] overflow-hidden flex-shrink-0">
          <BannerBG profile={local} />

          {/* Close */}
          <button onClick={() => { sfx.back(); onBack(); }}
            className="absolute top-3 right-3 z-10 w-7 h-7 bg-black/50 hover:bg-black/70 backdrop-blur-sm rounded-lg flex items-center justify-center text-white transition-all">
            <X className="w-3.5 h-3.5" />
          </button>

          {/* Edit banner button */}
          <button onClick={() => setTab('banner')}
            className="absolute bottom-2 right-2 z-10 flex items-center gap-1.5 px-2.5 py-1.5 bg-black/50 hover:bg-black/70 backdrop-blur-sm rounded-lg text-white text-[10px] font-black uppercase tracking-widest transition-all border border-white/20">
            <Camera className="w-3 h-3" /> Edit Banner
          </button>
        </div>

        {/* ── Avatar + name section ────────────────────────────────────── */}
        <div className={`${s.card} px-5 pb-4 relative flex-shrink-0`}>
          {/* Avatar overlapping banner */}
          <div className="absolute -top-10 left-5 z-10">
            <div className="relative w-20 h-20">
              <XPRing xp={XP} max={NEXT_XP} color={rank.color} size={80} />
              <div className="absolute inset-[6px] rounded-full overflow-hidden ring-4 ring-black shadow-xl">
                <img src={local.avatar} className="w-full h-full object-cover" alt="" />
              </div>
              <button onClick={() => setTab('avatar')}
                className="absolute -bottom-0.5 -right-0.5 w-7 h-7 bg-[#5865f2] rounded-full border-4 border-black flex items-center justify-center shadow-md hover:bg-[#4752c4] transition-colors">
                <Edit3 className="w-3 h-3 text-white" />
              </button>
            </div>
          </div>

          {/* Action buttons top right */}
          <div className="flex justify-end gap-2 pt-3 mb-2">
            <button onClick={() => { sfx.click(); onEditIdentity(); }}
              className={`flex items-center gap-1.5 px-3 py-2 ${s.btn} border-2 ${s.border} rounded-xl ${s.text} font-bold text-xs uppercase tracking-widest hover:border-black transition-all`}>
              <Edit3 className="w-3.5 h-3.5" /> Edit
            </button>
            <button onClick={() => { sfx.select(); onStartAssessment(); }}
              className={`flex items-center gap-1.5 px-3 py-2 ${s.btn} border-2 ${s.border} rounded-xl ${s.text} font-bold text-xs uppercase tracking-widest hover:border-black transition-all`}>
              <RefreshCw className="w-3.5 h-3.5" /> Test
            </button>
          </div>

          {/* Name + title + rank (Discord card layout) */}
          <div className={`mt-10 ${s.card} rounded-2xl border-2 ${s.border} p-4`}>
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <h1 className={`font-black text-lg ${s.text} uppercase tracking-tight leading-none`}>{local.name}</h1>
              {(local as any).title && (
                <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md border-2 font-black text-[9px] uppercase tracking-widest shadow-[2px_2px_0px_0px_rgba(0,0,0,0.8)] ${TITLE_STYLE[(local as any).title] || ''}`}>
                  {(local as any).title}
                </span>
              )}
              <span className="inline-flex items-center px-2 py-0.5 rounded-md border-2 border-black font-black text-[9px] uppercase tracking-widest text-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
                style={{ background: rank.color }}>
                {rank.label}
              </span>
            </div>
            <p className={`text-xs ${s.sub} font-medium`}>{XP} XP · {NEXT_XP - XP} to next rank</p>

            {/* XP progress bar */}
            <div className={`mt-3 h-1.5 ${dark ? 'bg-[#383a40]' : 'bg-stone-100'} rounded-full overflow-hidden`}>
              <motion.div initial={{width:0}} animate={{width:`${(XP/NEXT_XP)*100}%`}}
                transition={{duration:1.2,ease:'easeOut',delay:0.3}}
                className="h-full rounded-full" style={{background:rank.color,boxShadow:`0 0 8px ${rank.color}88`}}/>
            </div>

            {/* Member since */}
            <p className={`text-[10px] ${s.muted} font-medium mt-2 uppercase tracking-widest`}>
              Member since Jan 2025 · Band {local.targetBand} target
            </p>
          </div>
        </div>

        {/* ── Tabs ─────────────────────────────────────────────────────── */}
        <div className={`flex border-b-2 ${s.border} px-5 flex-shrink-0 ${s.card}`}>
          {(['overview','avatar','banner','settings'] as const).map(t => (
            <button key={t} onClick={() => { sfx.click(); setTab(t); }}
              className={`px-3 py-2.5 text-[11px] font-black uppercase tracking-widest border-b-2 -mb-[2px] transition-all ${tab===t ? (dark ? 'border-[#5865f2] text-white' : 'border-stone-900 text-stone-900') : `border-transparent ${s.muted} ${s.hover}`}`}>
              {t}
            </button>
          ))}
        </div>

        {/* ── Tab content (scrollable) ──────────────────────────────────── */}
        <div className={`flex-1 overflow-y-auto px-5 py-4 space-y-3 ${s.bg}`}>
          <AnimatePresence mode="wait">

            {/* OVERVIEW ─────────────────────────────────────────────────── */}
            {tab === 'overview' && (
              <motion.div key="ov" initial={{opacity:0,y:6}} animate={{opacity:1,y:0}} exit={{opacity:0}} transition={{duration:0.18}} className="space-y-3">

                <div className="grid grid-cols-3 gap-2.5">
                  {[
                    { label:'Level', val:(userProfile.proficiencyLevel||'').replace('Band ',''), col:'bg-amber-400' },
                    { label:'Target', val:`Band ${userProfile.targetBand}`, col:'bg-lime-400' },
                    { label:'Sessions', val:'12', col:'bg-cyan-400' },
                  ].map(c => (
                    <div key={c.label} className={`${c.col} border-4 border-black rounded-xl p-3 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] text-center`}>
                      <p className="text-[9px] font-black uppercase tracking-widest text-black/60">{c.label}</p>
                      <p className="font-black text-sm text-black">{c.val}</p>
                    </div>
                  ))}
                </div>

                <div>
                  <p className={`text-[10px] font-black uppercase tracking-[0.2em] ${s.muted} mb-2.5`}>Badges</p>
                  <div className="grid grid-cols-6 gap-2">
                    {badges.map(b => (
                      <div key={b.label} className={`flex flex-col items-center gap-1 p-2 rounded-xl border-2 transition-all ${b.earned ? 'border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]' : `${s.border} opacity-40`}`}
                        style={b.earned ? { background: `${b.col}33`, borderColor: b.col } : {}}>
                        <b.icon className="w-4 h-4" style={b.earned ? { color: b.col } : {}} />
                        <span className={`text-[7px] font-black uppercase text-center leading-tight ${b.earned ? s.text : s.muted}`}>{b.label}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className={`h-px ${dark ? 'bg-[#3f4147]' : 'bg-stone-200'}`} />
                <button onClick={() => { sfx.back(); localStorage.clear(); window.location.reload(); }}
                  className="flex items-center gap-2 px-4 py-2.5 bg-rose-500 text-white border-4 border-black rounded-xl font-black text-xs uppercase tracking-widest shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-all">
                  <LogOut className="w-3.5 h-3.5" /> Sign Out
                </button>
              </motion.div>
            )}

            {/* AVATAR ────────────────────────────────────────────────────── */}
            {tab === 'avatar' && (
              <motion.div key="av" initial={{opacity:0,y:6}} animate={{opacity:1,y:0}} exit={{opacity:0}} transition={{duration:0.18}} className="space-y-4">
                <button onClick={() => fileRef.current?.click()}
                  className={`w-full flex items-center gap-4 p-4 ${s.card} border-4 border-black rounded-2xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] transition-all group`}>
                  <div className="w-10 h-10 bg-stone-100 border-4 border-black rounded-xl flex items-center justify-center group-hover:bg-amber-400 transition-colors shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                    <Upload className="w-5 h-5 text-black" />
                  </div>
                  <div>
                    <p className={`font-black text-sm uppercase tracking-wide ${s.text}`}>Upload Your Photo</p>
                    <p className={`text-xs ${s.sub}`}>Any image · becomes your avatar</p>
                  </div>
                </button>
                <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleAvatar} />

                <p className={`text-[10px] font-black uppercase tracking-[0.2em] ${s.muted}`}>Quick Avatars</p>
                <div className="grid grid-cols-5 gap-2.5">
                  {AVATARS.map(a => {
                    const url = `https://api.dicebear.com/7.x/initials/svg?seed=${a.seed}&backgroundColor=${a.bg}&fontFamily=Arial&fontSize=40`;
                    const active = local.avatar === url;
                    return (
                      <button key={a.seed} onClick={() => save({...local, avatar:url})}
                        className={`aspect-square rounded-xl border-4 overflow-hidden transition-all ${active ? 'border-black shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] scale-110' : `${s.border} hover:border-stone-500`}`}>
                        <img src={url} className="w-full h-full" alt="" />
                      </button>
                    );
                  })}
                </div>
              </motion.div>
            )}

            {/* BANNER ─────────────────────────────────────────────────────── */}
            {tab === 'banner' && (
              <motion.div key="bn" initial={{opacity:0,y:6}} animate={{opacity:1,y:0}} exit={{opacity:0}} transition={{duration:0.18}} className="space-y-4">
                {/* Live preview */}
                <div className={`${s.card} border-4 border-black rounded-2xl overflow-hidden shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]`}>
                  <div className="relative h-20 overflow-hidden">
                    <BannerBG profile={local} />
                  </div>
                  <div className="relative px-4 pb-4">
                    <div className="absolute -top-7 left-4">
                      <div className="relative w-14 h-14">
                        <XPRing xp={XP} max={NEXT_XP} color={rank.color} size={56} />
                        <div className="absolute inset-[5px] rounded-full overflow-hidden ring-2 ring-black">
                          <img src={local.avatar} className="w-full h-full object-cover" alt="" />
                        </div>
                      </div>
                    </div>
                    <div className="pt-9">
                      <p className={`font-black text-sm ${s.text} uppercase`}>{local.name}</p>
                      <p className={`text-[10px] ${s.sub} font-medium`}>{rank.label} · {XP} XP</p>
                    </div>
                  </div>
                </div>

                {/* Upload */}
                <button onClick={() => bannerRef.current?.click()}
                  className={`w-full flex items-center gap-4 p-4 ${s.card} border-4 border-black rounded-2xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] transition-all group ${PLAN_RANK[plan] < 1 ? 'opacity-60 cursor-not-allowed' : ''}`}>
                  <div className="w-10 h-10 bg-[#5865f2] border-4 border-black rounded-xl flex items-center justify-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] group-hover:scale-105 transition-transform">
                    <Camera className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className={`font-black text-sm uppercase tracking-wide ${s.text}`}>
                      Upload Banner {PLAN_RANK[plan] < 1 && '— Pro required'}
                    </p>
                    <p className={`text-xs ${s.sub}`}>Any image · full display · no cropping</p>
                  </div>
                </button>
                <input ref={bannerRef} type="file" accept="image/*" className="hidden" onChange={handleBanner} />

                {local.customBannerUrl && (
                  <button onClick={() => save({...local, customBannerUrl: undefined})}
                    className="text-xs text-rose-500 font-bold hover:underline">
                    Remove custom banner
                  </button>
                )}

                {PLAN_RANK[plan] < 1 && (
                  <div className={`flex items-center gap-3 p-4 bg-amber-400/10 border-2 border-amber-400/40 rounded-xl`}>
                    <Crown className="w-5 h-5 text-amber-500 flex-shrink-0" />
                    <div>
                      <p className={`font-black text-sm ${s.text}`}>Custom banners need Pro</p>
                      <p className={`text-xs ${s.sub}`}>Upgrade to show any image as your profile banner</p>
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {/* SETTINGS ────────────────────────────────────────────────────── */}
            {tab === 'settings' && (
              <motion.div key="st" initial={{opacity:0,y:6}} animate={{opacity:1,y:0}} exit={{opacity:0}} transition={{duration:0.18}} className="space-y-3">

                {/* Dark mode toggle */}
                <div className={`flex items-center justify-between p-4 ${s.card} border-4 border-black rounded-2xl shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]`}>
                  <div className="flex items-center gap-3">
                    {dark ? <Moon className="w-5 h-5 text-[#5865f2]" /> : <Sun className="w-5 h-5 text-amber-500" />}
                    <div>
                      <p className={`font-black text-sm ${s.text} uppercase tracking-wide`}>Dark Mode</p>
                      <p className={`text-xs ${s.sub}`}>Toggle between light and dark theme</p>
                    </div>
                  </div>
                  <button onClick={() => save({...local, darkMode: !local.darkMode})}
                    className={`relative w-12 h-6 rounded-full border-2 border-black transition-colors shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] ${local.darkMode ? 'bg-[#5865f2]' : 'bg-stone-200'}`}>
                    <span className={`absolute top-0.5 w-4 h-4 bg-white border-2 border-black rounded-full transition-all shadow-sm ${local.darkMode ? 'left-6' : 'left-0.5'}`} />
                  </button>
                </div>

                {/* Notification row */}
                {[
                  { label:'Streak Reminders', sub:'Daily reminder to study', key:'notifStreak' },
                  { label:'Challenge Alerts', sub:'When friends challenge you', key:'notifChallenge' },
                  { label:'Result Summaries', sub:'Session performance emails', key:'notifResults' },
                ].map(item => (
                  <div key={item.key} className={`flex items-center justify-between p-4 ${s.card} border-2 ${s.border} rounded-xl`}>
                    <div className="flex items-center gap-3">
                      <Bell className={`w-4 h-4 ${s.muted}`} />
                      <div>
                        <p className={`font-bold text-sm ${s.text}`}>{item.label}</p>
                        <p className={`text-xs ${s.sub}`}>{item.sub}</p>
                      </div>
                    </div>
                    <button
                      className="relative w-11 h-6 bg-lime-400 border-2 border-black rounded-full shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                      <span className="absolute top-0.5 left-6 w-4 h-4 bg-white border-2 border-black rounded-full" />
                    </button>
                  </div>
                ))}

                <div className={`h-px ${dark ? 'bg-[#3f4147]' : 'bg-stone-200'}`} />
                <button onClick={() => { sfx.back(); localStorage.clear(); window.location.reload(); }}
                  className="flex items-center gap-2 px-4 py-2.5 bg-rose-500 text-white border-4 border-black rounded-xl font-black text-xs uppercase tracking-widest shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-all">
                  <LogOut className="w-3.5 h-3.5" /> Sign Out
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
};

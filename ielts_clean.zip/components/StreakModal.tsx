
import React from 'react';
import { X, Flame, Snowflake, Shield, Calendar, AlertCircle, Zap } from 'lucide-react';

interface StreakModalProps {
  onClose: () => void;
  streak: number;
  freezes: number;
  onBuyFreeze: () => void;
  coins: number;
}

type DayStatus = 'ACTIVE' | 'FROZEN' | 'MISSED' | 'FUTURE' | 'TODAY';

export const StreakModal: React.FC<StreakModalProps> = ({ 
  onClose, 
  streak, 
  freezes, 
  onBuyFreeze, 
  coins 
}) => {
  // Mock generation of the "Map" based on current streak
  const generateDays = (): { day: string; status: DayStatus; label: string }[] => {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const todayIndex = new Date().getDay() === 0 ? 6 : new Date().getDay() - 1; // 0-6 index
    
    return days.map((day, index) => {
      let status: DayStatus = 'FUTURE';
      if (index === todayIndex) status = 'TODAY';
      else if (index < todayIndex) {
        // Randomize history for visual demo purposes, keeping logic simple
        const rand = Math.random();
        if (rand > 0.8) status = 'FROZEN';
        else if (rand > 0.2) status = 'ACTIVE';
        else status = 'MISSED';
      }
      return { day, status, label: `${index + 1}` };
    });
  };

  const weekMap = generateDays();

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/90 backdrop-blur-md animate-fade-in perspective-1000">
      {/* Tilted Background Layers */}
      <div className="absolute w-full max-w-lg h-[600px] bg-orange-500 border-4 border-black rounded-[3rem] transform rotate-3 shadow-[16px_16px_0px_0px_rgba(0,0,0,1)] pointer-events-none"></div>
      
      <div className="relative bg-white w-full max-w-lg rounded-[3rem] border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] overflow-hidden animate-scale-in transform -rotate-1 flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-slate-950 p-6 flex justify-between items-center border-b-4 border-black relative z-10">
            <div className="flex items-center gap-3">
                <div className="bg-orange-500 p-2 rounded-xl border-2 border-white shadow-[0_0_15px_rgba(249,115,22,0.5)] animate-pulse-slow">
                    <Flame className="w-6 h-6 text-white fill-white" />
                </div>
                <div>
                    <h2 className="text-2xl font-black text-white uppercase tracking-tighter italic">Streak Map</h2>
                    <p className="text-[10px] font-bold text-orange-400 uppercase tracking-widest">Consistency Protocol</p>
                </div>
            </div>
            <button 
                onClick={onClose} 
                className="bg-white text-black p-2 rounded-xl border-2 border-transparent hover:bg-rose-500 hover:text-white hover:border-white transition-all shadow-[4px_4px_0px_0px_rgba(255,255,255,0.2)] hover:shadow-none hover:translate-x-1 hover:translate-y-1"
            >
                <X className="w-6 h-6" />
            </button>
        </div>

        <div className="flex-1 overflow-y-auto p-8 custom-scrollbar relative">
            {/* Texture */}
            <div className="absolute inset-0 opacity-[0.03] bg-[url('https://grainy-gradients.vercel.app/noise.svg')] pointer-events-none"></div>

            {/* Current Streak Hero */}
            <div className="text-center mb-12 relative z-10">
                <div className="inline-block relative">
                    <div className="absolute inset-0 bg-orange-400 blur-2xl opacity-20 rounded-full"></div>
                    <h3 className="text-8xl font-black text-slate-900 tracking-tighter leading-none relative z-10">
                        {streak}
                    </h3>
                    <Flame className="absolute -top-6 -right-8 w-16 h-16 text-orange-500 fill-orange-500 animate-bounce" />
                </div>
                <p className="text-slate-500 font-black uppercase tracking-[0.3em] text-sm mt-2">Day Streak Active</p>
            </div>

            {/* The Map / Timeline */}
            <div className="space-y-4 mb-12 relative z-10">
                <div className="flex items-center gap-2 mb-4">
                    <Calendar className="w-4 h-4 text-indigo-600" />
                    <span className="text-xs font-black uppercase tracking-widest text-slate-400">Weekly Trajectory</span>
                </div>
                
                <div className="grid grid-cols-7 gap-2 md:gap-3">
                    {weekMap.map((item, idx) => {
                        const isToday = item.status === 'TODAY';
                        return (
                            <div key={idx} className="flex flex-col items-center gap-2 group">
                                <div className={`
                                    w-full aspect-[3/4] rounded-2xl border-2 flex items-center justify-center relative overflow-hidden transition-all duration-300
                                    ${item.status === 'ACTIVE' ? 'bg-orange-400 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] -translate-y-1' : ''}
                                    ${item.status === 'FROZEN' ? 'bg-cyan-300 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]' : ''}
                                    ${item.status === 'MISSED' ? 'bg-slate-200 border-slate-300 grayscale opacity-70' : ''}
                                    ${item.status === 'FUTURE' ? 'bg-white border-slate-200 border-dashed' : ''}
                                    ${isToday ? 'border-4 border-indigo-600 ring-2 ring-indigo-200 scale-110 z-10 bg-white' : ''}
                                `}>
                                    {item.status === 'ACTIVE' && <Flame className="w-6 h-6 text-white fill-white animate-pulse" />}
                                    {item.status === 'FROZEN' && <Snowflake className="w-6 h-6 text-white fill-white" />}
                                    {item.status === 'MISSED' && <Flame className="w-5 h-5 text-slate-400" />}
                                    {item.status === 'TODAY' && <div className="w-3 h-3 bg-indigo-600 rounded-full animate-ping"></div>}
                                    
                                    {isToday && (
                                        <div className="absolute top-0 left-0 w-full h-full bg-indigo-600/10 pointer-events-none"></div>
                                    )}
                                </div>
                                <span className={`text-[10px] font-black uppercase ${isToday ? 'text-indigo-600' : 'text-slate-400'}`}>{item.day}</span>
                            </div>
                        );
                    })}
                </div>
            </div>

            {/* Shield Freeze Section */}
            <div className="bg-slate-50 border-4 border-slate-200 rounded-[2rem] p-6 relative group overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-400/20 rounded-full blur-2xl -translate-y-1/2 translate-x-1/2 pointer-events-none"></div>
                
                <div className="flex justify-between items-start mb-6 relative z-10">
                    <div>
                        <h4 className="text-lg font-black uppercase tracking-tight flex items-center gap-2">
                            <Shield className="w-5 h-5 text-cyan-500 fill-cyan-500" /> Streak Freeze
                        </h4>
                        <p className="text-xs font-bold text-slate-500 mt-1 max-w-[200px]">
                            Protects your streak if you miss a day of training.
                        </p>
                    </div>
                    <div className="text-center bg-white border-2 border-slate-200 px-4 py-2 rounded-xl">
                        <div className="text-2xl font-black text-cyan-600">{freezes}</div>
                        <div className="text-[8px] font-black uppercase tracking-widest text-slate-400">Equipped</div>
                    </div>
                </div>

                <button 
                    onClick={onBuyFreeze}
                    disabled={coins < 200 || freezes >= 2}
                    className={`
                        w-full py-4 rounded-xl border-4 font-black uppercase tracking-widest flex items-center justify-center gap-3 transition-all relative z-10
                        ${freezes >= 2 
                            ? 'bg-slate-200 border-slate-300 text-slate-400 cursor-not-allowed' 
                            : coins < 200 
                                ? 'bg-slate-100 border-slate-300 text-slate-400 cursor-not-allowed'
                                : 'bg-cyan-400 border-black text-black shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[10px_10px_0px_0px_rgba(0,0,0,1)] hover:bg-cyan-300 active:translate-y-0 active:shadow-none'
                        }
                    `}
                >
                    {freezes >= 2 ? (
                        <>Max Capacity Reached</>
                    ) : (
                        <>
                            Get Freeze <span className="bg-black text-white px-2 py-0.5 rounded text-xs ml-1 border border-white/20">200 XP</span>
                        </>
                    )}
                </button>
                {coins < 200 && freezes < 2 && (
                    <div className="mt-3 flex items-center justify-center gap-2 text-rose-500 text-[10px] font-black uppercase tracking-widest">
                        <AlertCircle className="w-3 h-3" /> Insufficient Funds
                    </div>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};


import React, { useState } from 'react';
import { ShopItem, UserProfile } from '../types';
import { ShoppingBag, Star, ArrowLeft, Check, Palette, Frame, Lock, Sparkles, X, Filter, Plus, Crown, Gem, Zap } from 'lucide-react';

interface ShopScreenProps {
  userProfile: UserProfile;
  onBuy: (item: ShopItem) => void;
  onEquip: (type: 'THEME' | 'FRAME', id: string) => void;
  onBack: () => void;
  onAddCoins: () => void;
}

// Extended Item List with Rarity
const ITEMS: ShopItem[] = [
    // --- THEMES ---
    { 
        id: 'theme-monochrome', 
        name: 'Monochrome', 
        type: 'THEME', 
        price: 75, 
        rarity: 'COMMON',
        preview: 'bg-white border-black text-black', 
        description: 'High contrast minimalism for focused study.' 
    },
    { 
        id: 'theme-forest', 
        name: 'Deep Forest', 
        type: 'THEME', 
        price: 150, 
        rarity: 'COMMON',
        preview: 'bg-emerald-950 border-emerald-400 text-emerald-100', 
        description: 'Calm natural tones to soothe the mind.' 
    },
    { 
        id: 'theme-ocean', 
        name: 'Abyss', 
        type: 'THEME', 
        price: 250, 
        rarity: 'RARE',
        preview: 'bg-cyan-950 border-cyan-400 text-cyan-200', 
        description: 'Subaquatic serenity with glowing text.' 
    },
    { 
        id: 'theme-sunset', 
        name: 'Miami Vice', 
        type: 'THEME', 
        price: 300, 
        rarity: 'RARE',
        preview: 'bg-indigo-950 border-rose-400 text-rose-300', 
        description: 'Retrowave synth aesthetics for late nights.' 
    },
    { 
        id: 'theme-cyberpunk', 
        name: 'Night City', 
        type: 'THEME', 
        price: 500, 
        rarity: 'EPIC',
        preview: 'bg-slate-900 border-green-400 text-green-400', 
        description: 'Neon lights, glitch effects, and high tech.' 
    },
    { 
        id: 'theme-luxury', 
        name: 'Executive', 
        type: 'THEME', 
        price: 800, 
        rarity: 'EPIC',
        preview: 'bg-slate-900 border-yellow-400 text-amber-100', 
        description: 'Gold trim and marble finishes for the elite.' 
    },
    { 
        id: 'theme-nebula', 
        name: 'Stardust', 
        type: 'THEME', 
        price: 1200, 
        rarity: 'LEGENDARY',
        preview: 'bg-[#1e1b4b] border-fuchsia-400 text-fuchsia-100', 
        description: 'Drift through the cosmos while you learn.' 
    },
    { 
        id: 'theme-matrix', 
        name: 'The Source', 
        type: 'THEME', 
        price: 2000, 
        rarity: 'LEGENDARY',
        preview: 'bg-black border-green-500 text-green-500 font-mono', 
        description: 'Enter the construct. Pure code interface.' 
    },

    // --- FRAMES ---
    { 
        id: 'frame-stealth', 
        name: 'Ghost Ops', 
        type: 'FRAME', 
        price: 100, 
        rarity: 'COMMON',
        preview: 'border-slate-700 ring-1 ring-white/20', 
        description: 'Low profile tactical frame.' 
    },
    { 
        id: 'frame-cyber', 
        name: 'Netrunner', 
        type: 'FRAME', 
        price: 250, 
        rarity: 'RARE',
        preview: 'border-cyan-400 border-dashed', 
        description: 'Hacked system border with data leaks.' 
    },
    { 
        id: 'frame-gold', 
        name: 'Midas Touch', 
        type: 'FRAME', 
        price: 400, 
        rarity: 'RARE',
        preview: 'border-yellow-400 ring-4 ring-yellow-200', 
        description: 'Luxurious solid gold finish.' 
    },
    { 
        id: 'frame-neon', 
        name: 'Neon Pulse', 
        type: 'FRAME', 
        price: 600, 
        rarity: 'EPIC',
        preview: 'border-fuchsia-500 shadow-[0_0_20px_#d946ef]', 
        description: 'Vibrant glowing aura that pulses.' 
    },
    { 
        id: 'frame-glitch', 
        name: 'System Error', 
        type: 'FRAME', 
        price: 800, 
        rarity: 'EPIC',
        preview: 'border-red-500 border-double shadow-[2px_2px_0px_rgba(255,0,0,0.5)]', 
        description: 'Unstable digital boundary.' 
    },
    { 
        id: 'frame-royal', 
        name: 'Royal Velvet', 
        type: 'FRAME', 
        price: 1000, 
        rarity: 'LEGENDARY',
        preview: 'border-purple-600 ring-4 ring-purple-900', 
        description: 'Fit for a vocabulary king.' 
    },
    { 
        id: 'frame-ice', 
        name: 'Frostbite', 
        type: 'FRAME', 
        price: 1500, 
        rarity: 'LEGENDARY',
        preview: 'border-cyan-200 ring-4 ring-cyan-100 shadow-[0_0_30px_#bae6fd]', 
        description: 'Frozen solid. Emanates cold energy.' 
    },
    { 
        id: 'frame-rgb', 
        name: 'Gamer', 
        type: 'FRAME', 
        price: 2500, 
        rarity: 'LEGENDARY',
        preview: 'border-transparent bg-gradient-to-r from-red-500 via-green-500 to-blue-500 p-1', 
        description: 'RGB lighting for maximum FPS (Frames Per Sentence).' 
    },
];

const RarityBadge = ({ rarity }: { rarity: string }) => {
    const colors = {
        COMMON: 'bg-slate-200 text-slate-600 border-slate-300',
        RARE: 'bg-blue-100 text-blue-600 border-blue-300',
        EPIC: 'bg-purple-100 text-purple-600 border-purple-300',
        LEGENDARY: 'bg-amber-100 text-amber-600 border-amber-300',
    };
    const bg = colors[rarity as keyof typeof colors] || colors.COMMON;
    
    return (
        <span className={`text-[10px] font-black px-2 py-0.5 rounded border uppercase tracking-widest ${bg}`}>
            {rarity}
        </span>
    );
};

export const ShopScreen: React.FC<ShopScreenProps> = ({ userProfile, onBuy, onEquip, onBack, onAddCoins }) => {
  const [filter, setFilter] = useState<'ALL' | 'THEME' | 'FRAME'>('ALL');

  const filteredItems = ITEMS.filter(item => filter === 'ALL' || item.type === filter);

  // Sort by price (low to high) but put legendary at bottom of their price bracket essentially
  filteredItems.sort((a, b) => a.price - b.price);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 text-white overflow-hidden flex flex-col font-sans">
        
        {/* Ambient Background */}
        <div className="absolute inset-0 z-0 pointer-events-none">
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#4f4f4f2e_1px,transparent_1px),linear-gradient(to_bottom,#4f4f4f2e_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]"></div>
            <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] bg-indigo-500/20 rounded-full blur-[128px]"></div>
            <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] bg-fuchsia-500/20 rounded-full blur-[128px]"></div>
        </div>

        {/* Header */}
        <div className="relative z-10 p-6 md:p-8 flex flex-col md:flex-row justify-between items-center border-b border-white/10 bg-slate-950/50 backdrop-blur-xl gap-4">
            <div className="flex items-center gap-4 w-full md:w-auto">
                <button 
                    onClick={onBack}
                    className="p-2 rounded-full hover:bg-white/10 transition-colors group"
                >
                    <ArrowLeft className="w-6 h-6 text-slate-400 group-hover:text-white" />
                </button>
                <div>
                    <h1 className="text-2xl md:text-3xl font-black uppercase tracking-tighter italic flex items-center gap-2">
                        Shop
                    </h1>
                    <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Personalize your look</p>
                </div>
            </div>

            <div className="flex items-center gap-3 bg-slate-900/80 border border-indigo-500/30 pl-5 pr-2 py-2 rounded-2xl shadow-[0_0_20px_rgba(99,102,241,0.15)] w-full md:w-auto justify-between md:justify-end">
                <div className="flex items-center gap-3">
                    <div className="p-1.5 bg-indigo-500 rounded-lg">
                        <Star className="w-4 h-4 text-white fill-current" />
                    </div>
                    <div className="flex flex-col items-end mr-2">
                        <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Balance</span>
                        <span className="text-xl font-black leading-none font-mono">{userProfile.bandCoins}</span>
                    </div>
                </div>
                <button 
                    onClick={onAddCoins}
                    className="p-2 bg-emerald-500 hover:bg-emerald-400 text-black rounded-xl transition-colors active:scale-95 flex items-center gap-1 font-bold text-xs uppercase px-3"
                    title="Add 100 Credits"
                >
                    <Plus className="w-4 h-4" /> Add
                </button>
            </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-hidden flex flex-col md:flex-row relative z-10">
            
            {/* Sidebar Filters */}
            <div className="w-full md:w-64 p-6 border-b md:border-b-0 md:border-r border-white/10 flex md:flex-col gap-4 overflow-x-auto md:overflow-visible">
                <button 
                    onClick={() => setFilter('ALL')}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl font-bold text-sm uppercase tracking-wider transition-all whitespace-nowrap ${filter === 'ALL' ? 'bg-white text-black shadow-lg shadow-white/20' : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'}`}
                >
                    <Filter className="w-4 h-4" /> All Items
                </button>
                <button 
                    onClick={() => setFilter('THEME')}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl font-bold text-sm uppercase tracking-wider transition-all whitespace-nowrap ${filter === 'THEME' ? 'bg-white text-black shadow-lg shadow-white/20' : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'}`}
                >
                    <Palette className="w-4 h-4" /> Themes
                </button>
                <button 
                    onClick={() => setFilter('FRAME')}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl font-bold text-sm uppercase tracking-wider transition-all whitespace-nowrap ${filter === 'FRAME' ? 'bg-white text-black shadow-lg shadow-white/20' : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'}`}
                >
                    <Frame className="w-4 h-4" /> Frames
                </button>
            </div>

            {/* Grid */}
            <div className="flex-1 overflow-y-auto p-6 md:p-8 custom-scrollbar">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {filteredItems.map((item) => {
                        const isOwned = userProfile.inventory.includes(item.id);
                        const isEquipped = item.type === 'THEME' ? userProfile.activeTheme === item.id : userProfile.activeFrame === item.id;
                        const canAfford = userProfile.bandCoins >= item.price;
                        
                        // Card Border based on rarity
                        let borderColor = 'border-white/10';
                        if (item.rarity === 'LEGENDARY') borderColor = 'border-amber-500/50 shadow-[0_0_15px_rgba(245,158,11,0.2)]';
                        else if (item.rarity === 'EPIC') borderColor = 'border-purple-500/50 shadow-[0_0_15px_rgba(168,85,247,0.2)]';
                        else if (item.rarity === 'RARE') borderColor = 'border-blue-500/50';

                        return (
                            <div key={item.id} className={`group relative bg-slate-900/50 backdrop-blur-md border ${borderColor} rounded-3xl overflow-hidden transition-all hover:scale-[1.02] flex flex-col h-full`}>
                                {/* Preview Area */}
                                <div className="h-40 bg-black/40 relative flex items-center justify-center p-6 border-b border-white/5 overflow-hidden">
                                    <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.05),transparent)]"></div>
                                    
                                    {item.type === 'FRAME' ? (
                                        <div className={`w-24 h-24 rounded-full bg-slate-800 relative ${item.preview}`}>
                                            <img 
                                                src={userProfile.avatar} 
                                                alt="Preview" 
                                                className="w-full h-full rounded-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" 
                                            />
                                        </div>
                                    ) : (
                                        <div className={`w-full h-24 rounded-xl relative overflow-hidden shadow-2xl transform group-hover:scale-105 transition-transform ${item.preview.split(' ')[0]} ${item.preview.split(' ')[1]}`}>
                                            {/* Mini UI Mockup */}
                                            <div className="absolute top-0 left-0 w-full h-4 bg-black/20"></div>
                                            <div className="p-3 flex gap-2">
                                                <div className="w-8 h-8 rounded-full bg-white/20"></div>
                                                <div className="flex-1 space-y-2">
                                                    <div className="w-3/4 h-2 bg-white/20 rounded"></div>
                                                    <div className="w-1/2 h-2 bg-white/20 rounded"></div>
                                                </div>
                                            </div>
                                            <div className="absolute bottom-3 right-3 px-2 py-1 rounded bg-black/30 text-[8px] font-black uppercase text-white/70">
                                                Theme
                                            </div>
                                        </div>
                                    )}
                                </div>

                                {/* Details */}
                                <div className="p-5 flex-1 flex flex-col">
                                    <div className="flex justify-between items-start mb-2">
                                        <h3 className="text-lg font-black uppercase tracking-tight text-white">{item.name}</h3>
                                        <RarityBadge rarity={item.rarity || 'COMMON'} />
                                    </div>
                                    <p className="text-sm text-slate-400 font-medium mb-6 flex-1">{item.description}</p>

                                    {isOwned ? (
                                        <button
                                            onClick={() => onEquip(item.type, item.id)}
                                            disabled={isEquipped}
                                            className={`w-full py-3 rounded-xl font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all ${
                                                isEquipped 
                                                ? 'bg-emerald-500 text-black cursor-default shadow-[0_0_15px_rgba(16,185,129,0.4)]' 
                                                : 'bg-white/10 text-white hover:bg-white hover:text-black'
                                            }`}
                                        >
                                            {isEquipped ? <><Check className="w-4 h-4" /> Selected</> : 'Use'}
                                        </button>
                                    ) : (
                                        <button
                                            onClick={() => onBuy(item)}
                                            disabled={!canAfford}
                                            className={`w-full py-3 rounded-xl font-bold uppercase tracking-wider flex items-center justify-center gap-2 border transition-all ${
                                                canAfford 
                                                ? 'bg-cyan-500 text-black border-cyan-500 hover:bg-cyan-400 hover:shadow-[0_0_15px_rgba(6,182,212,0.4)] hover:-translate-y-1' 
                                                : 'bg-transparent border-slate-700 text-slate-500 cursor-not-allowed'
                                            }`}
                                        >
                                            {canAfford ? (
                                                <><Sparkles className="w-4 h-4" /> {item.price}</>
                                            ) : (
                                                <><Lock className="w-4 h-4" /> {item.price}</>
                                            )}
                                        </button>
                                    )}
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    </div>
  );
};


import React, { useState, useEffect, useRef } from 'react';
import { generateSpeakingCueCard, evaluateSpeaking } from '../services/geminiService';
import { SpeakingCueCard, Feedback } from '../types';
import { Loader2, Mic, Play, Clock, CheckCircle, RotateCcw, Activity, ShieldCheck, Star, ArrowRight } from 'lucide-react';

export const SpeakingGameScreen = () => {
    const [phase, setPhase] = useState<'LOADING' | 'CUE_CARD' | 'PREP' | 'SPEAKING' | 'FEEDBACK'>('LOADING');
    const [cueCard, setCueCard] = useState<SpeakingCueCard | null>(null);
    const [timeLeft, setTimeLeft] = useState(0); 
    const [transcript, setTranscript] = useState('');
    const [feedback, setFeedback] = useState<Feedback | null>(null);
    const recognitionRef = useRef<any>(null);

    useEffect(() => {
        loadCueCard();
        
        // Initialize Speech Recognition
        if ('webkitSpeechRecognition' in window) {
            const SpeechRecognition = (window as any).webkitSpeechRecognition;
            recognitionRef.current = new SpeechRecognition();
            recognitionRef.current.continuous = true;
            recognitionRef.current.interimResults = true;

            recognitionRef.current.onresult = (event: any) => {
                let interimTranscript = '';
                let finalTranscript = '';

                for (let i = event.resultIndex; i < event.results.length; ++i) {
                    if (event.results[i].isFinal) {
                        finalTranscript += event.results[i][0].transcript;
                    } else {
                        interimTranscript += event.results[i][0].transcript;
                    }
                }
                setTranscript(prev => prev + finalTranscript + interimTranscript);
            };
            
            // Re-implement simplified handler for better React compatibility
            recognitionRef.current.onresult = (event: any) => {
                let current = '';
                for (let i = 0; i < event.results.length; i++) {
                    current += event.results[i][0].transcript;
                }
                setTranscript(current);
            };
        }
    }, []);

    const loadCueCard = async () => {
        setPhase('LOADING');
        setTranscript('');
        setFeedback(null);
        try {
            const card = await generateSpeakingCueCard();
            setCueCard(card);
            setPhase('CUE_CARD');
        } catch (e) {
            console.error(e);
        }
    };

    const startPrep = () => {
        setPhase('PREP');
        setTimeLeft(60); 
    };

    const startSpeaking = () => {
        setPhase('SPEAKING');
        setTimeLeft(120); 
        setTranscript('');
        recognitionRef.current?.start();
    };

    const finishSpeaking = async () => {
        if (!cueCard) return;
        recognitionRef.current?.stop();
        setPhase('LOADING');
        
        const textToEvaluate = transcript.trim() || "No speech detected.";
        
        try {
            const result = await evaluateSpeaking(cueCard.topic, textToEvaluate);
            setFeedback(result);
            setPhase('FEEDBACK');
        } catch (e) {
            console.error(e);
        }
    };

    useEffect(() => {
        let interval: ReturnType<typeof setInterval>;
        if ((phase === 'PREP' || phase === 'SPEAKING') && timeLeft > 0) {
            interval = setInterval(() => {
                setTimeLeft(t => t - 1);
            }, 1000);
        } else if (timeLeft === 0) {
            if (phase === 'PREP') startSpeaking();
            if (phase === 'SPEAKING') finishSpeaking();
        }
        return () => clearInterval(interval);
    }, [phase, timeLeft]);

    const formatTime = (s: number) => {
        const min = Math.floor(s / 60);
        const sec = s % 60;
        return `${min}:${sec < 10 ? '0' : ''}${sec}`;
    };

    if (phase === 'LOADING') {
        return (
            <div className="flex flex-col items-center justify-center h-[50vh] text-slate-800">
                <Loader2 className="w-16 h-16 text-black animate-spin mb-4" />
                <p className="font-black uppercase tracking-widest">{cueCard ? 'Analyzing Speech...' : 'Generating Topic...'}</p>
            </div>
        );
    }

    if (phase === 'CUE_CARD') {
        return (
            <div className="max-w-2xl mx-auto py-12 px-6 text-center animate-slide-up">
                <div className="bg-white rounded-[2rem] p-12 border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] mb-10">
                    <h2 className="text-4xl font-black text-slate-900 mb-6 uppercase tracking-tighter">Part 2: Long Turn</h2>
                    <p className="text-slate-700 text-lg font-medium leading-relaxed mb-8">
                        You will have <span className="bg-amber-300 px-1 border border-black">1 minute</span> to prepare and <span className="bg-rose-300 px-1 border border-black">2 minutes</span> to speak.
                    </p>
                    <button 
                        onClick={startPrep}
                        className="bg-indigo-600 text-white px-10 py-5 rounded-2xl font-black text-xl shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] border-2 border-black hover:bg-indigo-700 hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transition-all active:translate-y-0 active:shadow-none uppercase tracking-wide"
                    >
                        Start Challenge
                    </button>
                </div>
            </div>
        );
    }

    if (phase === 'FEEDBACK' && feedback) {
        return (
            <div className="max-w-5xl mx-auto py-12 px-6 animate-slide-up">
                <div className="flex flex-col md:flex-row gap-8">
                    {/* Score Card */}
                    <div className="w-full md:w-1/3 bg-slate-900 text-white rounded-[2rem] p-8 border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] text-center flex flex-col items-center justify-center relative overflow-hidden">
                        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.1),transparent)]"></div>
                        <h2 className="text-8xl font-black mb-2 text-emerald-400">{feedback.score}</h2>
                        <p className="text-slate-400 font-bold uppercase tracking-widest text-sm mb-6">Band Score</p>
                        <div className="w-full h-px bg-slate-700 mb-6"></div>
                        <div className="space-y-2 w-full text-sm">
                            <div className="flex justify-between"><span>Fluency</span><span className="font-bold text-white">{feedback.breakdown?.coherence || "?"}</span></div>
                            <div className="flex justify-between"><span>Vocab</span><span className="font-bold text-white">{feedback.breakdown?.vocabulary}</span></div>
                            <div className="flex justify-between"><span>Grammar</span><span className="font-bold text-white">{feedback.breakdown?.grammar}</span></div>
                        </div>
                    </div>

                    {/* Feedback Details */}
                    <div className="w-full md:w-2/3 bg-white rounded-[2rem] p-8 border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
                        <h3 className="text-xl font-black uppercase mb-6 flex items-center gap-3">
                            <Activity className="w-6 h-6 text-indigo-600" /> Examiner Analysis
                        </h3>
                        <p className="text-slate-700 font-medium leading-relaxed mb-8 border-l-4 border-indigo-200 pl-4">
                            "{feedback.analysis}"
                        </p>

                        <div className="bg-indigo-50 p-6 rounded-xl border-2 border-indigo-100 mb-8">
                            <h4 className="text-xs font-black uppercase tracking-widest text-indigo-800 mb-3 flex items-center gap-2">
                                <Star className="w-4 h-4" /> Improved Version
                            </h4>
                            <p className="text-indigo-900 font-medium italic">
                                "{feedback.betterAlternative}"
                            </p>
                        </div>

                        <button 
                            onClick={loadCueCard}
                            className="w-full py-4 bg-black text-white rounded-xl font-black shadow-lg border-2 border-transparent hover:border-black hover:bg-slate-800 transition-all flex items-center justify-center gap-2 uppercase tracking-wide"
                        >
                            <RotateCcw className="w-4 h-4" /> Next Topic
                        </button>
                    </div>
                </div>
                
                {/* Transcript Review */}
                <div className="mt-8 bg-slate-100 rounded-[2rem] p-8 border-4 border-slate-200">
                    <h4 className="text-xs font-black uppercase tracking-widest text-slate-400 mb-4">Your Transcript</h4>
                    <p className="text-slate-600 font-mono text-sm leading-relaxed">{transcript || "No speech recorded."}</p>
                </div>
            </div>
        );
    }

    return (
        <div className="max-w-5xl mx-auto py-12 px-6 animate-slide-up">
            <div className="flex flex-col md:flex-row gap-8">
                {/* CUE CARD */}
                <div className="w-full md:w-1/2 bg-white rounded-[1.5rem] p-10 border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] relative overflow-hidden transform rotate-[-1deg]">
                    <div className="absolute top-0 left-0 w-full h-4 bg-indigo-500 border-b-4 border-black"></div>
                    <span className="text-xs font-black text-slate-400 uppercase tracking-widest mb-6 block mt-4">Candidate Task Card</span>
                    <h3 className="text-3xl font-black text-slate-900 mb-8 leading-tight">{cueCard?.topic}</h3>
                    <ul className="space-y-4 mb-10">
                        {cueCard?.bulletPoints?.map((point, i) => (
                            <li key={i} className="flex gap-4 text-slate-800 font-bold text-lg">
                                <ArrowRight className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
                                {point}
                            </li>
                        ))}
                    </ul>
                    <div className="p-4 bg-slate-100 rounded-xl text-sm text-slate-600 font-medium italic border-2 border-slate-200">
                        "Talk for 1-2 minutes. You have 1 minute to think."
                    </div>
                </div>

                {/* TIMER & CONTROLS */}
                <div className="w-full md:w-1/2 flex flex-col gap-8">
                    <div className={`
                        flex-1 bg-white rounded-[2rem] p-10 border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] flex flex-col items-center justify-center text-center relative overflow-hidden transition-colors duration-500
                        ${phase === 'SPEAKING' ? 'bg-rose-50' : 'bg-amber-50'}
                    `}>
                            {phase === 'SPEAKING' && (
                                <div className="absolute top-6 right-6 flex items-center gap-2 bg-rose-500 text-white px-3 py-1 rounded font-black uppercase tracking-wider text-xs border-2 border-black animate-pulse">
                                    <span className="w-2 h-2 bg-white rounded-full"></span> REC
                                </div>
                            )}

                            <div className={`mb-6 p-6 rounded-full border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] ${phase === 'PREP' ? 'bg-amber-400 text-black' : 'bg-rose-500 text-white'}`}>
                                <Clock className="w-12 h-12" />
                            </div>
                            
                            <h4 className="text-sm font-black uppercase tracking-widest text-slate-500 mb-2">
                                {phase === 'PREP' ? 'Preparation Phase' : 'Speaking Phase'}
                            </h4>
                            <div className={`text-8xl font-mono font-black tracking-tighter drop-shadow-sm ${phase === 'PREP' ? 'text-amber-600' : 'text-rose-600'}`}>
                                {formatTime(timeLeft)}
                            </div>

                            {/* Live Transcript Display */}
                            {phase === 'SPEAKING' && (
                                <div className="w-full mt-6 bg-white/50 border-2 border-black/10 rounded-xl p-4 h-24 overflow-y-auto text-left relative">
                                    <p className="text-sm font-bold text-slate-700 font-mono leading-relaxed">
                                        {transcript || <span className="text-slate-400 italic">Listening...</span>}
                                    </p>
                                </div>
                            )}

                            {phase === 'PREP' && (
                                <button onClick={startSpeaking} className="mt-8 text-black font-bold hover:underline uppercase tracking-wide text-sm">
                                    Skip Prep
                                </button>
                            )}
                            {phase === 'SPEAKING' && (
                                <button onClick={finishSpeaking} className="mt-8 bg-black text-white px-8 py-3 rounded-xl font-bold border-2 border-transparent hover:bg-slate-800 transition-colors uppercase tracking-wide shadow-lg">
                                    Stop & Submit
                                </button>
                            )}
                    </div>
                </div>
            </div>
        </div>
    );
};

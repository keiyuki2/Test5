import * as React from "react"
import { Check } from "lucide-react"

interface CheckboxProps {
  checked?: boolean
  onCheckedChange?: (checked: boolean) => void
  disabled?: boolean
  className?: string
  'aria-invalid'?: boolean
}

const Checkbox = React.forwardRef<HTMLButtonElement, CheckboxProps>(
  ({ checked = false, onCheckedChange, disabled, className = "", ...props }, ref) => (
    <button
      ref={ref}
      role="checkbox"
      aria-checked={checked}
      type="button"
      disabled={disabled}
      onClick={() => !disabled && onCheckedChange?.(!checked)}
      className={[
        "h-5 w-5 shrink-0 rounded-md border-2 border-black bg-white",
        "shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400 focus-visible:ring-offset-1",
        "disabled:cursor-not-allowed disabled:opacity-50",
        "transition-all duration-150 flex items-center justify-center",
        checked
          ? "bg-amber-400 shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] translate-x-px translate-y-px"
          : "hover:bg-stone-50",
        className,
      ].join(" ")}
      {...props}
    >
      {checked && <Check className="h-3.5 w-3.5 text-black" strokeWidth={3} />}
    </button>
  )
)
Checkbox.displayName = "Checkbox"

export { Checkbox }

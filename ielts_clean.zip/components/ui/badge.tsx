import * as React from "react"

export type BadgeVariant = "default" | "secondary" | "destructive" | "outline" | "success" | "warning" | "owner" | "manager" | "verified" | "student"

interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: BadgeVariant
}

const styles: Record<BadgeVariant, string> = {
  default:     "bg-stone-900 text-white border-stone-900",
  secondary:   "bg-stone-100 text-stone-700 border-stone-300",
  destructive: "bg-rose-500 text-white border-rose-700",
  outline:     "bg-white text-stone-700 border-stone-300",
  success:     "bg-lime-400 text-black border-lime-600",
  warning:     "bg-amber-400 text-black border-amber-600",
  owner:       "border-amber-500 text-amber-900",
  manager:     "border-fuchsia-500 text-fuchsia-900",
  verified:    "border-cyan-500 text-cyan-900",
  student:     "border-emerald-500 text-emerald-900",
}

const gradients: Partial<Record<BadgeVariant, string>> = {
  owner:    "linear-gradient(135deg, #fde68a 0%, #fbbf24 50%, #f59e0b 100%)",
  manager:  "linear-gradient(135deg, #e879f9 0%, #a855f7 50%, #7c3aed 100%)",
  verified: "linear-gradient(135deg, #67e8f9 0%, #22d3ee 50%, #0891b2 100%)",
  student:  "linear-gradient(135deg, #86efac 0%, #4ade80 50%, #16a34a 100%)",
}

const icons: Partial<Record<BadgeVariant, string>> = {
  owner:    "👑",
  manager:  "⚙️",
  verified: "✓",
  student:  "🎓",
}

const shadows: Partial<Record<BadgeVariant, string>> = {
  owner:    "0 0 10px rgba(251,191,36,0.4), 2px 2px 0px rgba(0,0,0,0.8)",
  manager:  "0 0 10px rgba(168,85,247,0.3), 2px 2px 0px rgba(0,0,0,0.8)",
  verified: "0 0 10px rgba(34,211,238,0.3), 2px 2px 0px rgba(0,0,0,0.8)",
  student:  "0 0 8px rgba(74,222,128,0.3), 2px 2px 0px rgba(0,0,0,0.8)",
}

export const Badge = React.forwardRef<HTMLSpanElement, BadgeProps>(
  ({ className = "", variant = "default", children, ...props }, ref) => {
    const isTitle = ['owner','manager','verified','student'].includes(variant)
    return (
      <span ref={ref}
        className={[
          "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-lg border-2 font-black text-[10px] uppercase tracking-widest select-none",
          isTitle ? "" : "shadow-[2px_2px_0px_0px_rgba(0,0,0,0.8)]",
          styles[variant],
          className,
        ].join(" ")}
        style={isTitle ? {
          background: gradients[variant],
          boxShadow: shadows[variant],
        } : undefined}
        {...props}
      >
        {icons[variant] && <span className="text-[11px] leading-none">{icons[variant]}</span>}
        {children}
      </span>
    )
  }
)
Badge.displayName = "Badge"

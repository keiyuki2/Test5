import * as React from "react"

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {}

const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className = "", ...props }, ref) => (
    <textarea
      ref={ref}
      className={[
        "w-full min-h-[80px] rounded-xl border-4 border-black bg-white px-4 py-3",
        "text-sm font-medium text-stone-900 placeholder:text-stone-300",
        "shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]",
        "focus:outline-none focus:border-amber-400 focus:shadow-[3px_3px_0px_0px_rgba(251,191,36,1)]",
        "disabled:opacity-50 disabled:cursor-not-allowed",
        "transition-all resize-none",
        className,
      ].join(" ")}
      {...props}
    />
  )
)
Textarea.displayName = "Textarea"
export { Textarea }

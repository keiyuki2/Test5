import * as React from "react"

interface ToggleProps {
  pressed?: boolean
  onPressedChange?: (pressed: boolean) => void
  disabled?: boolean
  className?: string
  children?: React.ReactNode
  size?: 'sm' | 'md' | 'lg'
  variant?: 'default' | 'outline'
}

const Toggle = React.forwardRef<HTMLButtonElement, ToggleProps>(
  ({ pressed = false, onPressedChange, disabled, className = "", children, size = 'md', variant = 'default', ...props }, ref) => {
    const sizes = { sm: 'h-8 px-3 text-xs', md: 'h-10 px-4 text-sm', lg: 'h-12 px-5 text-base' }
    return (
      <button
        ref={ref}
        type="button"
        role="switch"
        aria-checked={pressed}
        disabled={disabled}
        onClick={() => onPressedChange?.(!pressed)}
        className={[
          "inline-flex items-center justify-center rounded-xl border-2 font-bold uppercase tracking-widest transition-all",
          sizes[size],
          pressed
            ? "bg-stone-900 border-black text-white shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] translate-x-px translate-y-px"
            : variant === 'outline'
              ? "border-stone-300 bg-white text-stone-600 hover:border-black hover:text-stone-900 shadow-[2px_2px_0px_0px_rgba(0,0,0,0.4)]"
              : "border-stone-200 bg-stone-50 text-stone-600 hover:bg-stone-100 hover:border-stone-400",
          disabled ? "opacity-50 cursor-not-allowed" : "",
          className,
        ].join(" ")}
        {...props}
      >
        {children}
      </button>
    )
  }
)
Toggle.displayName = "Toggle"
export { Toggle }

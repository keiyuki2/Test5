
import React, { useState, useEffect, useRef } from 'react';
import { Difficulty } from '../types';
import { generateListeningSection } from '../services/geminiService';
import { Headphones, Play, Pause, RotateCcw, Volume2, Check, X, ArrowRight, Loader2, Radio } from 'lucide-react';

interface ListeningGameScreenProps {
  difficulty: Difficulty;
  onComplete: () => void;
}

export const ListeningGameScreen: React.FC<ListeningGameScreenProps> = ({ difficulty, onComplete }) => {
  const [phase, setPhase] = useState<'MENU' | 'LOADING' | 'PLAYING' | 'FEEDBACK'>('MENU');
  const [section, setSection] = useState(1);
  const [content, setContent] = useState<any>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [score, setScore] = useState(0);
  const [progress, setProgress] = useState(0); // 0-100 for audio progress bar mock

  // Mock Audio Progress
  useEffect(() => {
      let interval: any;
      if (isPlaying) {
          interval = setInterval(() => {
              setProgress(p => {
                  if (p >= 100) {
                      setIsPlaying(false);
                      window.speechSynthesis.cancel();
                      return 100;
                  }
                  return p + 0.5; // Roughly 20 seconds for full bar in mock
              });
          }, 100);
      }
      return () => clearInterval(interval);
  }, [isPlaying]);

  const loadSection = async (sec: number) => {
      setSection(sec);
      setPhase('LOADING');
      try {
          const data = await generateListeningSection(difficulty, sec);
          setContent(data);
          setAnswers({});
          setScore(0);
          setProgress(0);
          setPhase('PLAYING');
      } catch (e) {
          console.error(e);
          setPhase('MENU');
      }
  };

  const toggleAudio = () => {
      if (isPlaying) {
          window.speechSynthesis.pause();
          setIsPlaying(false);
      } else {
          if (progress === 0 || progress === 100) {
              window.speechSynthesis.cancel();
              const u = new SpeechSynthesisUtterance(content.script);
              u.rate = 0.9;
              u.onend = () => { setIsPlaying(false); setProgress(100); };
              window.speechSynthesis.speak(u);
              setProgress(0);
          } else {
              window.speechSynthesis.resume();
          }
          setIsPlaying(true);
      }
  };

  const handleAnswer = (qId: string, option: string) => {
      if (phase === 'FEEDBACK') return;
      setAnswers(prev => ({ ...prev, [qId]: option }));
  };

  const submit = () => {
      let s = 0;
      content.questions.forEach((q: any) => {
          if (answers[q.id] === q.correctAnswer) s++;
      });
      setScore(s);
      setPhase('FEEDBACK');
      window.speechSynthesis.cancel();
  };

  const getSectionColor = (s: number) => {
      switch(s) {
          case 1: return 'bg-cyan-400';
          case 2: return 'bg-rose-400';
          case 3: return 'bg-yellow-400';
          case 4: return 'bg-amber-400 text-black';
          default: return 'bg-white';
      }
  };

  // --- MENU PHASE ---
  if (phase === 'MENU') {
      return (
          <div className="w-full max-w-6xl mx-auto py-12 px-6 animate-slide-up">
              <button onClick={onComplete} className="mb-8 font-black text-xs uppercase tracking-widest text-slate-500 hover:text-black">← Back to Dashboard</button>
              
              <div className="text-center mb-12">
                  <h2 className="text-6xl font-black uppercase tracking-tighter mb-4">Listening <span className="text-indigo-600">Core</span></h2>
                  <p className="text-xl font-bold text-slate-500">Select Frequency Band</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {[
                      { id: 1, title: 'Social Dialogue', desc: 'Two speakers, everyday context.', color: 'bg-cyan-400', icon: Headphones },
                      { id: 2, title: 'Social Monologue', desc: 'One speaker, local guide.', color: 'bg-rose-400', icon: Radio },
                      { id: 3, title: 'Edu Dialogue', desc: 'Multiple speakers, training context.', color: 'bg-yellow-400', icon: Volume2 },
                      { id: 4, title: 'Academic Lecture', desc: 'Complex monologue, abstract.', color: 'bg-amber-500 text-white', icon: Loader2 }
                  ].map((item) => (
                      <button 
                        key={item.id}
                        onClick={() => loadSection(item.id)}
                        className={`group relative h-80 rounded-[2.5rem] border-4 border-black p-8 text-left shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-2 hover:shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] transition-all flex flex-col justify-between overflow-hidden ${item.color}`}
                      >
                          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/noise.png')] opacity-20"></div>
                          <div className="relative z-10">
                              <div className="bg-black text-white w-12 h-12 rounded-xl flex items-center justify-center mb-4 border-2 border-white shadow-md">
                                  <item.icon className="w-6 h-6" />
                              </div>
                              <span className="text-xs font-black uppercase tracking-widest border-2 border-current px-2 py-1 rounded mb-2 inline-block">Section {item.id}</span>
                              <h3 className="text-3xl font-black uppercase leading-none tracking-tight">{item.title}</h3>
                          </div>
                          <p className="relative z-10 font-bold text-sm leading-tight opacity-90">{item.desc}</p>
                      </button>
                  ))}
              </div>
          </div>
      );
  }

  // --- LOADING PHASE ---
  if (phase === 'LOADING') {
      return (
          <div className="flex h-screen items-center justify-center flex-col gap-6 bg-slate-50">
              <div className="w-24 h-24 bg-black rounded-full flex items-center justify-center animate-spin border-4 border-slate-300 border-t-black">
                  <div className="w-8 h-8 bg-white rounded-full"></div>
              </div>
              <p className="font-black text-2xl uppercase tracking-widest text-slate-900 animate-pulse">Tuning Frequency...</p>
          </div>
      );
  }

  // --- PLAYING & FEEDBACK ---
  return (
      <div className="w-full max-w-5xl mx-auto py-8 px-4 flex flex-col min-h-screen">
          {/* Header & Audio Player */}
          <div className="sticky top-4 z-40 mb-8">
              <div className="bg-stone-900 rounded-[2.5rem] p-6 border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] text-white relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-32 bg-amber-400/20 rounded-full blur-[80px]"></div>
                  
                  <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
                      <div className="flex items-center gap-4 w-full md:w-auto">
                          <button onClick={() => setPhase('MENU')} className="bg-stone-800 p-3 rounded-xl hover:bg-slate-700 transition-colors">
                              <RotateCcw className="w-5 h-5" />
                          </button>
                          <div>
                              <h3 className="text-xs font-black uppercase tracking-widest text-slate-400">Now Playing</h3>
                              <p className="text-xl font-black uppercase italic truncate max-w-[200px] md:max-w-md">{content.context}</p>
                          </div>
                      </div>

                      {/* Retro Player Controls */}
                      <div className="flex items-center gap-4 bg-black/40 p-2 rounded-2xl border border-white/10 w-full md:w-auto justify-center">
                          <button 
                            onClick={toggleAudio}
                            className={`w-14 h-14 rounded-xl flex items-center justify-center border-2 border-transparent transition-all ${isPlaying ? 'bg-amber-500 text-white shadow-[0_0_15px_#6366f1]' : 'bg-white text-black hover:bg-slate-200'}`}
                          >
                              {isPlaying ? <Pause className="w-6 h-6 fill-current" /> : <Play className="w-6 h-6 fill-current" />}
                          </button>
                          
                          <div className="flex-1 md:w-64 h-12 bg-stone-800 rounded-lg relative overflow-hidden flex items-center px-2">
                              {/* Fake waveform bars */}
                              <div className="flex items-end gap-1 h-full w-full justify-center py-2 opacity-50">
                                  {Array.from({length: 20}).map((_, i) => (
                                      <div 
                                        key={i} 
                                        className={`w-1.5 bg-amber-400 rounded-full transition-all duration-100 ${isPlaying ? 'animate-pulse' : ''}`}
                                        style={{ height: `${Math.random() * 80 + 20}%`, animationDelay: `${i * 0.05}s` }}
                                      ></div>
                                  ))}
                              </div>
                              <div className="absolute bottom-0 left-0 h-1 bg-amber-500 transition-all duration-100 ease-linear" style={{ width: `${progress}%` }}></div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>

          {/* Content Area */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 flex-1">
              
              {/* Questions Column */}
              <div className="md:col-span-8 space-y-6">
                  {content.questions.map((q: any, idx: number) => (
                      <div key={q.id} className="bg-white rounded-[2rem] border-4 border-black p-8 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)]">
                          <div className="flex gap-4 mb-4">
                              <span className="bg-black text-white w-8 h-8 flex items-center justify-center rounded-full font-black text-sm flex-none">{idx + 1}</span>
                              <h4 className="text-lg font-bold text-slate-900 leading-snug">{q.text}</h4>
                          </div>
                          
                          <div className="space-y-3 pl-12">
                              {q.options.map((opt: string) => {
                                  const isSelected = answers[q.id] === opt;
                                  let btnClass = "w-full text-left p-4 rounded-xl border-2 font-bold text-sm transition-all flex items-center justify-between ";
                                  
                                  if (phase === 'FEEDBACK') {
                                      if (opt === q.correctAnswer) btnClass += "bg-emerald-100 border-emerald-500 text-emerald-900";
                                      else if (isSelected && opt !== q.correctAnswer) btnClass += "bg-rose-100 border-rose-500 text-rose-900";
                                      else btnClass += "bg-slate-50 border-slate-200 text-slate-400";
                                  } else {
                                      if (isSelected) btnClass += "bg-amber-500 border-black text-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] -translate-y-1";
                                      else btnClass += "bg-white border-slate-200 hover:border-black hover:bg-slate-50 text-slate-700";
                                  }

                                  return (
                                      <button 
                                        key={opt}
                                        onClick={() => handleAnswer(q.id, opt)}
                                        disabled={phase === 'FEEDBACK'}
                                        className={btnClass}
                                      >
                                          {opt}
                                          {phase === 'FEEDBACK' && opt === q.correctAnswer && <Check className="w-5 h-5 text-emerald-600" />}
                                          {phase === 'FEEDBACK' && isSelected && opt !== q.correctAnswer && <X className="w-5 h-5 text-rose-600" />}
                                      </button>
                                  );
                              })}
                          </div>
                      </div>
                  ))}
                  
                  {phase !== 'FEEDBACK' && (
                      <button 
                        onClick={submit}
                        disabled={Object.keys(answers).length < content.questions.length}
                        className="w-full py-5 bg-black text-white text-xl font-black uppercase tracking-widest rounded-2xl shadow-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-amber-500 transition-colors"
                      >
                          Submit Section
                      </button>
                  )}
              </div>

              {/* Sidebar: Score & Transcript (Feedback Only) */}
              <div className="md:col-span-4 flex flex-col gap-6">
                  {phase === 'FEEDBACK' ? (
                      <div className="sticky top-32 animate-scale-in">
                          <div className="bg-white rounded-[2.5rem] border-4 border-black p-8 text-center shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] mb-6">
                              <p className="text-xs font-black uppercase tracking-widest text-slate-400 mb-2">Result</p>
                              <div className="text-7xl font-black text-slate-900 mb-2">{score}<span className="text-2xl text-slate-400">/5</span></div>
                              <div className={`inline-block px-4 py-1 rounded-full text-xs font-black uppercase ${score >= 4 ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'}`}>
                                  {score >= 4 ? 'Excellent' : 'Needs Practice'}
                              </div>
                          </div>

                          <div className="bg-slate-50 rounded-[2.5rem] border-4 border-slate-200 p-6 max-h-[400px] overflow-y-auto custom-scrollbar">
                              <h4 className="font-black text-sm uppercase tracking-widest mb-4 border-b-2 border-slate-200 pb-2">Transcript</h4>
                              <p className="text-sm font-medium text-slate-600 leading-relaxed whitespace-pre-wrap">
                                  {content.script}
                              </p>
                          </div>
                          
                          <button onClick={() => setPhase('MENU')} className="w-full mt-6 py-4 bg-white border-4 border-black rounded-xl font-black uppercase hover:bg-slate-100 transition-colors">
                              New Section
                          </button>
                      </div>
                  ) : (
                      <div className="hidden md:block bg-amber-50 rounded-[2.5rem] border-4 border-indigo-100 p-8 text-center opacity-50">
                          <p className="font-black text-amber-400 uppercase text-xs tracking-widest">Feedback Module Offline</p>
                          <p className="text-sm text-amber-500 mt-2">Complete the test to view analysis.</p>
                      </div>
                  )}
              </div>
          </div>
      </div>
  );
};

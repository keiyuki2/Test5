import React, { useState, useEffect, useRef } from 'react';
import { Question, VocabQuestion } from '../types';
import { generateVocabCard } from '../services/geminiService';
import { 
  Send, RefreshCw, Volume2, X, Loader2, Copy, Trash2, 
  Terminal, Activity, Sparkles, Lightbulb, Zap, ChevronRight,
  ShieldCheck, Brain, Fingerprint
} from 'lucide-react';

interface GameScreenProps {
  question: Question;
  onSubmit: (text: string) => void;
  onSkip: () => void;
  isEvaluating: boolean;  currentStep?: number;
  totalSteps?: number;
}

export const GameScreen: React.FC<GameScreenProps> = ({ 
  question, 
  onSubmit, 
  onSkip, 
  isEvaluating,
  currentStep = 1,
  totalSteps = 5
}) => {
  const [input, setInput] = useState('');
  const [showHint, setShowHint] = useState(false);
  const [inspectedWord, setInspectedWord] = useState<{
    word: string; 
    data: VocabQuestion | null; 
    loading: boolean; 
    error: boolean 
  } | null>(null);
  
  const [speakingTarget, setSpeakingTarget] = useState<'question' | 'input' | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  }, [question]);

  useEffect(() => {
      setShowHint(false);
      setInput('');
      return () => { window.speechSynthesis.cancel(); };
  }, [question]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim().length > 5 && !isEvaluating) {
      window.speechSynthesis.cancel();
      onSubmit(input);
    }
  };

  const handleRevealHint = () => {
      if (showHint) return;
      setShowHint(true);
  };

  const handleWordClick = async (word: string) => {
      const cleanWord = word.replace(/[.,/#!$%^&*;:{}=\-_`~()]/g,"");
      if (!cleanWord || cleanWord.length < 2) return;
      setInspectedWord({ word: cleanWord, data: null, loading: true, error: false });
      try {
        const cardData = await generateVocabCard(cleanWord, question.text);
        setInspectedWord({ word: cleanWord, data: cardData, loading: false, error: false });
      } catch (e) {
          setInspectedWord({ word: cleanWord, data: null, loading: false, error: true });
      }
  };

  const handleSpeak = (text: string, target: 'question' | 'input') => {
      if (speakingTarget === target) {
          window.speechSynthesis.cancel();
          setSpeakingTarget(null);
          return;
      }
      window.speechSynthesis.cancel();
      setSpeakingTarget(target);
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'en-GB'; 
      utterance.rate = 0.9;
      utterance.onend = () => setSpeakingTarget(null);
      window.speechSynthesis.speak(utterance);
  };

  const wordCount = input.trim() === '' ? 0 : input.trim().split(/\s+/).length;
  const uniqueWords = new Set(input.trim().toLowerCase().split(/\s+/).filter(w => w.length > 0)).size;
  const diversity = wordCount > 0 ? Math.round((uniqueWords / wordCount) * 100) : 0;

  return (
    <div className="w-full max-w-7xl mx-auto py-6 px-4 animate-fade-in flex flex-col gap-8">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-center gap-6 bg-slate-900 border border-slate-800 p-6 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
          <div className="absolute inset-0 bg-indigo-500/5 pointer-events-none"></div>
          
          <div className="flex items-center gap-5 relative z-10">
              <div className="w-14 h-14 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-glow border border-indigo-400/50 transform rotate-3">
                  <Terminal className="w-7 h-7 text-white" />
              </div>
              <div>
                  <h1 className="text-sm font-black uppercase tracking-[0.3em] text-indigo-400 mb-0.5">IELTS Master</h1>
                  <p className="text-2xl font-black uppercase tracking-tight text-white italic">Writing Practice</p>
              </div>
          </div>

          <div className="flex items-center gap-8 relative z-10">
              <div className="flex flex-col items-center">
                  <span className="text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Progress</span>
                  <div className="flex gap-2 p-1.5 bg-black/40 rounded-xl border border-slate-700">
                      {Array.from({ length: totalSteps }).map((_, i) => (
                          <div 
                            key={i} 
                            className={`w-10 h-1.5 rounded-full transition-all duration-700 ${i + 1 === currentStep ? 'bg-indigo-500 shadow-glow' : i + 1 < currentStep ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]' : 'bg-slate-800'}`}
                          />
                      ))}
                  </div>
              </div>
              <div className="h-10 w-px bg-slate-800 hidden md:block"></div>
              <div className="flex items-center gap-4 bg-black/40 px-6 py-2.5 rounded-2xl border border-slate-700 group cursor-default">
                  <Zap className="w-5 h-5 text-yellow-400 fill-yellow-400 group-hover:scale-110 transition-transform" />
                  <div>
                      <span className="text-[9px] font-black uppercase text-slate-500 block leading-none mb-1">Hints</span>
                  </div>
              </div>
          </div>
      </div>

      {/* Practice Area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Question & Answer */}
        <div className="lg:col-span-8 flex flex-col gap-8">
            
            {/* Question */}
            <div className="relative group">
                <div className="absolute inset-0 bg-indigo-600/10 blur-[120px] rounded-full pointer-events-none group-hover:bg-indigo-600/20 transition-all duration-1000"></div>
                <div className="relative bg-[#0c1222] border-2 border-slate-700/50 rounded-[3.5rem] p-10 md:p-14 shadow-2xl overflow-hidden backdrop-blur-3xl">
                    {/* Scan Effect */}
                    <div className="absolute inset-0 pointer-events-none">
                        <div className="absolute top-0 left-0 w-full h-[2px] bg-indigo-500/30 blur-[1px] animate-scan"></div>
                        <div className="absolute inset-0 bg-[radial-gradient(#ffffff05_1px,transparent_1px)] [background-size:20px_20px] opacity-20"></div>
                    </div>
                    
                    <div className="flex justify-between items-start mb-10 relative z-10">
                        <div className="flex items-center gap-3 bg-indigo-500/10 px-4 py-1.5 rounded-full border border-indigo-500/20">
                            <Activity className="w-4 h-4 text-indigo-400 animate-pulse" />
                            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-300">Topic: {question.context || "Standard Academic"}</span>
                        </div>
                        <button onClick={() => handleSpeak(question.text, 'question')} className={`p-4 rounded-2xl border-2 border-slate-700 transition-all hover:bg-indigo-600 hover:border-indigo-400 hover:text-white group ${speakingTarget === 'question' ? 'bg-indigo-600 border-indigo-400 shadow-glow' : 'bg-slate-800 text-slate-400'}`}>
                            <Volume2 className="w-6 h-6 group-active:scale-90" />
                        </button>
                    </div>

                    <h2 className="text-3xl md:text-5xl font-black text-white leading-tight tracking-tight relative z-10 selection:bg-indigo-500">
                        {question.text.split(' ').map((word, i) => (
                            <span 
                              key={i} 
                              onClick={() => handleWordClick(word)}
                              className={`inline-block cursor-pointer px-1 rounded-lg transition-all duration-300 border-b-2 border-transparent hover:border-indigo-500/50 hover:bg-indigo-500/10 hover:-translate-y-0.5 ${inspectedWord?.word === word.replace(/[.,/#!$%^&*;:{}=\-_`~()]/g,"") ? 'bg-indigo-600 text-white shadow-glow border-indigo-400 translate-y-[-2px]' : ''}`}
                            >
                                {word}{' '}
                            </span>
                        ))}
                    </h2>

                    {/* Word Inspector Overlay */}
                    {inspectedWord && (
                        <div className="absolute top-0 right-0 bottom-0 w-full md:w-[400px] bg-slate-900 border-l border-indigo-500/50 shadow-[-20px_0_40px_rgba(0,0,0,0.5)] z-40 p-10 flex flex-col animate-slide-up backdrop-blur-xl">
                            <div className="flex justify-between items-start mb-10">
                                <div>
                                    <h3 className="text-4xl font-black capitalize text-white tracking-tighter mb-2">{inspectedWord.word}</h3>
                                    {!inspectedWord.loading && inspectedWord.data && (
                                        <span className="px-3 py-1 bg-emerald-500 text-black text-[10px] font-black rounded-lg uppercase tracking-widest border border-emerald-400">Band {inspectedWord.data.band}</span>
                                    )}
                                </div>
                                <button onClick={() => setInspectedWord(null)} className="p-3 hover:bg-rose-500/20 hover:text-rose-400 rounded-xl transition-all"><X className="w-7 h-7" /></button>
                            </div>

                            {inspectedWord.loading ? (
                                <div className="flex-1 flex flex-col items-center justify-center gap-4">
                                    <Loader2 className="w-12 h-12 animate-spin text-indigo-500" />
                                    <p className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-400/60 animate-pulse">Loading...</p>
                                </div>
                            ) : (
                                <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 space-y-10 animate-fade-in">
                                    <div>
                                        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-4 flex items-center gap-2">
                                            <ShieldCheck className="w-3 h-3" /> Definition
                                        </p>
                                        <p className="text-xl font-bold text-slate-200 leading-snug bg-black/30 p-5 rounded-2xl border border-slate-800 shadow-inner">{inspectedWord.data?.definition}</p>
                                    </div>
                                    <div>
                                        <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-4 flex items-center gap-2">
                                            <Sparkles className="w-3 h-3" /> Synonyms
                                        </p>
                                        <div className="flex flex-wrap gap-2">
                                            {inspectedWord.data?.synonyms.map(s => (
                                                <span key={s} className="px-4 py-2 bg-slate-800 border border-slate-700 rounded-xl text-sm font-bold text-slate-300 hover:border-indigo-400 hover:text-white hover:bg-indigo-900/20 transition-all cursor-default shadow-sm">{s}</span>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </div>

            {/* Writing Area */}
            <div className="flex flex-col bg-slate-900 rounded-[3rem] border-2 border-slate-800 shadow-2xl overflow-hidden focus-within:border-indigo-500/50 transition-all duration-500">
                <div className="flex justify-between items-center px-10 py-5 bg-slate-900/50 border-b border-slate-800">
                    <div className="flex items-center gap-3">
                        <div className="p-1.5 bg-emerald-500/10 rounded-lg">
                            <Brain className="w-4 h-4 text-emerald-400" />
                        </div>
                        <span className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-500 italic">Write your answer</span>
                    </div>
                    <div className="flex items-center gap-4">
                         <button onClick={() => navigator.clipboard.writeText(input)} className="p-2.5 text-slate-500 hover:text-white transition-all hover:bg-white/5 rounded-lg"><Copy className="w-4 h-4" /></button>
                         <button onClick={() => setInput('')} className="p-2.5 text-slate-500 hover:text-rose-500 transition-all hover:bg-rose-500/10 rounded-lg"><Trash2 className="w-4 h-4" /></button>
                    </div>
                </div>
                
                <textarea 
                    ref={textareaRef} 
                    value={input} 
                    onChange={(e) => setInput(e.target.value)} 
                    placeholder="Type your answer here..." 
                    className="w-full min-h-[280px] p-10 md:p-14 text-2xl md:text-3xl font-bold text-white placeholder:text-slate-800 bg-transparent border-none outline-none resize-none leading-relaxed font-sans scroll-smooth" 
                    disabled={isEvaluating}
                />

                <div className="px-10 py-8 bg-slate-950/80 border-t border-slate-800 flex flex-col md:flex-row items-center justify-between gap-8">
                    <div className="flex gap-4">
                        <button 
                            type="button" 
                            onClick={handleRevealHint} 
                            disabled={showHint} 
                            className={`flex items-center gap-3 px-8 py-3 rounded-2xl font-black uppercase tracking-widest text-[10px] border-2 transition-all ${showHint ? 'bg-amber-500/10 border-amber-500 text-amber-500' : 'bg-slate-900 border-slate-700 text-slate-500 hover:border-yellow-400 hover:text-yellow-400'}`}
                        >
                            <Lightbulb className={`w-4 h-4 ${showHint ? 'fill-current' : ''}`} />
                            {showHint ? "Hint revealed" : "Get a hint"}
                        </button>
                    </div>

                    <button 
                        onClick={handleSubmit} 
                        disabled={input.trim().length < 5 || isEvaluating} 
                        className={`group relative overflow-hidden flex items-center gap-4 px-16 py-5 rounded-2xl font-black text-xl uppercase tracking-[0.2em] transition-all ${input.trim().length < 5 || isEvaluating ? 'bg-slate-800 text-slate-600 opacity-50 cursor-not-allowed' : 'bg-indigo-600 text-white shadow-glow hover:bg-indigo-500 hover:-translate-y-1'}`}
                    >
                        <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
                        {isEvaluating ? <RefreshCw className="w-7 h-7 animate-spin" /> : <><Send className="w-6 h-6" /> Submit Answer</>}
                    </button>
                </div>
            </div>
        </div>

        {/* Stats */}
        <div className="lg:col-span-4 flex flex-col gap-6">
            <div className="bg-[#0c1222]/80 backdrop-blur-xl p-10 rounded-[3rem] border border-slate-700/50 shadow-2xl flex flex-col gap-10">
                <div className="flex items-center gap-4 pb-4 border-b border-slate-800">
                    <Fingerprint className="w-6 h-6 text-indigo-400" />
                    <h3 className="text-xs font-black uppercase tracking-[0.2em] text-slate-400">Stats</h3>
                </div>

                <div className="space-y-8">
                    <div className="flex flex-col gap-3">
                        <div className="flex justify-between items-end">
                            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Word Count</span>
                            <span className="text-lg font-black text-white font-mono">{wordCount} / 45</span>
                        </div>
                        <div className="h-2 w-full bg-black/50 rounded-full border border-slate-800 p-0.5">
                            <div className="h-full bg-indigo-500 shadow-glow transition-all duration-700 ease-out rounded-full" style={{ width: `${Math.min(100, (wordCount/45)*100)}%` }}></div>
                        </div>
                    </div>

                    <div className="flex flex-col gap-3">
                        <div className="flex justify-between items-end">
                            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Vocabulary Variety</span>
                            <span className="text-lg font-black text-emerald-400 font-mono">{diversity}%</span>
                        </div>
                        <div className="h-2 w-full bg-black/50 rounded-full border border-slate-800 p-0.5">
                            <div className="h-full bg-emerald-500 shadow-[0_0_15px_#10b981] transition-all duration-1000 ease-out rounded-full" style={{ width: `${diversity}%` }}></div>
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mt-4">
                         <div className="bg-black/40 p-5 rounded-3xl border border-slate-800 flex flex-col items-center shadow-inner group hover:border-indigo-500/50 transition-colors">
                             <span className="text-[9px] font-black uppercase tracking-widest text-slate-600 mb-2">XP Reward</span>
                             <span className="text-3xl font-black text-indigo-400 tracking-tighter">+25</span>
                         </div>
                         <div className="bg-black/40 p-5 rounded-3xl border border-slate-800 flex flex-col items-center shadow-inner group hover:border-indigo-500/50 transition-colors">
                             <span className="text-[9px] font-black uppercase tracking-widest text-slate-600 mb-2">Time Spent</span>
                             <span className="text-3xl font-black text-white font-mono tracking-tighter">0:{wordCount > 0 ? Math.floor(Math.random() * 60) : '00'}</span>
                         </div>
                    </div>
                </div>

                {/* Tip */}
                <div className="p-6 bg-indigo-500/5 border border-indigo-500/20 rounded-[2rem] relative overflow-hidden group hover:bg-indigo-500/10 transition-all duration-700">
                    <Sparkles className="absolute -right-6 -bottom-6 w-32 h-32 text-indigo-500/10 rotate-12 group-hover:rotate-0 transition-all duration-700" />
                    <div className="relative z-10">
                        <h4 className="text-[9px] font-black uppercase tracking-[0.3em] text-indigo-400 mb-3 flex items-center gap-2">
                             <ShieldCheck className="w-3 h-3" /> Tip
                        </h4>
                        <p className="text-xs font-bold text-slate-400 leading-relaxed italic border-l-2 border-indigo-500/50 pl-4">
                            "Integrate advanced academic markers like 'Consequently' or 'Notably' to secure high range scores."
                        </p>
                    </div>
                </div>
            </div>

            {/* Hint Display Area */}
            {showHint && (
                <div className="bg-amber-400 rounded-[2.5rem] p-8 border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] animate-scale-in">
                    <div className="flex items-center gap-3 mb-6">
                        <div className="p-2 bg-black rounded-xl">
                            <Lightbulb className="w-5 h-5 text-yellow-400" />
                        </div>
                        <h3 className="text-sm font-black uppercase tracking-widest text-black">Vocabulary Hints</h3>
                    </div>
                    <div className="flex flex-wrap gap-2">
                        {(question.targetVocabulary || []).map((word, i) => (
                            <span key={i} className="px-4 py-2 bg-black text-white rounded-xl text-xs font-black uppercase tracking-wider border border-white/20 shadow-lg">{word}</span>
                        ))}
                    </div>
                </div>
            )}
        </div>
      </div>

      <style>{`
        @keyframes scan {
          0% { top: -100%; }
          100% { top: 200%; }
        }
        .animate-scan {
          animation: scan 4s linear infinite;
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 5px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #1e293b;
          border-radius: 10px;
        }
      `}</style>
    </div>
  );
};
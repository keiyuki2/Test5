import React from 'react';
import { X, Shield, FileText, ArrowLeft } from 'lucide-react';

interface TermsOfServiceProps {
  onClose: () => void;
  mode?: 'modal' | 'page';
}

const sections = [
  {
    title: '1. Acceptance of Terms',
    body: `By creating an account or using IELTS Master ("the Platform"), you agree to be bound by these Terms of Service. If you do not agree, do not use the Platform. We reserve the right to update these terms at any time with notice to users.`,
  },
  {
    title: '2. Description of Service',
    body: `IELTS Master provides AI-powered study tools for standardized test preparation including IELTS, SAT, and English language proficiency exams. Content is for educational purposes only and does not guarantee any specific exam result or score.`,
  },
  {
    title: '3. User Accounts',
    body: `You are responsible for maintaining the confidentiality of your account credentials and for all activity under your account. You must provide accurate information when creating an account. Accounts may not be shared or transferred.`,
  },
  {
    title: '4. Subscription Plans & Billing',
    body: `Free accounts are available at no cost with limited features. Pro and Elite plans are billed monthly and auto-renew unless cancelled. You may cancel at any time from your profile settings. Refunds are available within 7 days of initial purchase for paid plans. Prices may change with 30 days notice.`,
  },
  {
    title: '5. Intellectual Property',
    body: `All content on the Platform — including AI-generated feedback, questions, scoring rubrics, and UI design — is owned by IELTS Master. You may not reproduce, distribute, or create derivative works without written permission. Your personal study data belongs to you.`,
  },
  {
    title: '6. Privacy & Data',
    body: `We collect account information, usage data, and content you submit for AI evaluation. We do not sell your personal data to third parties. AI processing of your submissions is done to provide feedback and improve the service. See our Privacy Policy for full details.`,
  },
  {
    title: '7. Acceptable Use',
    body: `You agree not to: share account access; attempt to reverse-engineer or scrape the Platform; submit harmful, offensive, or illegal content; use the Platform to deceive others about exam scores; or circumvent any security features. Violations may result in account termination.`,
  },
  {
    title: '8. Disclaimers & Limitation of Liability',
    body: `The Platform is provided "as is." We do not warrant that AI feedback will be error-free or that using the Platform will result in any particular exam score. To the maximum extent permitted by law, our liability is limited to the amount you paid in the 3 months preceding any claim.`,
  },
  {
    title: '9. Governing Law',
    body: `These terms are governed by the laws of the jurisdiction in which IELTS Master operates. Any disputes shall be resolved through binding arbitration, except where prohibited by local law.`,
  },
  {
    title: '10. Contact',
    body: `For questions about these terms, contact us at legal@ieltsmaster.edu. We aim to respond within 5 business days.`,
  },
];

export const TermsOfService: React.FC<TermsOfServiceProps> = ({ onClose, mode = 'modal' }) => {
  const isModal = mode === 'modal';

  return (
    <div className={`${isModal ? 'fixed inset-0 z-[200] bg-black/40 backdrop-blur-sm flex items-center justify-center p-4' : 'min-h-screen bg-stone-50'}`}
      style={{ fontFamily: "'Inter', sans-serif" }}>
      <div className={`${isModal ? 'w-full max-w-2xl max-h-[90vh] flex flex-col' : 'max-w-3xl mx-auto px-6 py-16'}`}>

        {isModal && (
          <div className="bg-white border-4 border-black rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] flex flex-col overflow-hidden">
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b-4 border-black bg-stone-900 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-amber-400 border-4 border-white/20 rounded-xl flex items-center justify-center">
                  <FileText className="w-4 h-4 text-black" />
                </div>
                <div>
                  <h2 className="font-black text-white text-base uppercase tracking-tight">Terms of Service</h2>
                  <p className="text-[10px] text-stone-400 font-medium">Last updated: January 2026</p>
                </div>
              </div>
              <button onClick={onClose}
                className="w-9 h-9 bg-white/10 border border-white/20 rounded-xl flex items-center justify-center text-white hover:bg-white/20 transition-all">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Scrollable content */}
            <div className="flex-1 overflow-y-auto p-6 bg-stone-50 space-y-5">
              {sections.map((sec) => (
                <div key={sec.title} className="bg-white border-2 border-stone-100 rounded-2xl p-5">
                  <h3 className="font-black text-sm uppercase tracking-wide text-stone-900 mb-2">{sec.title}</h3>
                  <p className="text-sm text-stone-600 font-medium leading-relaxed">{sec.body}</p>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div className="p-5 border-t-4 border-black bg-white shrink-0 flex items-center justify-between gap-4">
              <p className="text-xs text-stone-400 font-medium">By using IELTS Master you agree to these terms.</p>
              <button onClick={onClose}
                className="px-6 py-2.5 bg-amber-400 border-4 border-black rounded-xl font-black text-xs uppercase tracking-widest shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:translate-x-0.5 hover:translate-y-0.5 hover:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] transition-all">
                Close
              </button>
            </div>
          </div>
        )}

        {!isModal && (
          <>
            <button onClick={onClose} className="flex items-center gap-2 text-sm font-bold text-stone-500 hover:text-stone-900 transition-colors mb-8 group">
              <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back
            </button>
            <div className="flex items-center gap-4 mb-10">
              <div className="w-12 h-12 bg-amber-400 border-4 border-black rounded-2xl flex items-center justify-center shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                <Shield className="w-6 h-6 text-black" />
              </div>
              <div>
                <h1 className="text-3xl font-black uppercase tracking-tighter text-stone-900">Terms of Service</h1>
                <p className="text-sm text-stone-400 font-medium">Last updated: January 2026</p>
              </div>
            </div>
            <div className="space-y-4">
              {sections.map((sec) => (
                <div key={sec.title} className="bg-white border-4 border-black rounded-2xl p-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                  <h3 className="font-black text-sm uppercase tracking-wide text-stone-900 mb-3">{sec.title}</h3>
                  <p className="text-sm text-stone-600 font-medium leading-relaxed">{sec.body}</p>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

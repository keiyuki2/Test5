
import React, { useState, useEffect, useRef } from 'react';
import { DictationQuestion } from '../types';
import { Play, RotateCcw, ArrowRight, Check, X, Headphones, Edit3 } from 'lucide-react';

interface DictationGameScreenProps {
  questions: DictationQuestion[];
  onComplete: () => void;
}

export const DictationGameScreen: React.FC<DictationGameScreenProps> = ({ questions, onComplete }) => {
  const [index, setIndex] = useState(0);
  const [input, setInput] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [hasAnswered, setHasAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [history, setHistory] = useState<boolean[]>([]);
  const [playsLeft, setPlaysLeft] = useState(3);
  
  const currentQ = questions && questions[index];
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
      // Reset state on new question
      setInput('');
      setHasAnswered(false);
      setPlaysLeft(3);
      setIsPlaying(false);
      if (inputRef.current) inputRef.current.focus();
      
      // Auto-play first time after short delay
      const timer = setTimeout(() => {
          playAudio();
      }, 500);
      
      return () => {
          clearTimeout(timer);
          window.speechSynthesis.cancel();
      };
  }, [index]);

  const playAudio = () => {
      if (!currentQ || (playsLeft <= 0 && !hasAnswered)) return;
      if (isPlaying) return;

      setIsPlaying(true);
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(currentQ.sentence);
      utterance.lang = 'en-GB';
      utterance.rate = 0.8;
      utterance.onend = () => {
          setIsPlaying(false);
          if (!hasAnswered) setPlaysLeft(p => p - 1);
      };
      window.speechSynthesis.speak(utterance);
  };

  const checkAnswer = (e?: React.FormEvent) => {
      e?.preventDefault();
      if (hasAnswered || !currentQ) return;

      // Normalize strings: remove punctuation, lowercase, extra spaces
      const cleanInput = input.replace(/[.,/#!$%^&*;:{}=\-_`~()]/g, "").trim().toLowerCase();
      const cleanTarget = (currentQ.sentence || '').replace(/[.,/#!$%^&*;:{}=\-_`~()]/g, "").trim().toLowerCase();
      
      const isCorrect = cleanInput === cleanTarget;
      setHasAnswered(true);
      if (isCorrect) setScore(s => s + 1);
      setHistory(prev => [...prev, isCorrect]);
  };

  const handleNext = () => {
    if (index < questions.length - 1) {
      setIndex(i => i + 1);
    } else {
      setIndex(i => i + 1);
    }
  };

  if (index >= questions.length || !currentQ) {
      return (
          <div className="w-full max-w-2xl mx-auto py-12 px-6 animate-slide-up">
              <div className="bg-white rounded-[3rem] p-10 border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] text-center relative overflow-hidden">
                  <div className="mb-8 relative z-10">
                      <div className="w-24 h-24 bg-pink-500 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                          <Headphones className="w-12 h-12 text-white" />
                      </div>
                      <h2 className="text-5xl font-black uppercase tracking-tighter mb-2">Finished!</h2>
                      <p className="text-2xl font-bold text-slate-500">
                          Score: <span className="text-pink-600 bg-pink-100 px-2 rounded border border-pink-200">{score}</span> / {questions.length}
                      </p>
                  </div>
                  
                  <div className="flex justify-center gap-2 mb-10 flex-wrap relative z-10">
                      {history.map((res, i) => (
                          <div key={i} className={`w-4 h-4 rounded-full border-2 border-black ${res ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                      ))}
                  </div>

                  <button 
                    onClick={onComplete}
                    className="w-full py-5 bg-black text-white rounded-2xl font-black text-xl uppercase tracking-wider shadow-[6px_6px_0px_0px_rgba(0,0,0,0.5)] border-2 border-transparent hover:border-black hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 active:translate-y-0 active:shadow-none transition-all flex items-center justify-center gap-2 relative z-10"
                  >
                      Try Again <RotateCcw className="w-6 h-6" />
                  </button>
              </div>
          </div>
      );
  }

  return (
    <div className="w-full max-w-4xl mx-auto py-8 md:py-12 px-4 md:px-6 animate-slide-up flex flex-col h-[calc(100vh-140px)]">
        {/* Cassette Tape UI */}
        <div className="bg-slate-900 rounded-[3rem] p-8 md:p-12 border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] relative overflow-hidden mb-10">
            {/* Gloss Reflection */}
            <div className="absolute top-0 left-0 w-full h-1/2 bg-white opacity-5 rounded-t-[3rem] pointer-events-none"></div>
            
            {/* Reels */}
            <div className="flex justify-center gap-12 md:gap-20 mb-8 opacity-90 relative z-10">
                <div className={`w-24 h-24 md:w-32 md:h-32 rounded-full border-8 border-slate-700 bg-white relative flex items-center justify-center shadow-inner ${isPlaying ? 'animate-spin' : ''}`}>
                    <div className="w-3 h-3 bg-black rounded-full"></div>
                    <div className="absolute w-full h-3 bg-slate-300 transform rotate-45"></div>
                    <div className="absolute w-full h-3 bg-slate-300 transform -rotate-45"></div>
                </div>
                <div className={`w-24 h-24 md:w-32 md:h-32 rounded-full border-8 border-slate-700 bg-white relative flex items-center justify-center shadow-inner ${isPlaying ? 'animate-spin' : ''}`}>
                    <div className="w-3 h-3 bg-black rounded-full"></div>
                    <div className="absolute w-full h-3 bg-slate-300 transform rotate-45"></div>
                    <div className="absolute w-full h-3 bg-slate-300 transform -rotate-45"></div>
                </div>
                {/* Connecting Tape */}
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-48 h-12 bg-black -z-10 rounded"></div>
            </div>

            {/* Controls */}
            <div className="flex justify-center items-center gap-6 relative z-10">
                 <div className="bg-black text-green-400 font-mono text-xl px-4 py-2 rounded-lg border-2 border-slate-700 shadow-[inset_0_2px_4px_rgba(0,0,0,0.5)]">
                     00:0{index + 1}
                 </div>
                 <button 
                    onClick={playAudio}
                    disabled={playsLeft <= 0 && !hasAnswered}
                    className={`w-20 h-20 rounded-full border-4 border-black flex items-center justify-center shadow-[4px_4px_0px_0px_rgba(255,255,255,0.2)] active:translate-y-1 active:shadow-none transition-all ${
                        isPlaying ? 'bg-amber-400' : 'bg-pink-500 hover:bg-pink-400'
                    } disabled:opacity-50 disabled:cursor-not-allowed`}
                 >
                     <Play className={`w-8 h-8 text-black fill-current ${isPlaying ? 'animate-pulse' : ''}`} />
                 </button>
                 <div className="text-slate-400 font-black text-xs uppercase tracking-widest bg-black/30 px-3 py-1 rounded">
                     Replays: <span className="text-white">{hasAnswered ? '-' : playsLeft}</span>
                 </div>
            </div>
        </div>

        {/* Input Area */}
        <div className="flex-1 flex flex-col items-center">
            <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-indigo-100 rounded-lg border-2 border-black">
                    <Edit3 className="w-6 h-6 text-indigo-600" />
                </div>
                <h2 className="text-2xl md:text-3xl font-black text-slate-900 uppercase tracking-tighter">Write what you hear</h2>
            </div>
            
            <form onSubmit={checkAnswer} className="w-full max-w-2xl relative group">
                <input
                    ref={inputRef}
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    disabled={hasAnswered}
                    className={`w-full p-6 md:p-8 text-2xl md:text-3xl font-bold text-center border-4 border-black rounded-[2rem] focus:outline-none focus:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transition-all placeholder:text-slate-300 font-sans ${
                        hasAnswered 
                            ? (input.replace(/[.,/#!$%^&*;:{}=\-_`~()]/g, "").trim().toLowerCase() === (currentQ.sentence || '').replace(/[.,/#!$%^&*;:{}=\-_`~()]/g, "").trim().toLowerCase() 
                                ? 'bg-emerald-100 text-emerald-900 border-emerald-500'
                                : 'bg-rose-100 text-rose-900 border-rose-500')
                            : 'bg-white'
                    }`}
                    placeholder="Type here..."
                    autoComplete="off"
                    autoCorrect="off"
                />
            </form>

            {hasAnswered && (
                <div className="mt-8 text-center animate-slide-up w-full max-w-2xl">
                     <div className="bg-white p-6 rounded-2xl border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] mb-8">
                         <p className="text-xs font-black uppercase tracking-widest text-slate-400 mb-2">Correct Sentence</p>
                         <p className="text-xl md:text-2xl font-bold text-slate-900 leading-snug font-serif">"{currentQ.sentence}"</p>
                     </div>
                     
                     <button 
                        onClick={handleNext}
                        className="w-full py-4 bg-black text-white rounded-xl font-black text-xl uppercase tracking-wider hover:bg-slate-800 transition-colors border-2 border-transparent hover:border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1"
                    >
                        Next <ArrowRight className="inline-block w-6 h-6 ml-2" />
                    </button>
                </div>
            )}
            
            {!hasAnswered && (
                <button 
                    onClick={() => checkAnswer()}
                    disabled={input.length < 5}
                    className="mt-8 px-12 py-4 bg-indigo-600 text-white rounded-xl font-black text-xl uppercase tracking-wider hover:bg-indigo-700 transition-colors border-2 border-black shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-none"
                >
                    Check
                </button>
            )}
        </div>
    </div>
  );
};

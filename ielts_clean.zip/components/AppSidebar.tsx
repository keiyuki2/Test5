import React from 'react'
import {
  Target,
  Search,
  Zap,
  Settings,
  User,
  ChevronLeft,
  ChevronRight,
  Menu as MenuIcon,
  X,
  Crown,
  Users,
  Flame,
  LayoutDashboard,
  Calculator,
  GraduationCap,
  BookOpen,
  BookMarked,
  Trophy
} from 'lucide-react'
import { GameState, GameMode, UserProfile, SessionStats } from '../types'
import { sfx } from '../services/soundService'

function useIsMobile() {
  const [m, setM] = React.useState(typeof window !== 'undefined' && window.innerWidth < 768)
  React.useEffect(() => {
    const h = () => setM(window.innerWidth < 768)
    window.addEventListener('resize', h)
    return () => window.removeEventListener('resize', h)
  }, [])
  return m
}

interface AppSidebarProps {
  gameState: GameState; gameMode: GameMode
  setGameState: (s: GameState) => void; setGameMode: (m: GameMode) => void
  userProfile: UserProfile | null; stats: SessionStats
  setShowMissions: (v: boolean) => void; setShowDictionary: (v: boolean) => void
  setShowSettings: (v: boolean) => void; setShowProfileDashboard: (v: boolean) => void
  setShowSubscriptions: (v: boolean) => void; setShowSocial: (v: boolean) => void
  setShowVocabNotebook: (v: boolean) => void
}

export function AppSidebar({
  gameState, gameMode, setGameState, setGameMode, userProfile, stats,
  setShowMissions, setShowDictionary, setShowSettings, setShowProfileDashboard,
  setShowSubscriptions, setShowSocial, setShowVocabNotebook,
}: AppSidebarProps) {
  const isMobile = useIsMobile()
  const [collapsed, setCollapsed] = React.useState(false)
  const [mobileOpen, setMobileOpen] = React.useState(false)
  const wide = isMobile ? true : !collapsed
  const plan = userProfile?.plan ?? 'free'
  const isSAT = gameMode === GameMode.SAT_DASHBOARD || gameMode === GameMode.SAT_WHITEBOARD || gameMode === GameMode.SAT_CALCULATOR
  const avatar = userProfile?.avatar
    || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(userProfile?.name || 'U')}&backgroundColor=f87171&fontFamily=Arial&fontSize=40`

  const close = () => setMobileOpen(false)

  const nav = [
    { label: 'Dashboard',   icon: LayoutDashboard, active: gameState === GameState.MENU && !isSAT,
      onClick: () => { close(); sfx.click(); setGameState(GameState.MENU) } },
    { label: 'Social',      icon: Users,  active: false, badge: '3',
      onClick: () => { close(); sfx.click(); setShowSocial(true) } },
    { label: 'Dictionary',  icon: BookOpen, BookMarked, active: false,
      onClick: () => { close(); sfx.click(); setShowDictionary(true) } },
    { label: 'Daily Tasks', icon: Zap, active: false,
      onClick: () => { close(); sfx.click(); setShowMissions(true) } },
  ]

  const planColor = plan === 'elite' ? '#fbbf24' : plan === 'pro' ? '#6366f1' : '#10b981'
  const planLabel = plan === 'free' ? 'Go Pro ✦' : plan === 'pro' ? 'Pro ✦' : 'Elite ✦'

  const Sidebar = () => (
    <div className="flex flex-col h-full overflow-hidden" style={{
      background: 'white',
      borderRight: '4px solid #e7e5e4',
      fontFamily: "'Inter', sans-serif"
    }}>
      {/* ── Logo ─────────────────────────────────────────────────────── */}
      <div className={`flex items-center gap-3 shrink-0 border-b-4 border-stone-100 ${wide ? 'px-4 h-14' : 'justify-center h-14'}`}>
        <div className="w-8 h-8 bg-rose-500 border-4 border-black rounded-xl flex items-center justify-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] flex-shrink-0">
          <Target className="w-4 h-4 text-white" strokeWidth={3} />
        </div>
        {wide && (
          <div className="flex-1 min-w-0">
            <p className="font-black text-[13px] uppercase tracking-tight text-stone-900 leading-none">
              IELTS<span className="text-rose-500"> MASTER</span>
            </p>
            <p className="text-[9px] text-stone-400 font-medium mt-0.5">Study Platform</p>
          </div>
        )}
        {!isMobile && wide && (
          <button onClick={() => { sfx.click(); setCollapsed(true) }}
            className="w-5 h-5 rounded flex items-center justify-center text-stone-300 hover:text-stone-600 hover:bg-stone-100 transition-all flex-shrink-0">
            <ChevronLeft className="w-4 h-4" />
          </button>
        )}
        {!isMobile && !wide && (
          <button onClick={() => { sfx.click(); setCollapsed(false) }}
            className="absolute right-[-13px] top-[18px] w-6 h-6 bg-white border-4 border-black rounded-full flex items-center justify-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] z-10">
            <ChevronRight className="w-3 h-3" />
          </button>
        )}
      </div>

      {/* ── Mode switcher ─────────────────────────────────────────────── */}
      <div className={`shrink-0 ${wide ? 'px-3 pt-4 pb-3' : 'px-2 pt-3 pb-3'}`}>
        {wide && <p className="text-[9px] font-black uppercase tracking-[0.2em] text-stone-400 px-1 mb-2">Mode</p>}
        <div className={`grid gap-1.5 ${wide ? 'grid-cols-2' : 'grid-cols-1'}`}>
          {[
            { id: 'ielts', label: 'IELTS', icon: GraduationCap, active: !isSAT, color: 'bg-emerald-500',
              onClick: () => { close(); sfx.navigate(); setGameMode(GameMode.PARAPHRASE); setGameState(GameState.MENU) } },
            { id: 'sat',  label: 'SAT',   icon: Calculator,     active: isSAT,  color: 'bg-amber-400',
              onClick: () => { close(); sfx.navigate(); setGameMode(GameMode.SAT_DASHBOARD); setGameState(GameState.PLAYING) } },
          ].map(m => (
            <button key={m.id} onClick={m.onClick} title={!wide ? m.label : undefined}
              className={`flex items-center justify-center gap-1.5 rounded-xl border-4 font-black text-xs uppercase tracking-wide transition-all
                ${wide ? 'flex-row py-2 px-2' : 'flex-col py-2.5'}
                ${m.active
                  ? `${m.color} border-black text-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]`
                  : 'border-stone-200 text-stone-500 hover:border-stone-400 hover:text-stone-800 bg-white'}`}>
              <m.icon className="w-3.5 h-3.5 flex-shrink-0" />
              <span className={wide ? '' : 'text-[8px]'}>{m.label}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="mx-3 h-0.5 bg-stone-100 shrink-0" />

      {/* ── Nav ──────────────────────────────────────────────────────── */}
      <nav className={`flex-1 overflow-y-auto ${wide ? 'px-3 py-3' : 'px-2 py-3'} space-y-0.5`}>
        {wide && <p className="text-[9px] font-black uppercase tracking-[0.2em] text-stone-400 px-1 mb-2">Navigate</p>}
        {nav.map(item => (
          <button key={item.label} onClick={item.onClick} title={!wide ? item.label : undefined}
            className={`w-full flex items-center rounded-xl border-4 transition-all duration-100
              ${wide ? 'px-3 py-2.5 gap-3' : 'justify-center py-2.5'}
              ${item.active
                ? 'bg-stone-900 border-black text-white shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]'
                : 'border-transparent text-stone-500 hover:text-stone-900 hover:bg-stone-50 hover:border-stone-200'}`}>
            <item.icon className="flex-shrink-0 w-4 h-4" strokeWidth={item.active ? 2.5 : 2} />
            {wide && (
              <>
                <span className="text-sm font-bold flex-1 text-left">{item.label}</span>
                {item.badge && (
                  <span className="w-5 h-5 rounded-full bg-rose-500 text-white text-[10px] font-black flex items-center justify-center flex-shrink-0">{item.badge}</span>
                )}
              </>
            )}
          </button>
        ))}

        {/* Streak */}
        {wide && (stats.streak ?? 0) > 0 && (
          <div className="mt-3 flex items-center gap-2.5 px-3 py-2.5 bg-amber-400 border-4 border-black rounded-xl shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
            <Flame className="w-4 h-4 text-black flex-shrink-0" />
            <div>
              <p className="text-xs font-black text-black leading-none">{stats.streak} day streak</p>
              <p className="text-[10px] text-black/60 font-medium mt-0.5">Keep going!</p>
            </div>
          </div>
        )}
      </nav>

      <div className="mx-3 h-0.5 bg-stone-100 shrink-0" />

      {/* ── Upgrade ──────────────────────────────────────────────────── */}
      <div className={`${wide ? 'px-3 py-3' : 'px-2 py-3'} shrink-0`}>
        <button
          onClick={() => { close(); sfx.click(); setShowSubscriptions(true) }}
          title={!wide ? planLabel : undefined}
          className={`w-full flex items-center rounded-xl border-4 border-black font-black text-sm uppercase tracking-wide transition-all shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]
            ${wide ? 'px-3 py-2.5 gap-2.5' : 'justify-center py-2.5'}`}
          style={{ background: planColor, color: plan === 'free' ? '#000' : '#000' }}>
          <Crown className="flex-shrink-0 w-4 h-4" strokeWidth={2.5} />
          {wide && <span className="flex-1 text-left text-black">{planLabel}</span>}
        </button>
      </div>

      {/* ── Settings + Profile ────────────────────────────────────────── */}
      <div className={`${wide ? 'px-3 pb-4' : 'px-2 pb-4'} space-y-0.5 shrink-0`}>
        <button onClick={() => { close(); sfx.click(); setShowSettings(true) }}
          title={!wide ? 'Settings' : undefined}
          className={`w-full flex items-center rounded-xl border-2 border-transparent text-stone-500 hover:text-stone-900 hover:bg-stone-50 hover:border-stone-200 transition-all
            ${wide ? 'px-3 py-2 gap-3' : 'justify-center py-2'}`}>
          <Settings className="flex-shrink-0 w-4 h-4" />
          {wide && <span className="text-sm font-medium">Settings</span>}
        </button>

        <button onClick={() => { close(); sfx.click(); setShowProfileDashboard(true) }}
          title={!wide ? 'Profile' : undefined}
          className={`w-full flex items-center rounded-xl border-4 border-transparent hover:bg-stone-50 hover:border-stone-200 transition-all group
            ${wide ? 'px-2.5 py-2 gap-2.5' : 'justify-center py-2'}`}>
          <div className="relative flex-shrink-0">
            <img src={avatar} className="w-8 h-8 rounded-xl object-cover border-4 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]" alt="" />
            <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-lime-400 rounded-full border-2 border-white" />
          </div>
          {wide && (
            <>
              <div className="flex-1 text-left min-w-0">
                <p className="text-[13px] font-bold text-stone-900 truncate leading-tight">{userProfile?.name?.split(' ')[0] || 'Student'}</p>
                <p className="text-[9px] text-stone-400 font-medium uppercase tracking-widest">Band {userProfile?.targetBand || '—'}</p>
              </div>
              <User className="flex-shrink-0 w-3.5 h-3.5 text-stone-300 group-hover:text-stone-600 transition-colors" />
            </>
          )}
        </button>
      </div>
    </div>
  )

  if (!isMobile) return (
    <div className={`h-screen sticky top-0 flex-shrink-0 relative transition-all duration-200 ${collapsed ? 'w-[56px]' : 'w-[220px]'}`}>
      <Sidebar />
    </div>
  )

  return (
    <>
      {mobileOpen && <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40" onClick={() => setMobileOpen(false)} />}
      <button onClick={() => setMobileOpen(!mobileOpen)}
        className="fixed top-3 left-3 z-50 w-9 h-9 bg-white border-4 border-black rounded-xl flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
        {mobileOpen ? <X className="w-4 h-4" /> : <MenuIcon className="w-4 h-4" />}
      </button>
      <div className={`fixed inset-y-0 left-0 z-50 w-[220px] transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <Sidebar />
      </div>
    </>
  )
}

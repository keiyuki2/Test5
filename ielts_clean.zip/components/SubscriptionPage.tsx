import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Check, Crown, Zap, Star, ArrowRight, Copy, CheckCircle, Shield } from 'lucide-react';
import { UserProfile, SubscriptionPlan } from '../types';
import { sfx } from '../services/soundService';
import { Badge } from './ui/badge';

interface SubscriptionPageProps {
  userProfile: UserProfile | null;
  onClose: () => void;
  onUpgrade: (plan: SubscriptionPlan) => void;
}

const PLANS = [
  {
    id: 'free' as SubscriptionPlan,
    name: 'Free', price: '₮0', period: 'forever',
    color: 'bg-white', shadow: 'shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]',
    features: ['5 AI sessions / day', 'Basic drills & vocabulary', '1 mock exam per month', 'Community access'],
  },
  {
    id: 'pro' as SubscriptionPlan,
    name: 'Pro', price: '₮29,900', period: '/month',
    color: 'bg-stone-900', shadow: 'shadow-[4px_4px_0px_0px_rgba(251,191,36,1)]',
    badge: 'Most Popular', featured: true,
    features: ['Unlimited AI feedback', 'Speaking sim + scoring', 'Daily mock exams', 'All 20+ drill games', 'Pro banners + custom banner upload', 'Priority support'],
  },
  {
    id: 'elite' as SubscriptionPlan,
    name: 'Elite', price: '₮69,900', period: '/month',
    color: 'bg-amber-400', shadow: 'shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]',
    features: ['Everything in Pro', 'Animated banners', 'Exclusive badge set', 'Early feature access', 'Verified certificate', 'Elite profile title'],
  },
];

function CopyBtn({ text }: { text: string }) {
  const [done, setDone] = useState(false);
  return (
    <button onClick={() => { navigator.clipboard.writeText(text).catch(()=>{}); setDone(true); sfx.xp(); setTimeout(()=>setDone(false),2000); }}
      className="flex items-center gap-1.5 px-2.5 py-1.5 bg-stone-800 hover:bg-stone-700 border-2 border-stone-600 rounded-lg text-xs font-bold text-stone-300 transition-all">
      {done ? <CheckCircle className="w-3 h-3 text-lime-400" /> : <Copy className="w-3 h-3" />}
      {done ? 'Copied' : 'Copy'}
    </button>
  );
}

export const SubscriptionPage: React.FC<SubscriptionPageProps> = ({ userProfile, onClose, onUpgrade }) => {
  const [selected, setSelected] = useState<SubscriptionPlan | null>(null);
  const [showPayment, setShowPayment] = useState(false);
  const current = userProfile?.plan ?? 'free';

  const pickPlan = (plan: SubscriptionPlan) => {
    if (plan === 'free' || plan === current) return;
    sfx.click(); setSelected(plan); setShowPayment(true);
  };

  const planData = PLANS.find(p => p.id === selected);

  return (
    <div className="fixed inset-0 z-[90] bg-stone-50 overflow-y-auto" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white border-b-4 border-black px-5 py-4 flex items-center justify-between shadow-[0_4px_0px_0px_rgba(0,0,0,1)]">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-amber-400 border-4 border-black rounded-xl flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
            <Crown className="w-4 h-4 text-black" />
          </div>
          <div>
            <h1 className="font-black text-stone-900 text-base uppercase tracking-tight leading-none">Upgrade</h1>
            {current !== 'free' && <p className="text-stone-400 text-[10px] font-medium capitalize">{current} plan active</p>}
          </div>
        </div>
        <button onClick={() => { sfx.back(); onClose(); }}
          className="w-9 h-9 bg-stone-100 hover:bg-stone-200 border-2 border-stone-200 hover:border-stone-400 rounded-xl flex items-center justify-center text-stone-500 hover:text-stone-900 transition-all">
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="max-w-4xl mx-auto px-4 md:px-8 py-8 space-y-8">

        {/* Hero */}
        <div className="text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-amber-400 border-4 border-black rounded-xl mb-4 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
            <Zap className="w-4 h-4 text-black" />
            <span className="text-sm font-black text-black uppercase tracking-widest">Pay with MonPay · No card needed</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-black uppercase tracking-tighter text-stone-900 leading-tight">
            Pick your <span className="text-rose-500">plan</span>
          </h2>
          <p className="text-stone-400 font-medium mt-2 text-sm">Cancel anytime · Instant activation after payment confirmation</p>
        </div>

        {/* Plans */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {PLANS.map((plan, i) => {
            const active = current === plan.id;
            const isFeature = plan.id === 'pro';
            return (
              <motion.div key={plan.id}
                initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}
                className={`relative flex flex-col rounded-3xl border-4 border-black p-6 transition-all hover:-translate-y-1 ${plan.color} ${plan.shadow} ${isFeature ? 'scale-[1.02]' : ''}`}>
                {plan.badge && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-amber-400 border-4 border-black px-4 py-1.5 rounded-xl shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                    <span className="text-[10px] font-black uppercase tracking-widest text-black">{plan.badge}</span>
                  </div>
                )}
                {active && (
                  <div className="absolute -top-4 right-4 bg-lime-400 border-4 border-black px-3 py-1 rounded-xl">
                    <span className="text-[10px] font-black uppercase tracking-widest text-black">Active</span>
                  </div>
                )}

                <p className={`font-black text-xs uppercase tracking-widest mb-1 ${plan.id === 'pro' ? 'text-stone-400' : 'text-stone-500'}`}>{plan.name}</p>
                <div className="flex items-baseline gap-1.5 mb-5">
                  <span className={`text-4xl font-black tracking-tighter ${plan.id === 'pro' ? 'text-white' : 'text-stone-900'}`}>{plan.price}</span>
                  <span className={`text-xs font-bold opacity-50 ${plan.id === 'pro' ? 'text-white' : 'text-stone-900'}`}>{plan.period}</span>
                </div>

                <ul className="flex-1 space-y-2.5 mb-6">
                  {plan.features.map(f => (
                    <li key={f} className="flex items-start gap-2.5 text-sm font-medium">
                      <Check className={`w-4 h-4 mt-0.5 flex-shrink-0 ${plan.id === 'pro' ? 'text-amber-400' : plan.id === 'elite' ? 'text-black' : 'text-stone-500'}`} />
                      <span className={plan.id === 'pro' ? 'text-stone-300' : plan.id === 'elite' ? 'text-black' : 'text-stone-600'}>{f}</span>
                    </li>
                  ))}
                </ul>

                <button onClick={() => pickPlan(plan.id)} disabled={active || plan.id === 'free'}
                  className={`w-full py-3 rounded-xl font-black text-xs uppercase tracking-widest border-4 border-black transition-all shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:translate-x-0.5 hover:translate-y-0.5 hover:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] active:shadow-none disabled:opacity-50 disabled:cursor-not-allowed ${
                    plan.id === 'pro' ? 'bg-amber-400 text-black' :
                    plan.id === 'elite' ? 'bg-black text-white' : 'bg-stone-100 text-stone-500'
                  }`}>
                  {active ? 'Current Plan' : plan.id === 'free' ? 'Always Free' : `Get ${plan.name} →`}
                </button>
              </motion.div>
            );
          })}
        </div>

        {/* MonPay Payment Section */}
        <div className="bg-white border-4 border-black rounded-3xl overflow-hidden shadow-[6px_6px_0px_0px_rgba(0,0,0,1)]">
          <div className="bg-stone-900 px-6 py-4 flex items-center gap-3">
            <Shield className="w-5 h-5 text-amber-400" />
            <h3 className="font-black text-white text-sm uppercase tracking-widest">How to Pay — MonPay / Bank Transfer</h3>
          </div>

          <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* MonPay QR */}
            <div className="flex flex-col items-center">
              <p className="font-black text-sm uppercase tracking-wide text-stone-900 mb-4 self-start flex items-center gap-2">
                MonPay QR Code
              </p>

              {/* Real QR code */}
              <div className="bg-black rounded-2xl p-4 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] w-full max-w-[240px]">
                <div className="flex items-center gap-2.5 mb-3">
                  <img src="https://api.dicebear.com/7.x/initials/svg?seed=Tuv&backgroundColor=f59e0b&fontFamily=Arial&fontSize=40"
                    className="w-9 h-9 rounded-full border-2 border-stone-700 object-cover" alt="" />
                  <div>
                    <p className="font-black text-white text-sm leading-none">Э.Тувшинболд</p>
                    <p className="text-stone-400 text-xs">94920916</p>
                  </div>
                </div>
                <img src="/monpay-qr.png" alt="MonPay QR Code"
                  className="w-full rounded-xl bg-white p-2" />
                <div className="mt-3 text-center">
                  <p className="text-stone-500 text-[9px] font-bold uppercase tracking-widest mb-1">IBAN дансны дугаар</p>
                  <p className="font-black text-white text-sm">MN13 0050 0991 0486 3281</p>
                  <p className="text-stone-500 text-[9px] font-bold uppercase tracking-widest mt-2 mb-1">Монрау дансны дугаар</p>
                  <p className="font-black text-white text-sm">9910 4863 281</p>
                </div>
              </div>

              <p className="text-[10px] text-stone-400 font-medium text-center mt-3 max-w-[220px] leading-relaxed">
                Scan with MonPay or any Mongolian bank app. Add your email in the transfer note.
              </p>
            </div>

            {/* Bank transfer details */}
            <div>
              <p className="font-black text-sm uppercase tracking-wide text-stone-900 mb-4 flex items-center gap-2">
                Bank Transfer
              </p>
              <div className="space-y-3">
                {[
                  { bank: 'Khan Bank (IBAN)', number: 'MN13 0050 0991 0486 3281' },
                  { bank: 'Monpay Number', number: '9910 4863 281' },
                ].map(acc => (
                  <div key={acc.bank} className="bg-stone-900 border-4 border-stone-700 rounded-xl p-4">
                    <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest mb-2">{acc.bank}</p>
                    <div className="flex items-center justify-between gap-3">
                      <span className="font-mono font-black text-white text-sm">{acc.number}</span>
                      <CopyBtn text={acc.number} />
                    </div>
                  </div>
                ))}
                <div className="bg-amber-50 border-4 border-amber-200 rounded-xl p-4">
                  <p className="text-xs font-bold text-amber-800 leading-relaxed">
                    After payment, email your receipt to <span className="font-black">pay@ieltsmaster.mn</span> and your account upgrades within a few hours.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Confirmation modal */}
      {showPayment && planData && (
        <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
            className="bg-white border-4 border-black rounded-3xl p-8 max-w-sm w-full shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
            <h3 className="font-black text-xl uppercase tracking-tighter text-stone-900 mb-1">Confirm Upgrade</h3>
            <p className="text-stone-400 text-sm font-medium mb-5">
              {planData.name} plan — {planData.price}{planData.period}
            </p>
            <div className="bg-stone-50 border-4 border-stone-200 rounded-2xl p-4 mb-6">
              <p className="text-stone-600 text-sm font-medium leading-relaxed">
                Complete payment via MonPay QR or bank transfer first, then click "I Paid". Your account upgrades after receipt verification.
              </p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => { sfx.back(); setShowPayment(false); }}
                className="flex-1 py-3 bg-stone-100 text-stone-700 border-4 border-stone-300 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-stone-200 transition-colors">
                Cancel
              </button>
              <button onClick={() => { sfx.complete(); onUpgrade(selected!); setShowPayment(false); }}
                className="flex-1 py-3 bg-amber-400 text-black border-4 border-black rounded-xl font-black text-xs uppercase tracking-widest shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-all">
                I Paid ✓
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

import React, { useEffect, useState } from 'react';
import { Feedback, Question } from '../types';
import { sfx } from '../services/soundService';
import { ArrowRight, Star, TrendingUp, Zap, CheckCircle, AlertCircle, BookOpen, RotateCcw } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface ResultScreenProps {
  feedback: Feedback;
  originalQuestion: Question;
  userAnswer: string;
  onNext: () => void;
}

// ── Animated score ring (osu-style, but on white) ────────────────────────────
function ScoreRing({ score }: { score: number }) {
  const [animated, setAnimated] = useState(0);
  const size = 160;
  const r = (size - 16) / 2;
  const circ = 2 * Math.PI * r;

  const color  = score >= 80 ? '#16a34a' : score >= 60 ? '#d97706' : '#dc2626';
  const bgRing = score >= 80 ? '#dcfce7' : score >= 60 ? '#fef9c3' : '#fee2e2';
  const label  = score >= 80 ? 'Excellent' : score >= 60 ? 'Good' : 'Try Again';
  const rankLetter = score >= 90 ? 'S' : score >= 80 ? 'A' : score >= 65 ? 'B' : score >= 50 ? 'C' : 'D';

  useEffect(() => {
    let v = 0;
    const id = setInterval(() => {
      v = Math.min(v + score / 60, score);
      setAnimated(v);
      if (v >= score) clearInterval(id);
    }, 16);
    return () => clearInterval(id);
  }, [score]);

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="absolute rotate-[-90deg]">
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={bgRing} strokeWidth={10} />
        <circle cx={size/2} cy={size/2} r={r} fill="none"
          stroke={color} strokeWidth={10} strokeLinecap="round"
          strokeDasharray={circ} strokeDashoffset={circ * (1 - animated / 100)}
          style={{ transition: 'stroke-dashoffset 0.04s linear', filter: `drop-shadow(0 0 6px ${color}66)` }}
        />
      </svg>
      <div className="relative z-10 flex flex-col items-center">
        <span className="font-black leading-none" style={{ fontSize: 42, color }}>{Math.round(animated)}</span>
        <span className="font-black uppercase tracking-widest text-[10px]" style={{ color: `${color}99` }}>{label}</span>
      </div>
      {/* Rank badge */}
      <div className="absolute -top-2 -right-2 w-9 h-9 rounded-xl border-4 border-black flex items-center justify-center font-black text-sm shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]"
        style={{ background: color, color: '#fff' }}>
        {rankLetter}
      </div>
    </div>
  );
}

// ── Skill bar (white theme) ──────────────────────────────────────────────────
function SkillBar({ label, score }: { label: string; score: number }) {
  const [w, setW] = useState(0);
  useEffect(() => { const t = setTimeout(() => setW(score), 400); return () => clearTimeout(t); }, [score]);
  const color = score >= 80 ? '#16a34a' : score >= 60 ? '#d97706' : '#dc2626';
  const grade = score >= 80 ? 'A' : score >= 65 ? 'B' : score >= 50 ? 'C' : 'D';
  const gradeColor = score >= 80 ? 'text-emerald-600' : score >= 65 ? 'text-amber-600' : score >= 50 ? 'text-cyan-600' : 'text-rose-600';
  return (
    <div className="flex items-center gap-3">
      <span className={`w-6 text-center font-black text-base ${gradeColor}`}>{grade}</span>
      <div className="flex-1">
        <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-stone-400 mb-1.5">
          <span>{label}</span><span>{score}</span>
        </div>
        <div className="h-3 bg-stone-100 rounded-full overflow-hidden border-4 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
          <div className="h-full rounded-full transition-all duration-1000 ease-out"
            style={{ width: `${w}%`, background: color }} />
        </div>
      </div>
    </div>
  );
}

// ── Confetti ─────────────────────────────────────────────────────────────────
function Confetti({ score }: { score: number }) {
  if (score < 70) return null;
  const colors = ['#f59e0b','#10b981','#f43f5e','#6366f1','#06b6d4','#a855f7'];
  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {Array.from({ length: 20 }).map((_, i) => (
        <motion.div key={i}
          initial={{ y: -20, x: `${Math.random() * 100}vw`, opacity: 1, rotate: 0 }}
          animate={{ y: '110vh', opacity: [1, 1, 0], rotate: Math.random() * 720 }}
          transition={{ duration: 2 + Math.random() * 2, delay: Math.random() * 0.6, ease: 'easeIn' }}
          className="absolute w-2.5 h-2.5 rounded"
          style={{ background: colors[i % colors.length] }}
        />
      ))}
    </div>
  );
}

export const ResultScreen: React.FC<ResultScreenProps> = ({ feedback, originalQuestion, userAnswer, onNext }) => {
  const [tab, setTab] = useState<'overview' | 'feedback'>('overview');
  const score = feedback.score;
  const rankColor = score >= 80 ? '#16a34a' : score >= 60 ? '#d97706' : '#dc2626';
  const rankBg    = score >= 80 ? 'bg-emerald-50'  : score >= 60 ? 'bg-amber-50'  : 'bg-rose-50';
  const rankBorder= score >= 80 ? 'border-emerald-200' : score >= 60 ? 'border-amber-200' : 'border-rose-200';

  const metrics = [
    { label: 'Vocabulary', score: feedback.breakdown.vocabulary },
    { label: 'Grammar',    score: feedback.breakdown.grammar },
    ...(feedback.breakdown.meaning    !== undefined ? [{ label: 'Meaning',   score: feedback.breakdown.meaning }] : []),
    ...(feedback.breakdown.coherence  !== undefined ? [{ label: 'Coherence', score: feedback.breakdown.coherence }] : []),
    ...(feedback.breakdown.taskResponse !== undefined ? [{ label: 'Task',    score: feedback.breakdown.taskResponse }] : []),
  ];

  return (
    <div className="min-h-screen bg-stone-50" style={{ fontFamily: "'Inter', sans-serif" }}>
      <Confetti score={score} />

      {/* ── Top bar ─────────────────────────────────────────────────────── */}
      <div className="sticky top-0 z-30 bg-white border-b-4 border-black px-6 py-3 flex items-center justify-between shadow-[0_4px_0px_rgba(0,0,0,1)]">
        <div className="flex items-center gap-3">
          <div className="w-2 h-2 rounded-full border-2 border-black" style={{ background: rankColor }} />
          <span className="font-black text-sm uppercase tracking-widest text-stone-500">Result</span>
        </div>
        <div className="flex gap-1.5">
          {(['overview','feedback'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`px-4 py-1.5 rounded-xl text-xs font-black uppercase tracking-widest border-4 transition-all ${
                tab === t ? 'bg-stone-900 text-white border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]' : 'border-transparent text-stone-400 hover:text-stone-900'
              }`}>{t}</button>
          ))}
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 md:px-8 py-8">

        {/* OVERVIEW */}
        {tab === 'overview' && (
          <motion.div key="ov" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>

            {/* Hero result card */}
            <div className={`${rankBg} border-4 ${rankBorder} border-l-[8px] rounded-3xl p-8 mb-6 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] flex flex-col md:flex-row items-center gap-8 relative overflow-hidden`}
              style={{ borderLeftColor: rankColor }}>
              {/* Decorative rank letter */}
              <div className="absolute right-4 top-1/2 -translate-y-1/2 font-black leading-none select-none pointer-events-none text-[120px] opacity-5" style={{ color: rankColor }}>
                {score >= 90 ? 'S' : score >= 80 ? 'A' : score >= 65 ? 'B' : score >= 50 ? 'C' : 'D'}
              </div>

              <div className="relative z-10 flex-shrink-0">
                <ScoreRing score={score} />
              </div>

              <div className="relative z-10 flex-1 text-center md:text-left">
                <h2 className="text-3xl font-black uppercase tracking-tighter text-stone-900 mb-2 leading-tight">
                  {score >= 80 ? 'Outstanding!' : score >= 60 ? 'Well Done!' : 'Keep Going!'}
                </h2>
                <p className="text-stone-500 font-medium max-w-xs mb-6">
                  {score >= 80 ? 'Excellent vocabulary and structure. Keep this level.' : score >= 60 ? 'Solid attempt. A few tweaks will push you further.' : 'Every attempt builds real skill. Check the feedback below.'}
                </p>
                <button onClick={() => { sfx.navigate(); onNext(); }}
                  className="inline-flex items-center gap-2 px-8 py-3.5 border-4 border-black rounded-2xl font-black text-sm uppercase tracking-widest shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all group"
                  style={{ background: rankColor, color: '#fff' }}>
                  Next Task <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {/* Skills */}
              <div className="bg-white border-4 border-black rounded-2xl p-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-400 mb-5 flex items-center gap-2">
                  <TrendingUp className="w-3.5 h-3.5" /> Breakdown
                </h3>
                <div className="space-y-4">
                  {metrics.map(m => <SkillBar key={m.label} label={m.label} score={m.score} />)}
                </div>
              </div>

              <div className="space-y-4">
                {/* Strengths */}
                <div className="bg-white border-4 border-emerald-300 rounded-2xl p-5 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                  <h4 className="text-[10px] font-black uppercase tracking-widest text-emerald-600 mb-3 flex items-center gap-1.5">
                    <CheckCircle className="w-3.5 h-3.5" /> Strengths
                  </h4>
                  <ul className="space-y-2">
                    {feedback.strengths.slice(0, 3).map((s, i) => (
                      <li key={i} className="text-sm text-stone-700 font-medium flex gap-2 leading-snug">
                        <span className="text-emerald-500 flex-shrink-0 font-black">+</span>{s}
                      </li>
                    ))}
                  </ul>
                </div>
                {/* Improvements */}
                <div className="bg-white border-4 border-rose-300 rounded-2xl p-5 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                  <h4 className="text-[10px] font-black uppercase tracking-widest text-rose-600 mb-3 flex items-center gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5" /> Improve
                  </h4>
                  <ul className="space-y-2">
                    {feedback.weaknesses.slice(0, 3).map((w, i) => (
                      <li key={i} className="text-sm text-stone-700 font-medium flex gap-2 leading-snug">
                        <span className="text-rose-500 flex-shrink-0 font-black">→</span>{w}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Better answer */}
            <div className="mt-5 bg-white border-4 border-black rounded-2xl p-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-400 mb-4 flex items-center gap-2">
                <BookOpen className="w-3.5 h-3.5" /> Suggested Answer
              </h3>
              <div className="relative pl-5">
                <div className="absolute left-0 top-0 bottom-0 w-1 rounded-full" style={{ background: rankColor }} />
                <p className="text-stone-700 font-medium leading-relaxed text-sm">{feedback.betterAlternative}</p>
              </div>
            </div>
          </motion.div>
        )}

        {/* FEEDBACK */}
        {tab === 'feedback' && (
          <motion.div key="fb" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }} className="space-y-5">
            <div className="bg-white border-4 border-black rounded-2xl p-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-400 mb-4">AI Analysis</h3>
              <p className="text-stone-700 font-medium leading-relaxed italic">"{feedback.analysis}"</p>
            </div>
            {userAnswer ? (
              <div className="bg-white border-4 border-black rounded-2xl p-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-400 mb-4">Your Answer</h3>
                <p className="text-stone-600 font-medium leading-relaxed text-sm whitespace-pre-wrap">{userAnswer}</p>
              </div>
            ) : null}
          </motion.div>
        )}
      </div>
    </div>
  );
};

/**
 * DEV PANEL — for testing only, not for production
 * Add ?dev=true to URL or press Ctrl+Shift+D to toggle
 */
import React, { useState, useEffect } from 'react';
import { GameState, GameMode, Difficulty, UserProfile, SubscriptionPlan } from '../types';
import { X, ChevronDown, ChevronUp, Zap, User, Monitor, CreditCard, RotateCcw, Eye } from 'lucide-react';

interface DevPanelProps {
  gameState: GameState;
  gameMode: GameMode;
  userProfile: UserProfile | null;
  setGameState: (s: GameState) => void;
  setGameMode:  (m: GameMode)  => void;
  onAuthMode:   (m: 'LOGIN' | 'SIGNUP' | 'ASSESSMENT') => void;
  onSetProfile: (p: UserProfile) => void;
  onReset:      () => void;
  onShowSubscription?: () => void;
  onShowSocial?: () => void;
}

const MOCK_PROFILES: Record<string, UserProfile> = {
  'Free / Beginner': {
    name: 'Test User', targetBand: '6.5', avatar: 'https://api.dicebear.com/7.x/initials/svg?seed=Test&backgroundColor=f43f5e&fontFamily=Arial&fontSize=40',
    proficiencyLevel: Difficulty.EASY, plan: 'free', activeBanner: 'none', unlockedBanners: [],
  },
  'Pro / Intermediate': {
    name: 'Pro User', targetBand: '7.5', avatar: 'https://api.dicebear.com/7.x/initials/svg?seed=Pro&backgroundColor=f59e0b&fontFamily=Arial&fontSize=40',
    proficiencyLevel: Difficulty.MEDIUM, plan: 'pro', activeBanner: 'amber', unlockedBanners: ['none','stone','amber','rose','cyan','lime'],
  },
  'Elite / Advanced': {
    name: 'Elite User', targetBand: '9.0', avatar: 'https://api.dicebear.com/7.x/initials/svg?seed=Elite&backgroundColor=10b981&fontFamily=Arial&fontSize=40',
    proficiencyLevel: Difficulty.HARD, plan: 'elite', activeBanner: 'rainbow', unlockedBanners: ['none','stone','amber','rose','cyan','lime','rainbow','neon','fire','aurora'],
  },
};

const ALL_MODES: { label: string; state: GameState; mode: GameMode }[] = [
  { label: 'Menu',            state: GameState.MENU,    mode: GameMode.PARAPHRASE },
  { label: 'Loading',         state: GameState.LOADING, mode: GameMode.PARAPHRASE },
  { label: 'SAT Dashboard',   state: GameState.PLAYING, mode: GameMode.SAT_DASHBOARD },
  { label: 'SAT Whiteboard',  state: GameState.PLAYING, mode: GameMode.SAT_WHITEBOARD },
  { label: 'SAT Calculator',  state: GameState.PLAYING, mode: GameMode.SAT_CALCULATOR },
  { label: 'Vocab Game',      state: GameState.PLAYING, mode: GameMode.VOCABULARY },
  { label: 'Listening',       state: GameState.PLAYING, mode: GameMode.LISTENING },
  { label: 'Reading',         state: GameState.PLAYING, mode: GameMode.READING },
  { label: 'Writing',         state: GameState.PLAYING, mode: GameMode.WRITING },
  { label: 'Speaking',        state: GameState.PLAYING, mode: GameMode.SPEAKING },
  { label: 'Collocation',     state: GameState.PLAYING, mode: GameMode.COLLOCATION },
  { label: 'Idioms',          state: GameState.PLAYING, mode: GameMode.IDIOM },
  { label: 'Synonym',         state: GameState.PLAYING, mode: GameMode.SYNONYM },
  { label: 'Dictation',       state: GameState.PLAYING, mode: GameMode.DICTATION },
  { label: 'Tone/Register',   state: GameState.PLAYING, mode: GameMode.TONE },
  { label: 'Map',             state: GameState.PLAYING, mode: GameMode.MAP },
  { label: 'Heading Match',   state: GameState.PLAYING, mode: GameMode.HEADING_MATCH },
  { label: 'Style Transfer',  state: GameState.PLAYING, mode: GameMode.STYLE_TRANSFER },
  { label: 'Pronunciation',   state: GameState.PLAYING, mode: GameMode.PRONUNCIATION },
  { label: 'Lexical Echo',    state: GameState.PLAYING, mode: GameMode.LEXICAL_ECHO },
  { label: 'Synaptic Bridge', state: GameState.PLAYING, mode: GameMode.SYNAPTIC_BRIDGE },
  { label: 'Mock Exam',       state: GameState.PLAYING, mode: GameMode.MOCK_EXAM },
];

function Group({ title, children }: { title: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(true);
  return (
    <div className="border border-black/10 rounded-xl overflow-hidden">
      <button onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between px-3 py-2 bg-stone-100 hover:bg-stone-200 transition-colors">
        <span className="text-[10px] font-black uppercase tracking-widest text-stone-600">{title}</span>
        {open ? <ChevronUp className="w-3.5 h-3.5 text-stone-400" /> : <ChevronDown className="w-3.5 h-3.5 text-stone-400" />}
      </button>
      {open && <div className="p-2 space-y-1 bg-white">{children}</div>}
    </div>
  );
}

function Btn({ label, color = 'bg-stone-100', onClick }: { label: string; color?: string; onClick: () => void }) {
  return (
    <button onClick={onClick}
      className={`w-full text-left px-3 py-2 rounded-lg text-[11px] font-bold text-stone-700 hover:text-stone-900 ${color} hover:brightness-95 transition-all border border-black/10`}>
      {label}
    </button>
  );
}

export function DevPanel(props: DevPanelProps) {
  const [visible, setVisible] = useState(false);
  const [minimized, setMinimized] = useState(false);

  useEffect(() => {
    // Expose dev commands to browser console
    (window as any).__dev = {
      setTitle: (title: 'owner'|'manager'|'verified'|'student'|null) => {
        const raw = localStorage.getItem('ielts_user_profile');
        if (!raw) { console.error('No profile found'); return; }
        const p = JSON.parse(raw);
        if (title) p.title = title; else delete p.title;
        localStorage.setItem('ielts_user_profile', JSON.stringify(p));
        console.log(`✅ Title set to: ${title}. Reload the page.`);
        window.location.reload();
      },
      setPlan: (plan: 'free'|'pro'|'elite') => {
        const raw = localStorage.getItem('ielts_user_profile');
        if (!raw) { console.error('No profile found'); return; }
        const p = JSON.parse(raw); p.plan = plan;
        localStorage.setItem('ielts_user_profile', JSON.stringify(p));
        console.log(`✅ Plan set to: ${plan}. Reload the page.`);
        window.location.reload();
      },
      setBanner: (bannerId: string) => {
        const raw = localStorage.getItem('ielts_user_profile');
        if (!raw) { console.error('No profile found'); return; }
        const p = JSON.parse(raw); p.activeBanner = bannerId; delete p.customBannerUrl;
        localStorage.setItem('ielts_user_profile', JSON.stringify(p));
        console.log(`✅ Banner set to: ${bannerId}. Reload the page.`);
        window.location.reload();
      },
      help: () => console.log(`
🛠  IELTS Master Dev Commands
─────────────────────────────
__dev.setTitle('owner'|'manager'|'verified'|'student'|null)
__dev.setPlan('free'|'pro'|'elite')
__dev.setBanner('none'|'amber'|'rose'|'ocean'|'forest'|'rainbow'|'fire'|'aurora'|'neon')
      `.trim()),
    };
    console.log("💡 Dev commands available. Type __dev.help() for usage.");

    // Show if ?dev=true in URL
    if (new URLSearchParams(window.location.search).get('dev') === 'true') {
      setVisible(true);
    }
    // Ctrl+Shift+D shortcut
    const handler = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'D') {
        e.preventDefault();
        setVisible(v => !v);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  if (!visible) return (
    <button
      onClick={() => setVisible(true)}
      title="Open Dev Panel (Ctrl+Shift+D)"
      className="fixed bottom-4 right-4 z-[200] w-10 h-10 bg-stone-900 text-white rounded-xl border-2 border-white/20 flex items-center justify-center text-xs font-black shadow-xl hover:bg-stone-700 transition-colors opacity-40 hover:opacity-100"
    >
      D
    </button>
  );

  return (
    <div
      className="fixed bottom-4 right-4 z-[200] w-72 bg-white border-4 border-black rounded-2xl shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] overflow-hidden"
      style={{ fontFamily: "'Inter', sans-serif" }}
    >
      {/* Header */}
      <div className="bg-stone-900 px-4 py-2.5 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-lime-400 rounded-full animate-pulse" />
          <span className="text-[11px] font-black uppercase tracking-widest text-white">Dev Panel</span>
          <span className="text-[9px] text-stone-500 font-mono">Ctrl+Shift+D</span>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => setMinimized(!minimized)} className="text-stone-400 hover:text-white transition-colors p-1">
            {minimized ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
          <button onClick={() => setVisible(false)} className="text-stone-400 hover:text-white transition-colors p-1">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {!minimized && (
        <div className="p-2 space-y-2 max-h-[80vh] overflow-y-auto">

          {/* Status */}
          <div className="bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-[10px] font-mono text-stone-500 space-y-0.5">
            <div><span className="text-stone-400">state:</span> <span className="text-amber-600 font-bold">{props.gameState}</span></div>
            <div><span className="text-stone-400">mode:</span> <span className="text-lime-600 font-bold">{props.gameMode}</span></div>
            <div><span className="text-stone-400">user:</span> <span className="text-rose-500 font-bold">{props.userProfile?.name ?? 'none'}</span></div>
            <div><span className="text-stone-400">plan:</span> <span className="text-cyan-600 font-bold">{props.userProfile?.plan ?? 'none'}</span></div>
            <div><span className="text-stone-400">title:</span> <span className="text-amber-600 font-bold">{(props.userProfile as any)?.title ?? 'none'}</span></div>
            <div><span className="text-stone-400">banner:</span> <span className="text-fuchsia-500 font-bold">{props.userProfile?.activeBanner ?? 'none'}</span></div>
          </div>

          {/* Auth screens */}
          <Group title="Auth Screens">
            <Btn label="Login screen" color="bg-stone-100" onClick={() => props.onAuthMode('LOGIN')} />
            <Btn label="Signup screen" color="bg-stone-100" onClick={() => props.onAuthMode('SIGNUP')} />
            <Btn label="Assessment only" color="bg-stone-100" onClick={() => props.onAuthMode('ASSESSMENT')} />
          </Group>

          {/* Mock profiles */}
          <Group title="Set Profile">
            {Object.entries(MOCK_PROFILES).map(([label, profile]) => (
              <Btn key={label} label={label}
                color={profile.plan === 'elite' ? 'bg-amber-50' : profile.plan === 'pro' ? 'bg-stone-100' : 'bg-stone-50'}
                onClick={() => {
                  localStorage.setItem('ielts_user_profile', JSON.stringify(profile));
                  props.onSetProfile(profile);
                }} />
            ))}
          </Group>

          {/* Subscriptions */}
          <Group title="Change Plan">
            {(['free', 'pro', 'elite'] as SubscriptionPlan[]).map(plan => (
              <Btn key={plan} label={`Set plan: ${plan}`}
                color={plan === 'elite' ? 'bg-amber-100' : plan === 'pro' ? 'bg-cyan-50' : 'bg-stone-50'}
                onClick={() => {
                  if (!props.userProfile) return;
                  const updated = { ...props.userProfile, plan };
                  localStorage.setItem('ielts_user_profile', JSON.stringify(updated));
                  props.onSetProfile(updated);
                }} />
            ))}
          </Group>

          {/* Navigate to screens */}
          <Group title="Navigate To">
            {ALL_MODES.map(({ label, state, mode }) => (
              <Btn key={label} label={label} onClick={() => {
                props.setGameState(state);
                props.setGameMode(mode);
              }} />
            ))}
          </Group>

          {/* Banners */}
          <Group title="Set Banner">
            {['none','stone','amber','rose','cyan','lime','rainbow','neon','fire','aurora'].map(id => (
              <Btn key={id} label={`Banner: ${id}`} onClick={() => {
                if (!props.userProfile) return;
                const updated = { ...props.userProfile, activeBanner: id };
                localStorage.setItem('ielts_user_profile', JSON.stringify(updated));
                props.onSetProfile(updated);
              }} />
            ))}
          </Group>

          {/* Reset */}
          <Group title="Reset">
            <Btn label="Clear localStorage + reload" color="bg-rose-50" onClick={() => {
              localStorage.clear();
              sessionStorage.clear();
              window.location.reload();
            }} />
            <Btn label="Go to landing page" color="bg-stone-50" onClick={props.onReset} />
            {props.onShowSubscription && <Btn label="Open Subscription Page" color="bg-amber-50" onClick={props.onShowSubscription} />}
            {props.onShowSocial && <Btn label="Open Social Hub" color="bg-cyan-50" onClick={props.onShowSocial} />}
          </Group>

        </div>
      )}
    </div>
  );
}

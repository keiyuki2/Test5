
import React, { useState } from 'react';
import { IdiomQuestion } from '../types';
import { ArrowRight, Flame, Check, X, RotateCcw, Lightbulb, Puzzle } from 'lucide-react';

interface IdiomGameScreenProps {
  questions: IdiomQuestion[];
  onComplete: () => void;}

export const IdiomGameScreen: React.FC<IdiomGameScreenProps> = ({ questions, onComplete }) => {
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [hasAnswered, setHasAnswered] = useState(false);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [history, setHistory] = useState<boolean[]>([]);
  
  const [matching, setMatching] = useState<{a: string | null, b: string | null}>({a: null, b: null});
  const [matched, setMatched] = useState<number[]>([]);
  const [matchError, setMatchError] = useState<boolean>(false);

  const currentQ = questions && questions[index];

  const handleOptionClick = (option: string) => {
    if (hasAnswered || !currentQ) return;
    setSelectedOption(option);
    setHasAnswered(true);
    const isCorrect = option === (currentQ.variant === 'BINARY' ? 'True' : currentQ.missingWord);
    if (isCorrect) setScore(s => s + 1);
    setHistory(prev => [...prev, isCorrect]);
  };

  const handleMatchSelect = (side: 'a' | 'b', val: string) => {
      if (hasAnswered || matchError || !currentQ) return;
      const newMatching = { ...matching, [side]: val };
      setMatching(newMatching);
      
      if (newMatching.a && newMatching.b) {
          const pairIdx = (currentQ.pairs || []).findIndex(p => p.a === newMatching.a && p.b === newMatching.b);
          if (pairIdx !== -1) {
              const newMatched = [...matched, pairIdx];
              setMatched(newMatched);
              setMatching({a: null, b: null});
              if (newMatched.length === (currentQ.pairs?.length || 0)) {
                  setHasAnswered(true);
                  setScore(s => s + 1);
                  setHistory(prev => [...prev, true]);
              }
          } else {
              setMatchError(true);
              setTimeout(() => { setMatching({a: null, b: null}); setMatchError(false); }, 600);
          }
      }
  };

  const handleNext = () => {
    if (index < questions.length - 1) {
      setIndex(i => i + 1);
      setHasAnswered(false);
      setSelectedOption(null);
      setMatched([]);
      setMatchError(false);
    } else {
      onComplete();
    }
  };

  if (!currentQ || index >= questions.length) {
      return (
          <div className="w-full max-w-2xl mx-auto py-12 px-4 animate-slide-up">
              <div className="bg-white rounded-[3rem] border-4 border-black p-8 text-center shadow-[12px_12px_0px_0px_rgba(0,0,0,1)]">
                  <Flame className="w-20 h-20 text-orange-500 mx-auto mb-6" />
                  <h2 className="text-4xl font-black mb-4 uppercase">Mission Accomplished</h2>
                  <p className="text-3xl font-black text-slate-400 mb-8">Score: {score}/{questions?.length || 0}</p>
                  <button onClick={onComplete} className="w-full py-4 bg-black text-white rounded-2xl font-black uppercase shadow-[6px_6px_0px_0px_rgba(0,0,0,1)]">Return to Base</button>
              </div>
          </div>
      );
  }

  const currentOptions = currentQ.options || (currentQ.variant === 'BINARY' ? ['True', 'False'] : []);
  const sentenceParts = (currentQ.sentence || '').split('_______');

  return (
    <div className="w-full max-w-4xl mx-auto py-4 px-4 animate-slide-up flex flex-col min-h-[calc(100vh-120px)]">
      <div className="flex justify-between items-center mb-6 bg-white p-3 rounded-2xl border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
          <div className="flex items-center gap-2"><Puzzle className="w-5 h-5 text-orange-500" /><span className="text-lg font-black">{score}</span></div>
          <p className="text-lg font-black text-orange-500">{index + 1}/{questions.length}</p>
      </div>
      <div className="flex-1 flex flex-col justify-center items-center pb-24">
          {currentQ.variant === 'MATCH' ? (
              <div className="w-full max-w-2xl">
                  <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">{(currentQ.pairs || []).map((p, idx) => (
                        <button key={p.a} onClick={() => handleMatchSelect('a', p.a)} className={`w-full p-4 rounded-xl border-4 font-bold transition-all ${matched.includes(idx) ? 'bg-emerald-100 opacity-40' : matching.a === p.a ? 'bg-indigo-600 text-white' : 'bg-white'}`}>{p.a}</button>
                      ))}</div>
                      <div className="space-y-2">{(currentQ.pairs || []).map((p, idx) => (
                        <button key={p.b} onClick={() => handleMatchSelect('b', p.b)} className={`w-full p-4 rounded-xl border-4 font-bold transition-all ${matched.includes(idx) ? 'bg-emerald-100 opacity-40' : matching.b === p.b ? 'bg-indigo-600 text-white' : 'bg-white'}`}>{p.b}</button>
                      ))}</div>
                  </div>
              </div>
          ) : (
              <div className="w-full text-center">
                  <div className="bg-white p-8 md:p-12 rounded-[2.5rem] border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] mb-8">
                      <h2 className="text-2xl md:text-4xl font-black text-slate-900 leading-snug">
                          {sentenceParts.map((part, i) => <React.Fragment key={i}>{part}{i < sentenceParts.length - 1 && <span className="inline-block border-b-4 border-black min-w-[120px] mx-2 text-indigo-600">{hasAnswered ? currentQ.missingWord : "_______"}</span>}</React.Fragment>)}
                      </h2>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto">
                      {currentOptions.map(opt => (
                          <button key={opt} onClick={() => handleOptionClick(opt)} disabled={hasAnswered} className={`p-5 rounded-2xl border-4 font-black text-xl transition-all ${hasAnswered ? (opt === currentQ.missingWord ? 'bg-emerald-400 border-black' : 'bg-white opacity-40') : 'bg-white hover:border-black'}`}>{opt}</button>
                      ))}
                  </div>
              </div>
          )}
          {hasAnswered && <div className="fixed bottom-8 left-1/2 -translate-x-1/2 w-full max-w-xs px-4 animate-slide-up"><button onClick={handleNext} className="w-full py-5 bg-black text-white rounded-[2rem] font-black text-2xl uppercase border-4 border-transparent hover:border-black flex items-center justify-center gap-2">Next <ArrowRight className="w-7 h-7" /></button></div>}
      </div>
    </div>
  );
};

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { generatePronunciationSentence, evaluatePronunciation } from '../services/geminiService';
import { PronunciationResult, Difficulty } from '../types';
import { Mic, Square, ArrowRight, Loader2, Volume2, Check, AlertCircle, RefreshCw, Play, Pause } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { sfx } from '../services/soundService';

interface Props { difficulty: Difficulty; onComplete: () => void; }

// ── Animated sound ball ────────────────────────────────────────────────────────
function SoundBall({ recording, volume }: { recording: boolean; volume: number }) {
  const rings = [1, 1.5, 2.2];
  const scale = 1 + (volume / 255) * 0.4;

  return (
    <div className="relative flex items-center justify-center w-40 h-40">
      {/* Ripple rings — grow with volume */}
      {recording && rings.map((r, i) => (
        <motion.div key={i}
          className="absolute rounded-full border-4 border-rose-400"
          style={{ width: 80 * r, height: 80 * r, opacity: 0.6 - i * 0.18 }}
          animate={{ scale: [1, 1 + (volume / 255) * (0.3 + i * 0.15), 1], opacity: [0.5 - i*0.15, 0.1, 0.5 - i*0.15] }}
          transition={{ duration: 0.3, repeat: Infinity, ease: 'easeInOut' }}
        />
      ))}
      {/* Core ball */}
      <motion.button
        animate={{ scale: recording ? scale : 1 }}
        transition={{ duration: 0.05 }}
        className={`relative z-10 w-24 h-24 rounded-full border-4 border-black flex items-center justify-center shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-colors duration-150 ${
          recording ? 'bg-rose-500 text-white' : 'bg-white text-stone-900 hover:bg-stone-50'
        }`}
      >
        {recording ? <Square className="w-10 h-10 fill-current" /> : <Mic className="w-10 h-10" />}
      </motion.button>
    </div>
  );
}

// ── Word chip ─────────────────────────────────────────────────────────────────
function WordChip({ word, isCorrect, errorType, correction, onPlayFix }: {
  word: string; isCorrect: boolean; errorType?: string; correction?: string; onPlayFix: () => void;
}) {
  const [showTip, setShowTip] = useState(false);
  return (
    <div className="relative inline-flex flex-col items-center gap-1">
      <button
        onClick={() => !isCorrect && setShowTip(s => !s)}
        className={`px-3 py-1.5 rounded-xl border-4 font-bold text-base transition-all ${
          isCorrect
            ? 'bg-lime-100 border-lime-400 text-lime-800'
            : 'bg-rose-50 border-rose-400 text-rose-700 cursor-pointer hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5'
        }`}>
        {word}
        {!isCorrect && <span className="ml-1 text-rose-400 text-xs">✕</span>}
      </button>
      <AnimatePresence>
        {showTip && !isCorrect && (
          <motion.div initial={{ opacity:0, y:4 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0, y:4 }}
            className="absolute bottom-full mb-2 z-20 bg-stone-900 text-white rounded-xl p-3 w-48 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] border-4 border-black">
            <p className="text-[10px] font-black uppercase tracking-widest text-stone-400 mb-1">{errorType || 'Pronunciation'}</p>
            {correction && <p className="font-black text-sm text-amber-400 mb-2">Say: "{correction}"</p>}
            <button onClick={onPlayFix}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-400 text-black border-2 border-black rounded-lg font-black text-[10px] uppercase tracking-widest hover:bg-amber-300 transition-colors w-full justify-center">
              <Volume2 className="w-3 h-3" /> Play Example
            </button>
            {/* Triangle */}
            <div className="absolute top-full left-1/2 -translate-x-1/2 w-3 h-3 bg-stone-900 border-r-4 border-b-4 border-black rotate-45 -translate-y-1.5" />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export const PronunciationGameScreen: React.FC<Props> = ({ difficulty, onComplete }) => {
  const [sentence, setSentence] = useState('');
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [recording, setRecording] = useState(false);
  const [result, setResult] = useState<PronunciationResult | null>(null);
  const [volume, setVolume] = useState(0);
  const [liveText, setLiveText] = useState('');
  const [isSpeaking, setIsSpeaking] = useState(false);

  const mediaRecRef  = useRef<MediaRecorder | null>(null);
  const chunksRef    = useRef<Blob[]>([]);
  const analyserRef  = useRef<AnalyserNode | null>(null);
  const animFrameRef = useRef<number>(0);
  const recogRef     = useRef<any>(null);
  const liveTextRef  = useRef('');

  useEffect(() => { loadSentence(); return () => { window.speechSynthesis.cancel(); }; }, [difficulty]);

  const loadSentence = async () => {
    setLoading(true); setResult(null); setLiveText('');
    try { const s = await generatePronunciationSentence(difficulty); setSentence(s); }
    catch (e) { setSentence("The weather in Ulaanbaatar can be very extreme in winter."); }
    finally { setLoading(false); }
  };

  // ── Volume analyser loop ──────────────────────────────────────────────────
  const startVolumeAnalysis = (stream: MediaStream) => {
    const ctx = new AudioContext();
    const src = ctx.createMediaStreamSource(stream);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 256;
    src.connect(analyser);
    analyserRef.current = analyser;
    const buf = new Uint8Array(analyser.frequencyBinCount);
    const tick = () => {
      analyser.getByteFrequencyData(buf);
      const avg = buf.reduce((a, b) => a + b, 0) / buf.length;
      setVolume(avg);
      animFrameRef.current = requestAnimationFrame(tick);
    };
    tick();
  };

  // ── Live speech recognition ───────────────────────────────────────────────
  const startRecognition = () => {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) return;
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recog = new SR();
    recog.continuous = true;
    recog.interimResults = true;
    recog.lang = 'en-US';
    recog.onresult = (e: any) => {
      let text = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        text += e.results[i][0].transcript;
      }
      setLiveText(text);
      liveTextRef.current = text;
    };
    recog.start();
    recogRef.current = recog;
  };

  const stopRecognition = () => {
    try { recogRef.current?.stop(); } catch {}
    recogRef.current = null;
  };

  const handleStartRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecRef.current = new MediaRecorder(stream);
      chunksRef.current = [];
      mediaRecRef.current.ondataavailable = e => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      mediaRecRef.current.start();
      setRecording(true);
      setLiveText('');
      liveTextRef.current = '';
      startVolumeAnalysis(stream);
      startRecognition();
      sfx.click();
    } catch {
      alert('Microphone permission required.');
    }
  }, []);

  const handleStopRecording = useCallback(() => {
    if (!mediaRecRef.current || !recording) return;
    cancelAnimationFrame(animFrameRef.current);
    stopRecognition();
    setVolume(0);
    mediaRecRef.current.stop();
    setRecording(false);

    mediaRecRef.current.onstop = async () => {
      mediaRecRef.current?.stream.getTracks().forEach(t => t.stop());
      // Use the live transcript captured by SpeechRecognition — no audio model needed
      const capturedText = liveTextRef.current || '';
      if (!capturedText.trim()) {
        alert('No speech detected. Please speak clearly and try again.');
        setAnalyzing(false);
        return;
      }
      setAnalyzing(true);
      try {
        const res = await evaluatePronunciation(sentence, capturedText);
        setResult(res);
        sfx[res.score >= 70 ? 'correct' : 'wrong']();
      } catch { alert('Analysis failed. Please try again.'); }
      finally { setAnalyzing(false); }
    };
  }, [recording, sentence]);

  const playTTS = (text: string, rate = 0.85) => {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'en-GB'; u.rate = rate;
    u.onstart = () => setIsSpeaking(true);
    u.onend = () => setIsSpeaking(false);
    window.speechSynthesis.speak(u);
  };

  const playWordFix = (word: string, correction?: string) => {
    playTTS(correction || word, 0.7);
  };

  if (loading) return (
    <div className="flex h-[50vh] items-center justify-center flex-col gap-4">
      <Loader2 className="w-10 h-10 animate-spin text-stone-400" />
      <p className="font-black text-sm uppercase tracking-widest text-stone-400">Loading challenge...</p>
    </div>
  );

  return (
    <div className="w-full max-w-3xl mx-auto py-8 px-4 flex flex-col items-center gap-6" style={{ fontFamily:"'Inter',sans-serif" }}>

      {/* Header */}
      <div className="w-full text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-rose-500 border-4 border-black rounded-xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] mb-4">
          <Mic className="w-4 h-4 text-white" />
          <span className="font-black text-white text-xs uppercase tracking-widest">Pronunciation Lab</span>
        </div>
        <h2 className="text-3xl font-black text-stone-900 uppercase tracking-tighter leading-tight">Read This Aloud</h2>
      </div>

      {/* Sentence card */}
      <div className="w-full bg-white border-4 border-black rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)]">
        <button onClick={() => playTTS(sentence)} className="w-full text-left group">
          <p className="text-2xl md:text-3xl font-bold text-stone-900 leading-snug text-center mb-3">
            "{sentence}"
          </p>
          <div className="flex items-center justify-center gap-2 text-stone-400 group-hover:text-stone-700 transition-colors">
            {isSpeaking
              ? <><Pause className="w-4 h-4" /><span className="text-xs font-black uppercase tracking-widest">Speaking...</span></>
              : <><Volume2 className="w-4 h-4" /><span className="text-xs font-black uppercase tracking-widest">Tap to listen</span></>
            }
          </div>
        </button>
      </div>

      {!result ? (
        <>
          {/* Live transcript box */}
          <div className={`w-full bg-white border-4 rounded-2xl p-4 min-h-[56px] flex items-center justify-center transition-all ${recording ? 'border-rose-400 shadow-[3px_3px_0px_0px_rgba(239,68,68,0.5)]' : 'border-stone-200'}`}>
            {liveText ? (
              <p className="text-stone-700 font-medium text-center leading-relaxed">{liveText}</p>
            ) : (
              <p className="text-stone-300 font-medium text-sm text-center">
                {recording ? 'Listening...' : 'Your speech will appear here'}
              </p>
            )}
          </div>

          {/* Sound ball + button */}
          <div className="flex flex-col items-center gap-4">
            <div
              onMouseDown={handleStartRecording}
              onMouseUp={handleStopRecording}
              onTouchStart={e => { e.preventDefault(); handleStartRecording(); }}
              onTouchEnd={e => { e.preventDefault(); handleStopRecording(); }}
              className="cursor-pointer select-none"
            >
              <SoundBall recording={recording} volume={volume} />
            </div>
            <div className={`px-4 py-2 rounded-xl border-4 font-black text-xs uppercase tracking-widest transition-all ${
              recording
                ? 'bg-rose-100 border-rose-400 text-rose-700'
                : 'bg-stone-100 border-stone-300 text-stone-500'
            }`}>
              {analyzing ? 'Analyzing...' : recording ? 'Release to stop' : 'Hold to record'}
            </div>
            {analyzing && (
              <div className="flex items-center gap-2 text-stone-400">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="text-xs font-black uppercase tracking-widest">Checking phonemes...</span>
              </div>
            )}
          </div>
        </>
      ) : (
        /* Results */
        <motion.div initial={{ opacity:0, y:16 }} animate={{ opacity:1, y:0 }} transition={{ duration:0.35 }}
          className="w-full space-y-5">

          {/* Score card */}
          <div className="bg-white border-4 border-black rounded-3xl p-6 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] flex items-center gap-6">
            {/* Ring score */}
            <div className="relative flex-shrink-0">
              {(() => {
                const s = result.score, size = 96, r = 38, circ = 2*Math.PI*r;
                const color = s>=80?'#4ade80':s>=60?'#fbbf24':'#f87171';
                const rank = s>=90?'S':s>=80?'A':s>=65?'B':s>=50?'C':'D';
                const rankBg: Record<string,string> = {S:'bg-amber-400',A:'bg-lime-400',B:'bg-cyan-400',C:'bg-orange-400',D:'bg-rose-400'};
                return (
                  <div className="relative" style={{width:size,height:size}}>
                    <svg width={size} height={size} className="rotate-[-90deg] absolute inset-0">
                      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#f5f5f4" strokeWidth={8}/>
                      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={8} strokeLinecap="round"
                        strokeDasharray={circ} strokeDashoffset={circ*(1-s/100)}
                        style={{transition:'stroke-dashoffset 1s ease-out',filter:`drop-shadow(0 0 6px ${color}88)`}}/>
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className="font-black text-xl text-stone-900 leading-none">{result.score}</span>
                      <span className="text-[8px] font-black text-stone-400 uppercase">Score</span>
                    </div>
                    <div className={`absolute -top-1 -right-1 w-8 h-8 ${rankBg[rank]} border-4 border-black rounded-lg flex items-center justify-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]`}>
                      <span className="font-black text-black text-xs">{rank}</span>
                    </div>
                  </div>
                );
              })()}
            </div>

            <div className="flex-1">
              <p className="text-[10px] font-black uppercase tracking-widest text-stone-400 mb-1.5">AI Feedback</p>
              <p className="font-medium text-stone-700 text-sm leading-relaxed">{result.analysis}</p>
            </div>
          </div>

          {/* Word breakdown — tappable with correction popup */}
          {result.words && result.words.length > 0 && (
            <div className="bg-white border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-400 mb-4">
                Word Breakdown — tap a red word for tip
              </p>
              <div className="flex flex-wrap gap-2">
                {result.words.map((w, i) => (
                  <WordChip key={i} word={w.word} isCorrect={w.isCorrect}
                    errorType={w.errorType} correction={w.correction}
                    onPlayFix={() => playWordFix(w.word, w.correction)} />
                ))}
              </div>
              <div className="mt-4 flex items-center gap-3 text-xs font-bold text-stone-400">
                <div className="flex items-center gap-1.5"><div className="w-3 h-3 bg-lime-200 border-2 border-lime-400 rounded" />Correct</div>
                <div className="flex items-center gap-1.5"><div className="w-3 h-3 bg-rose-100 border-2 border-rose-400 rounded" />Needs work</div>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3">
            <button onClick={() => playTTS(sentence)}
              className="flex items-center justify-center gap-2 px-5 py-3 bg-white text-stone-900 border-4 border-black rounded-xl font-black text-xs uppercase tracking-widest shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-all">
              <Volume2 className="w-4 h-4" /> Listen Again
            </button>
            <button onClick={() => { setResult(null); setLiveText(''); sfx.navigate(); }}
              className="flex items-center justify-center gap-2 px-5 py-3 bg-stone-100 text-stone-700 border-4 border-stone-300 rounded-xl font-black text-xs uppercase tracking-widest shadow-[3px_3px_0px_0px_rgba(0,0,0,0.3)] hover:-translate-y-0.5 hover:border-black hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-all">
              <RefreshCw className="w-4 h-4" /> Retry
            </button>
            <button onClick={() => { loadSentence(); sfx.navigate(); }}
              className="flex-1 flex items-center justify-center gap-2 py-3 bg-stone-900 text-white border-4 border-black rounded-xl font-black text-xs uppercase tracking-widest shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-none transition-all group">
              Next <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
};

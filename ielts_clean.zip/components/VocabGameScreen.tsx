import React, { useState, useEffect, useRef } from 'react';
import { VocabQuestion, Language } from '../types';
import { translations } from '../translations';
import { 
    Keyboard, MousePointerClick, Type, Lightbulb, Bookmark, 
    BookmarkCheck, X, Loader2, HelpCircle, ArrowRight, BookOpen,
    PenTool, Eye, History
} from 'lucide-react';

interface VocabGameScreenProps {
  questions: VocabQuestion[];
  onComplete: () => void;  lang: Language;
}

export const VocabGameScreen: React.FC<VocabGameScreenProps> = ({ 
  questions, 
  onComplete,
  lang 
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isTypingMode, setIsTypingMode] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [isRevealed, setIsRevealed] = useState(false);
  const [hasSurrendered, setHasSurrendered] = useState(false);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [inspectedItem, setInspectedItem] = useState<{ word: string, definition: string, example?: string, band?: string, loading?: boolean, error?: boolean } | null>(null);
  
  // Scramble for Spelling
  const [scrambledLetters, setScrambledLetters] = useState<{ char: string, id: number, used: boolean }[]>([]);
  const [spellingInput, setSpellingInput] = useState<string[]>([]);

  const t = translations[lang];
  const currentQuestion = questions[currentIndex];
  const questionType = currentQuestion?.questionType || 'SENTENCE';
  const isQuestionBookmarked = false;
  
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
      // Reset for new question
      setInputValue('');
      setIsRevealed(false);
      setHasSurrendered(false);
      setSelectedOption(null);
      setInspectedItem(null);
      
      if (currentQuestion && questionType === 'SPELLING') {
          const letters = currentQuestion.correctAnswer.split('').map((char, i) => ({ char, id: i, used: false }));
          // Shuffle
          for (let i = letters.length - 1; i > 0; i--) {
              const j = Math.floor(Math.random() * (i + 1));
              [letters[i], letters[j]] = [letters[j], letters[i]];
          }
          setScrambledLetters(letters);
          setSpellingInput(new Array(currentQuestion.correctAnswer.length).fill(''));
      }
  }, [currentIndex, currentQuestion, questionType]);

  const handleNextQuizQuestion = () => {
      if (currentIndex < questions.length - 1) {
          setCurrentIndex(prev => prev + 1);
      } else {
          onComplete();
      }
  };

  const handleHint = () => {
      if (true) {
          if (isTypingMode) {
              setInputValue(prev => {
                  const target = currentQuestion.correctAnswer;
                  if (prev.length < target.length) return target.substring(0, prev.length + 1);
                  return prev;
              });
          }
      }
  };

  const handleDontKnow = () => {
      setHasSurrendered(true);
      setInputValue(currentQuestion.correctAnswer);
  };

  const handleTypingSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!inputValue.trim()) return;
      setIsRevealed(true);
  };

  const handleOptionClick = (option: string) => {
      setSelectedOption(option);
      setIsRevealed(true);
  };

  const handleLetterClick = (item: { char: string, id: number }) => {
      const emptyIndex = spellingInput.findIndex(c => c === '');
      if (emptyIndex !== -1) {
          const newInput = [...spellingInput];
          newInput[emptyIndex] = item.char;
          setSpellingInput(newInput);
          
          setScrambledLetters(prev => prev.map(l => l.id === item.id ? { ...l, used: true } : l));
          
          if (emptyIndex === spellingInput.length - 1) {
              setIsRevealed(true);
          }
      }
  };

  const handleSlotClick = (index: number) => {
      const char = spellingInput[index];
      if (char) {
          const newScrambled = [...scrambledLetters];
          const lIndex = newScrambled.findIndex(l => l.used && l.char === char);
          if (lIndex !== -1) newScrambled[lIndex].used = false;
          setScrambledLetters(newScrambled);

          const newInput = [...spellingInput];
          newInput[index] = '';
          setSpellingInput(newInput);
          setIsRevealed(false);
      }
  };

  const renderSentence = (masked: boolean) => {
      if (!currentQuestion) return null;
      const parts = currentQuestion.contextSentence.split('_______');
      if (parts.length === 1) return <p>{currentQuestion.contextSentence}</p>;
      
      return (
          <p>
              {parts[0]}
              <span className="font-black text-indigo-600 border-b-4 border-black mx-1 min-w-[80px] inline-block text-center">
                  {masked ? (hasSurrendered || isRevealed ? currentQuestion.correctAnswer : '_______') : currentQuestion.correctAnswer}
              </span>
              {parts[1]}
          </p>
      );
  };

  const onToggleBookmark = (_id: string, _q: any) => {};

  // Logic to determine phase: usually just 'QUIZ' in this simplified version
  const phase = 'QUIZ'; 
  const isReviewWord = false; 
  
  if (phase === 'QUIZ' && currentQuestion) {
    const quizOptions = currentQuestion.options || [];
    const disabledOptions: string[] = []; 

    const isInspectedBookmarked = false;

    return (
        <div className="w-full max-w-3xl mx-auto animate-slide-up relative py-8 px-4">
        
        {/* Dynamic Island Header */}
        <div className="w-full flex justify-center mb-8 sticky top-6 z-50">
            <div className="bg-[#0f172a] text-white rounded-full p-2 pl-4 pr-2 flex items-center justify-between gap-4 shadow-[0_8px_30px_rgb(0,0,0,0.2)] border border-slate-800 w-full max-w-[95%] md:max-w-lg transition-all">
                
                {/* Left: Mode Switcher */}
                <div className="flex items-center">
                    {questionType !== 'SPELLING' && (
                        <button onClick={() => setIsTypingMode(!isTypingMode)} 
                            className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-full text-[10px] md:text-xs font-bold transition-all border border-slate-700"
                        >
                            {isTypingMode ? <MousePointerClick className="w-3 h-3 md:w-4 md:h-4" /> : <Keyboard className="w-3 h-3 md:w-4 md:h-4" />}
                            <span className="hidden sm:inline">{isTypingMode ? t.vocab.choiceMode : t.vocab.typingMode}</span>
                        </button>
                    )}
                    {questionType === 'SPELLING' && (
                        <div className="flex items-center gap-2 px-4 py-2 bg-yellow-500/10 text-yellow-500 rounded-full text-xs font-bold border border-yellow-500/20">
                            <Type className="w-3 h-3" /> {t.vocab.spelling}
                        </div>
                    )}
                </div>

                {/* Right: Actions */}
                <div className="flex items-center gap-2">
                    {!isRevealed && !hasSurrendered && (
                        <button onClick={handleHint} disabled={false} className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-full text-[10px] md:text-xs font-bold text-yellow-400 transition-colors border border-slate-700 disabled:opacity-50">
                            <Lightbulb className="w-3 h-3 md:w-4 md:h-4 fill-current" />
                            <span className="hidden sm:inline">Hint</span>
                        </button>
                    )}
                    <button onClick={() => onToggleBookmark(currentQuestion.id, currentQuestion)} className={`p-2 rounded-full transition-all ${isQuestionBookmarked ? "bg-amber-400 text-black" : "bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 border border-slate-700"}`}>
                        {isQuestionBookmarked ? <BookmarkCheck className="w-4 h-4 fill-current" /> : <Bookmark className="w-4 h-4" />}
                    </button>
                </div>
            </div>
        </div>

        <div className="w-full bg-slate-100 h-2.5 rounded-full mb-10 overflow-hidden relative z-10 border border-slate-200 shadow-inner">
            <div className="bg-indigo-600 h-full transition-all duration-500 ease-out" style={{ width: `${((currentIndex) / questions.length) * 100}%` }} />
        </div>
        
        <div className="grid grid-cols-1 gap-8 relative">
            {inspectedItem && (
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-40 w-11/12 max-w-sm bg-white border-4 border-black rounded-3xl shadow-[16px_16px_0px_0px_rgba(0,0,0,1)] p-0 animate-scale-in">
                    <div className="bg-slate-900 text-white p-4 rounded-t-[1.3rem] flex justify-between items-center border-b-4 border-black">
                        <h3 className="text-xl font-black capitalize">{inspectedItem.word}</h3>
                        <button onClick={() => setInspectedItem(null)} className="hover:text-rose-400"><X className="w-6 h-6" /></button>
                    </div>
                    <div className="p-6">
                        {inspectedItem.loading ? (
                            <div className="flex flex-col items-center justify-center py-6 gap-4"><Loader2 className="w-8 h-8 animate-spin text-black" /></div>
                        ) : inspectedItem.error ? (
                            <div className="text-center font-bold text-rose-500">Error loading.</div>
                        ) : (
                            <>
                                {inspectedItem.band && <span className="inline-block mb-3 bg-black text-white text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider">Band {inspectedItem.band}</span>}
                                <div className="space-y-4">
                                    <div>
                                        <p className="text-xs font-black uppercase tracking-widest mb-1 text-slate-400">{t.vocab.meaning}</p>
                                        <p className="text-slate-900 font-bold leading-snug">{inspectedItem.definition}</p>
                                    </div>
                                    {inspectedItem.example && (
                                        <div className="bg-slate-100 rounded-lg p-3 border-2 border-slate-200 border-l-4 border-l-black">
                                            <p className="text-sm text-slate-600 italic font-medium">"{inspectedItem.example}"</p>
                                        </div>
                                    )}
                                </div>
                            </>
                        )}
                    </div>
                </div>
            )}
            {inspectedItem && <div className="absolute inset-0 bg-black/20 backdrop-blur-sm z-30 rounded-[2rem]" onClick={() => setInspectedItem(null)}></div>}
            
            <div className={`bg-white rounded-[2.5rem] shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] border-4 ${isReviewWord ? 'border-yellow-500' : 'border-black'} p-10 md:p-14 relative overflow-hidden text-center min-h-[320px] flex flex-col justify-center items-center`}>
                {isReviewWord && (
                    <div className="absolute top-0 left-0 bg-yellow-400 text-black px-4 py-2 rounded-br-2xl border-b-4 border-r-4 border-black z-20 font-black uppercase text-xs tracking-widest flex items-center gap-2 shadow-md">
                        <History className="w-4 h-4" /> Past Mistake
                    </div>
                )}
                <div className="absolute top-6 left-6 bg-white text-black text-xs font-black px-4 py-2 rounded-full uppercase tracking-widest border-2 border-black flex items-center gap-2">
                    {questionType === 'DEFINITION' ? <><BookOpen className="w-3 h-3" /> {t.vocab.matchDef} </> : questionType === 'SPELLING' ? <><Type className="w-3 h-3" /> {t.vocab.anagram} </> : <><PenTool className="w-3 h-3" /> {t.vocab.fillBlank} </>}
                </div>
                <div className="absolute top-6 right-6 bg-black text-white text-xs font-black px-4 py-2 rounded-full uppercase tracking-widest border-2 border-transparent">
                    Band {currentQuestion.band}
                </div>
                <div className="text-2xl md:text-4xl text-slate-900 leading-snug mb-8 font-black font-sans select-none">
                    {questionType === 'DEFINITION' ? (
                        <div className="flex flex-col gap-4 animate-fade-in">
                            <span className="text-slate-400 text-sm font-black uppercase tracking-widest">{t.vocab.meaning}</span>
                            <p>{currentQuestion.definition}</p>
                        </div>
                    ) : renderSentence(true)}
                </div>
                <div className={`transition-all duration-300 overflow-hidden w-full ${isRevealed && !hasSurrendered ? 'opacity-100 max-h-40 translate-y-0' : 'opacity-0 max-h-0 translate-y-4'}`}>
                    <div className="bg-amber-100 rounded-xl p-4 inline-block border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] max-w-xl">
                        {questionType === 'DEFINITION' ? (
                            <>
                                <p className="text-xs text-amber-800 uppercase tracking-widest font-black mb-1">{t.vocab.example}</p>
                                <p className="text-black font-bold">{currentQuestion.contextSentence.replace('_______', currentQuestion.word)}</p>
                            </>
                        ) : (
                            <>
                                <p className="text-xs text-amber-800 uppercase tracking-widest font-black mb-1">{t.vocab.meaning}</p>
                                <p className="text-black font-bold">{currentQuestion.definition}</p>
                            </>
                        )}
                    </div>
                </div>
            </div>

            <div className={`transition-all duration-500 ${hasSurrendered ? 'bg-white rounded-[2rem] p-8 border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] z-20 relative' : ''}`}>
                {hasSurrendered && (
                    <div className="text-center mb-6 text-indigo-600 font-black animate-pulse flex items-center justify-center gap-2 text-sm uppercase tracking-wider">
                        <Eye className="w-5 h-5" />Inspection Mode Active
                    </div>
                )}
                {questionType === 'SPELLING' ? (
                    <div className="flex flex-col gap-6 items-center">
                        <div className="flex flex-wrap justify-center gap-2 md:gap-3">
                            {(spellingInput || []).map((char, idx) => (
                                <button key={idx} onClick={() => handleSlotClick(idx)} disabled={isRevealed} className={`w-10 h-10 md:w-14 md:h-14 rounded-lg border-4 border-black flex items-center justify-center text-xl md:text-2xl font-black uppercase transition-all ${char ? (isRevealed ? (spellingInput.join('').toLowerCase() === currentQuestion.correctAnswer.toLowerCase() ? 'bg-emerald-400 text-black' : 'bg-rose-400 text-black') : 'bg-white text-black hover:bg-rose-100') : 'bg-slate-100 border-dashed border-slate-300'}`}>
                                    {char}
                                </button>
                            ))}
                        </div>
                        <div className="flex flex-wrap justify-center gap-2 md:gap-3 p-4 bg-slate-100 rounded-2xl border-2 border-black max-w-2xl">
                            {(scrambledLetters || []).map((item, idx) => (
                                <button key={idx} onClick={() => handleLetterClick(item)} disabled={item.used || isRevealed} className={`w-10 h-10 md:w-14 md:h-14 rounded-lg border-4 border-black flex items-center justify-center text-xl md:text-2xl font-black uppercase transition-all ${item.used ? 'bg-slate-300 opacity-30' : 'bg-yellow-300 hover:bg-yellow-200 text-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]'}`}>
                                    {item.char}
                                </button>
                            ))}
                        </div>
                    </div>
                ) : isTypingMode && !hasSurrendered ? (
                    <form onSubmit={handleTypingSubmit} className="relative max-w-lg mx-auto w-full">
                        <input ref={inputRef} type="text" value={inputValue} onChange={(e) => setInputValue(e.target.value)} disabled={isRevealed} placeholder="Type the word..." className={`w-full p-5 rounded-2xl border-4 text-center text-2xl font-black outline-none transition-all ${isRevealed ? (inputValue.trim().toLowerCase() === currentQuestion.correctAnswer.toLowerCase() ? "bg-emerald-100 border-emerald-500" : "bg-rose-100 border-rose-500") : "bg-white border-black"}`} />
                    </form>
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {quizOptions.map((option, idx) => {
                            const optionWord = option.word;
                            const isDisabled = disabledOptions.includes(optionWord);
                            let btnClass = "bg-white border-black text-slate-700 hover:bg-indigo-100 hover:text-black hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)]";
                            if (isDisabled) btnClass = "bg-slate-100 border-slate-200 text-slate-300 cursor-not-allowed opacity-40";
                            else if (isRevealed) {
                                if (optionWord === currentQuestion.correctAnswer) btnClass = "bg-emerald-400 border-black text-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]";
                                else if (optionWord === selectedOption) btnClass = "bg-rose-400 border-black text-black opacity-80 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]";
                                else btnClass = "bg-slate-100 border-slate-300 text-slate-400 opacity-50";
                            } else if (hasSurrendered) {
                                btnClass = "bg-slate-50 border-slate-300 text-slate-500 cursor-zoom-in hover:bg-indigo-100 hover:border-indigo-400 hover:text-indigo-800";
                                if (optionWord === currentQuestion.correctAnswer && !inspectedItem) btnClass += " border-emerald-400 bg-emerald-50"; 
                            }
                            return (
                                <button key={idx} onClick={() => handleOptionClick(optionWord)} disabled={isRevealed || isDisabled} className={`p-5 rounded-xl border-4 font-black text-xl transition-all ${btnClass}`}>
                                    {isDisabled ? "" : optionWord}
                                </button>
                            );
                        })}
                    </div>
                )}
            </div>
        </div>
        
        {!isRevealed && !hasSurrendered && (
            <div className="flex justify-center mt-6">
                <button onClick={handleDontKnow} className="flex items-center gap-2 text-slate-500 hover:text-black text-sm font-black transition-colors px-6 py-3 hover:bg-white rounded-xl border-2 border-transparent hover:border-black uppercase tracking-wider">
                    <HelpCircle className="w-5 h-5" />{t.vocab.dontKnow}
                </button>
            </div>
        )}
        
        {(isRevealed || hasSurrendered) && (
            <div className="flex justify-center mt-10 animate-slide-up">
                <button onClick={handleNextQuizQuestion} className="bg-black text-white px-12 py-5 rounded-2xl font-black text-lg flex items-center gap-3 hover:bg-indigo-600 border-4 border-transparent hover:border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,0.5)] transition-all">
                    {currentIndex < questions.length - 1 ? t.vocab.nextWord : t.vocab.finishSet} <ArrowRight className="w-6 h-6" />
                </button>
            </div>
        )}
        </div>
    );
  }
  
  return null;
};
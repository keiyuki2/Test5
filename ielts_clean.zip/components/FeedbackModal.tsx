
import React, { useState } from 'react';
import { X, Star, Send, MessageSquare, ThumbsUp, Activity } from 'lucide-react';

interface FeedbackModalProps {
  onClose: () => void;
}

export const FeedbackModal: React.FC<FeedbackModalProps> = ({ onClose }) => {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rating === 0) return;

    setIsSubmitting(true);
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      // Auto close after success
      setTimeout(onClose, 2000);
    }, 1500);
  };

  if (isSuccess) {
    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md animate-fade-in">
        <div className="bg-white rounded-[2.5rem] p-12 border-4 border-black shadow-[0_0_50px_rgba(16,185,129,0.3)] text-center max-w-sm w-full animate-scale-in">
          <div className="w-24 h-24 bg-emerald-400 rounded-full flex items-center justify-center mx-auto mb-6 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] animate-bounce">
            <ThumbsUp className="w-12 h-12 text-black" />
          </div>
          <h2 className="text-3xl font-black uppercase tracking-tighter mb-2">Received</h2>
          <p className="text-slate-500 font-bold uppercase tracking-widest text-xs">Thank you for your feedback</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-lg bg-white rounded-[2rem] border-4 border-black shadow-[16px_16px_0px_0px_rgba(0,0,0,1)] overflow-hidden flex flex-col animate-slide-up">
        
        {/* Header */}
        <div className="bg-slate-50 px-8 py-6 border-b-4 border-black flex justify-between items-center relative">
            {/* Tech Decoration */}
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500"></div>
            
            <div className="flex items-center gap-3">
                <div className="bg-black text-white p-2 rounded-lg">
                    <Activity className="w-5 h-5" />
                </div>
                <div>
                    <h2 className="text-xl font-black uppercase tracking-tighter italic">Your Feedback</h2>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Tell us what you think</p>
                </div>
            </div>
            <button 
                onClick={onClose}
                className="w-10 h-10 flex items-center justify-center rounded-xl hover:bg-rose-100 text-slate-400 hover:text-rose-600 transition-colors"
            >
                <X className="w-6 h-6" />
            </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-8 md:p-10 flex flex-col gap-8">
            
            {/* Rating Section */}
            <div className="text-center">
                <p className="text-xs font-black uppercase tracking-widest text-slate-400 mb-4">Rate your experience</p>
                <div className="flex justify-center gap-2" onMouseLeave={() => setHoverRating(0)}>
                    {[1, 2, 3, 4, 5].map((star) => (
                        <button
                            key={star}
                            type="button"
                            className="group relative focus:outline-none"
                            onMouseEnter={() => setHoverRating(star)}
                            onClick={() => setRating(star)}
                        >
                            <Star 
                                className={`w-10 h-10 md:w-12 md:h-12 transition-all duration-200 ${
                                    (hoverRating || rating) >= star 
                                    ? 'fill-yellow-400 text-black scale-110 drop-shadow-md' 
                                    : 'text-slate-300 fill-slate-100 hover:scale-105'
                                }`} 
                                strokeWidth={2.5}
                            />
                        </button>
                    ))}
                </div>
                <p className="h-4 mt-2 text-xs font-bold text-indigo-600 uppercase tracking-widest transition-opacity duration-300">
                    {(hoverRating || rating) === 5 ? "Exceptional" :
                     (hoverRating || rating) === 4 ? "Effective" :
                     (hoverRating || rating) === 3 ? "Standard" :
                     (hoverRating || rating) === 2 ? "Suboptimal" :
                     (hoverRating || rating) === 1 ? "Poor" : ""}
                </p>
            </div>

            {/* Comment Section */}
            <div className="space-y-2">
                <label className="text-xs font-black uppercase tracking-widest text-slate-400 flex items-center gap-2">
                    <MessageSquare className="w-3 h-3" /> Your comments (Optional)
                </label>
                <textarea
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="Report bugs, suggest features, or share your experience..."
                    className="w-full h-32 p-4 bg-slate-50 border-2 border-slate-200 rounded-xl font-medium text-slate-700 focus:outline-none focus:border-black focus:bg-white focus:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-all resize-none placeholder:text-slate-300"
                />
            </div>

            {/* Submit Button */}
            <button
                type="submit"
                disabled={rating === 0 || isSubmitting}
                className={`
                    w-full py-4 rounded-xl font-black uppercase tracking-widest text-sm flex items-center justify-center gap-3 transition-all border-2 border-black
                    ${rating === 0 
                        ? 'bg-slate-100 text-slate-300 border-slate-200 cursor-not-allowed' 
                        : 'bg-indigo-600 text-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] hover:bg-indigo-700 active:translate-y-0 active:shadow-none'
                    }
                `}
            >
                {isSubmitting ? (
                    <>Sending...</>
                ) : (
                    <>Submit <Send className="w-4 h-4" /></>
                )}
            </button>
        </form>
      </div>
    </div>
  );
};


import React, { useState, useEffect, useRef } from 'react';
import { SynapticBridgeQuestion, SynapticFeedback, Difficulty } from '../types';
import { evaluateSynapticBridge } from '../services/geminiService';
import { ArrowRight, Brain, Zap, Send, Check, X, RefreshCw, Info, Sparkles, Activity, Layers, Terminal, ShieldAlert } from 'lucide-react';

interface SynapticBridgeScreenProps {
  questions: SynapticBridgeQuestion[];
  synapseLevels: Record<string, number>;
  difficulty: Difficulty;
  onComplete: (activatedWords: string[]) => void;
}

export const SynapticBridgeScreen: React.FC<SynapticBridgeScreenProps> = ({ questions, synapseLevels, difficulty, onComplete }) => {
  const [index, setIndex] = useState(0);
  const [input, setInput] = useState('');
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [feedback, setFeedback] = useState<SynapticFeedback | null>(null);
  const [activatedThisSession, setActivatedThisSession] = useState<string[]>([]);
  
  const currentQ = questions && questions[index];
  const currentWordLevel = synapseLevels[currentQ?.anchorWord] || 1;

  useEffect(() => {
    setInput('');
    setFeedback(null);
  }, [index]);

  const handleSubmit = async () => {
    if (!input.trim() || isEvaluating) return;
    setIsEvaluating(true);
    try {
        const res = await evaluateSynapticBridge(currentQ, input);
        setFeedback(res);
        if (res.activated) {
            setActivatedThisSession(prev => [...prev, currentQ.anchorWord]);
        }
    } catch (e) {
        console.error(e);
    } finally {
        setIsEvaluating(false);
    }
  };

  const handleNext = () => {
    if (index < questions.length - 1) {
      setIndex(i => i + 1);
    } else {
      onComplete(activatedThisSession);
    }
  };

  const isHardMode = difficulty === Difficulty.HARD;
  const isFoundation = difficulty === Difficulty.FOUNDATION;

  if (!currentQ) return null;

  return (
    <div className={`w-full max-w-6xl mx-auto py-8 md:py-12 px-4 animate-fade-in flex flex-col gap-8 min-h-[80vh] transition-colors duration-1000 ${isHardMode ? 'bg-slate-950/5' : ''}`}>
        {/* Header HUD */}
        <div className={`flex justify-between items-center border-4 p-6 rounded-[2rem] shadow-xl transition-all duration-700 ${isHardMode ? 'bg-black border-rose-500/50 shadow-rose-900/20' : 'bg-slate-900 border-indigo-500/50 shadow-indigo-900/20'}`}>
            <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center border-2 shadow-lg transition-colors ${isHardMode ? 'bg-rose-600 border-rose-400 shadow-rose-500/50' : 'bg-indigo-600 border-indigo-400 shadow-indigo-500/50'}`}>
                    <Brain className="w-6 h-6 text-white" />
                </div>
                <div>
                    <h2 className={`text-xl font-black uppercase tracking-tighter italic text-white`}>
                        Synaptic <span className={isHardMode ? 'text-rose-400' : 'text-indigo-400'}>Bridge</span>
                    </h2>
                    <p className={`text-[10px] font-mono uppercase tracking-widest ${isHardMode ? 'text-rose-300' : 'text-indigo-300'}`}>
                        Protocol: {isHardMode ? 'High_Pressure_Activation' : isFoundation ? 'Lexical_Basics' : 'Standard_Recalibration'}
                    </p>
                </div>
            </div>
            <div className="flex items-center gap-6">
                 <div className="text-right">
                    <p className="text-[10px] font-black uppercase text-slate-500 mb-1">Bridge Progress</p>
                    <div className="flex gap-1">
                        {questions.map((_, i) => (
                            <div key={i} className={`h-1.5 w-6 rounded-full transition-all duration-500 ${i === index ? (isHardMode ? 'bg-rose-400 w-10 shadow-[0_0_10px_#fb7185]' : 'bg-indigo-400 w-10 shadow-[0_0_10px_#818cf8]') : i < index ? 'bg-emerald-500' : 'bg-slate-800'}`}></div>
                        ))}
                    </div>
                 </div>
            </div>
        </div>

        {/* Difficulty Alert for Hard Mode */}
        {isHardMode && !feedback && (
            <div className="bg-rose-500/10 border-2 border-rose-500/30 p-4 rounded-2xl flex items-center gap-4 animate-pulse">
                <ShieldAlert className="w-6 h-6 text-rose-500" />
                <p className="text-xs font-black uppercase text-rose-600 tracking-widest">Synthetic Constraints Enabled: Evaluation sensitivity at maximum.</p>
            </div>
        )}

        {/* Game Area */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            
            {/* Left Panel: Target Word & Constraints */}
            <div className="lg:col-span-4 flex flex-col gap-6">
                <div className={`bg-white rounded-[2.5rem] border-4 border-black p-8 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] relative overflow-hidden group transition-all ${isHardMode ? 'hover:shadow-[12px_12px_0px_0px_rgba(225,29,72,1)]' : ''}`}>
                    <div className={`absolute top-0 right-0 p-4 text-white rounded-bl-3xl border-l-4 border-b-4 border-black font-black text-[10px] uppercase transition-colors ${isHardMode ? 'bg-rose-600' : 'bg-indigo-600'}`}>
                        Synapse Lvl {currentWordLevel}
                    </div>
                    <p className="text-xs font-black uppercase text-slate-400 mb-2 tracking-widest">Anchor Word</p>
                    <h3 className={`text-4xl md:text-5xl font-black tracking-tighter mb-4 capitalize transition-colors ${isHardMode ? 'text-rose-600' : 'text-indigo-600'}`}>
                        {currentQ.anchorWord}
                    </h3>
                    <p className="text-slate-600 font-bold leading-snug mb-6 border-l-4 border-slate-100 pl-4 py-2 italic">
                        "{currentQ.definition}"
                    </p>
                    
                    {currentQ.constraint && (
                        <div className={`mt-4 p-4 rounded-2xl flex items-start gap-3 border-2 transition-colors ${isHardMode ? 'bg-rose-50 border-rose-200' : 'bg-amber-50 border-amber-200'}`}>
                            <Activity className={`w-5 h-5 flex-none mt-1 ${isHardMode ? 'text-rose-500' : 'text-amber-500'}`} />
                            <div>
                                <span className={`text-[10px] font-black uppercase tracking-widest block mb-1 ${isHardMode ? 'text-rose-600' : 'text-amber-600'}`}>Neural Friction</span>
                                <p className={`text-sm font-bold ${isHardMode ? 'text-rose-900' : 'text-amber-900'}`}>{currentQ.constraint}</p>
                            </div>
                        </div>
                    )}
                    
                    {currentQ.targetCollocation && (
                        <div className="mt-4 p-4 bg-cyan-50 border-2 border-cyan-200 rounded-2xl flex items-start gap-3">
                            <Layers className="w-5 h-5 text-cyan-500 flex-none mt-1" />
                            <div>
                                <span className="text-[10px] font-black uppercase text-cyan-600 tracking-widest block mb-1">Target Collocation</span>
                                <p className="text-sm font-bold text-cyan-900">Pair with: <span className="underline decoration-2">{currentQ.targetCollocation}</span></p>
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {/* Right Panel: The Bridge */}
            <div className="lg:col-span-8 flex flex-col gap-6">
                
                {/* Input Context */}
                <div className="bg-slate-100 rounded-[2.5rem] border-4 border-slate-300 p-8 relative">
                    <span className="absolute -top-4 left-8 bg-slate-900 text-white px-4 py-1 rounded-xl font-black text-[10px] uppercase tracking-widest border-2 border-white shadow-md">
                        Simple Input (Band {isFoundation ? '3.0' : isHardMode ? '6.0' : '5.0'})
                    </span>
                    <p className="text-2xl md:text-3xl font-bold text-slate-500 italic leading-tight">
                        "{currentQ.simpleSentence}"
                    </p>
                </div>

                {/* Interaction Node */}
                <div className="flex-1 bg-white rounded-[2.5rem] border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] flex flex-col overflow-hidden relative min-h-[400px]">
                    <div className="bg-slate-900 px-8 py-4 border-b-4 border-black flex justify-between items-center">
                        <div className="flex items-center gap-2">
                            <Terminal className={`w-4 h-4 ${isHardMode ? 'text-rose-400' : 'text-indigo-400'}`} />
                            <span className="text-xs font-black uppercase tracking-widest text-slate-400">Active Recall Buffer</span>
                        </div>
                        {input.length > 0 && (
                            <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase transition-all ${input.toLowerCase().includes(currentQ.anchorWord.toLowerCase()) ? 'bg-emerald-500 text-white animate-pulse' : 'bg-slate-800 text-slate-400'}`}>
                                {input.toLowerCase().includes(currentQ.anchorWord.toLowerCase()) ? 'Anchor Integrated' : 'Waiting for Anchor...'}
                            </div>
                        )}
                    </div>
                    
                    <textarea 
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder={`Engineer a sophisticated alternative using '${currentQ.anchorWord}'...`}
                        className="flex-1 w-full p-10 text-2xl font-bold outline-none resize-none placeholder:text-slate-200 bg-transparent text-slate-900"
                        disabled={isEvaluating || !!feedback}
                    />

                    {!feedback ? (
                        <div className="p-8 border-t-4 border-black bg-slate-50 flex justify-end items-center gap-6">
                            <div className="text-right hidden md:block">
                                <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Syntactic Parity</p>
                                <div className="h-1.5 w-32 bg-slate-200 rounded-full mt-1 overflow-hidden">
                                    <div className={`h-full transition-all duration-300 ${isHardMode ? 'bg-rose-500' : 'bg-indigo-500'}`} style={{width: `${Math.min(100, (input.length/currentQ.simpleSentence.length)*100)}%`}}></div>
                                </div>
                            </div>
                            <button 
                                onClick={handleSubmit}
                                disabled={!input.trim() || isEvaluating}
                                className={`text-white px-12 py-5 rounded-2xl font-black uppercase tracking-widest text-xl transition-all flex items-center gap-4 shadow-[6px_6px_0px_0px_rgba(0,0,0,0.3)] hover:-translate-y-1 active:translate-y-0 active:shadow-none disabled:opacity-50 ${isHardMode ? 'bg-rose-600 hover:bg-rose-700' : 'bg-black hover:bg-indigo-600'}`}
                            >
                                {isEvaluating ? <><RefreshCw className="animate-spin" /> Analyzing</> : <><Send className="w-6 h-6" /> Activate</>}
                            </button>
                        </div>
                    ) : (
                        <div className={`p-8 border-t-4 border-black animate-slide-up flex flex-col md:flex-row gap-8 items-center ${feedback.activated ? 'bg-emerald-50' : 'bg-rose-50'}`}>
                            <div className="flex-1">
                                <div className="flex items-center gap-3 mb-3">
                                    <div className={`p-2 rounded-xl border-2 border-black ${feedback.activated ? 'bg-emerald-400' : 'bg-rose-400'}`}>
                                        {feedback.activated ? <Sparkles className="w-5 h-5 text-black" /> : <X className="w-5 h-5 text-white" />}
                                    </div>
                                    <span className="text-xl font-black uppercase tracking-tighter">
                                        {feedback.activated ? 'Activation Successful' : 'Neural Mismatch'}
                                    </span>
                                    <span className={`bg-white px-3 py-1 rounded-full border-2 border-black font-black text-sm ${feedback.score >= 80 ? 'text-emerald-600' : 'text-rose-600'}`}>{feedback.score}%</span>
                                </div>
                                <p className="text-slate-700 font-bold leading-snug">{feedback.analysis}</p>
                                
                                {feedback.improvement && (
                                    <div className={`mt-4 p-4 rounded-2xl border-2 bg-white/60 ${isHardMode ? 'border-rose-200' : 'border-black/10'}`}>
                                        <span className={`text-[10px] font-black uppercase block mb-1 ${isHardMode ? 'text-rose-400' : 'text-indigo-400'}`}>Band 9.0 Optimized Path</span>
                                        <p className="text-slate-900 font-bold italic">"{feedback.improvement}"</p>
                                    </div>
                                )}
                            </div>
                            <button 
                                onClick={handleNext}
                                className="bg-black text-white px-10 py-6 rounded-[2.5rem] font-black uppercase tracking-widest text-xl hover:bg-slate-800 transition-all shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 active:translate-y-0"
                            >
                                {index < questions.length - 1 ? 'Next Phase' : 'Final Report'} <ArrowRight className="inline-block ml-2 w-6 h-6" />
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>

        {/* Dynamic Synapse Pulse (Stylistic Scaling) */}
        <div className="fixed bottom-0 left-0 w-full h-1 bg-slate-900 overflow-hidden pointer-events-none opacity-20">
             <div className={`h-full animate-[synapse_3s_infinite] ${isHardMode ? 'bg-rose-500' : 'bg-indigo-500'}`} style={{width: isHardMode ? '40%' : '20%', animationDuration: isHardMode ? '1s' : '3s'}}></div>
        </div>

        <style>{`
            @keyframes synapse {
                0% { transform: translateX(-100%); }
                100% { transform: translateX(500%); }
            }
        `}</style>
    </div>
  );
};

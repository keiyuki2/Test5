
import React, { useState, useEffect, useRef } from 'react';
import { ReadingPassage, ReadingQuestion, VocabQuestion, FreeRecallResult } from '../types';
import { generateVocabCard, evaluateFreeRecall } from '../services/geminiService';
import { Play, Pause, RotateCcw, Zap, Eye, CheckCircle, Clock, BookOpen, ArrowRight, Settings, Loader2, X, Bookmark, BookmarkCheck, PenTool, Check, AlertCircle } from 'lucide-react';

interface ReadingGameScreenProps {
  passage: ReadingPassage;
  onComplete: () => void;
}

type SubMode = 'SELECT' | 'COMPREHENSION' | 'SPEED_STATIC' | 'SPEED_FLASH' | 'FREE_RECALL';

export const ReadingGameScreen: React.FC<ReadingGameScreenProps> = ({ passage, onComplete }) => {
  const [subMode, setSubMode] = useState<SubMode>('SELECT');
  
  // Existing Comprehension State
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);

  // Vocabulary Inspection
  const [inspectedWord, setInspectedWord] = useState<{
    word: string;
    data: VocabQuestion | null;
    loading: boolean;
    error: boolean;
  } | null>(null);

  // Speed Reading State
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [startTime, setStartTime] = useState(0);
  const [endTime, setEndTime] = useState(0);
  const [wpm, setWpm] = useState(0);
  const [targetWpm, setTargetWpm] = useState(300);
  const [flashIndex, setFlashIndex] = useState(0);
  const [isFlashing, setIsFlashing] = useState(false);
  const [words, setWords] = useState<string[]>([]);

  // FREE RECALL STATE
  const [recallText, setRecallText] = useState('');
  const [recallPhase, setRecallPhase] = useState<'READING' | 'WRITING' | 'RESULT'>('READING');
  const [recallResult, setRecallResult] = useState<FreeRecallResult | null>(null);
  const [isEvaluatingRecall, setIsEvaluatingRecall] = useState(false);

  useEffect(() => {
    if (passage) {
        setWords(passage.text.split(/\s+/));
    }
  }, [passage]);

  // Flash Effect Hook
  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (isFlashing && flashIndex < words.length) {
        const delay = 60000 / targetWpm;
        interval = setInterval(() => {
            setFlashIndex(prev => {
                if (prev >= words.length - 1) {
                    setIsFlashing(false);
                    return prev;
                }
                return prev + 1;
            });
        }, delay);
    }
    return () => clearInterval(interval);
  }, [isFlashing, targetWpm, words.length, flashIndex]);

  const handleStartStatic = () => {
      setStartTime(Date.now());
      setIsTimerRunning(true);
      setEndTime(0);
      setWpm(0);
  };

  const handleStopStatic = () => {
      const end = Date.now();
      setEndTime(end);
      setIsTimerRunning(false);
      
      const minutes = (end - startTime) / 60000;
      const wordCount = passage.text.split(/\s+/).length;
      if (minutes > 0) {
          setWpm(Math.round(wordCount / minutes));
      }
  };

  const handleAnswerSelect = (qId: string, option: string) => {
      if (showResults) return;
      setAnswers(prev => ({ ...prev, [qId]: option }));
  };

  const checkAnswers = () => {
      let correct = 0;
      passage.questions.forEach(q => {
          if (answers[q.id] === q.correctAnswer) correct++;
      });
      setScore(correct);
      setShowResults(true);
  };

  const handleWordClick = async (word: string) => {
    const cleanWord = word.replace(/[.,/#!$%^&*;:{}=\-_`~()]/g,"");
    if (!cleanWord || cleanWord.length < 2) return;
    setInspectedWord({ word: cleanWord, data: null, loading: true, error: false });
    const sentences = passage.text.match(/[^.!?]+[.!?]+/g) || [passage.text];
    const contextSentence = sentences.find(s => s.includes(word)) || passage.text.substring(0, 100);
    try {
        const cardData = await generateVocabCard(cleanWord, contextSentence);
        setInspectedWord({ word: cleanWord, data: cardData, loading: false, error: false });
    } catch (e) {
        setInspectedWord({ word: cleanWord, data: null, loading: false, error: true });
    }
  };

  const submitFreeRecall = async () => {
      if (!recallText.trim()) return;
      setIsEvaluatingRecall(true);
      try {
          const res = await evaluateFreeRecall(passage.text, recallText);
          setRecallResult(res);
          setRecallPhase('RESULT');
      } catch (e) {
          console.error(e);
      } finally {
          setIsEvaluatingRecall(false);
      }
  };

  const resetAll = () => {
      setSubMode('SELECT');
      setAnswers({});
      setShowResults(false);
      setIsTimerRunning(false);
      setStartTime(0);
      setEndTime(0);
      setFlashIndex(0);
      setIsFlashing(false);
      setInspectedWord(null);
      setRecallText('');
      setRecallPhase('READING');
      setRecallResult(null);
  };

  const renderClickableText = () => {
      const parts = passage.text.split(/(\s+)/);
      return parts.map((part, index) => {
          if (part.trim().length === 0) return <span key={index}>{part}</span>;
          
          return (
              <span 
                key={index}
                onClick={() => handleWordClick(part)}
                className={`
                    cursor-pointer rounded-sm px-0.5 transition-colors border-b-2 border-transparent
                    ${inspectedWord?.word === part.replace(/[.,/#!$%^&*;:{}=\-_`~()]/g,"") 
                        ? 'bg-yellow-300 text-black border-black font-bold' 
                        : 'hover:bg-indigo-100 hover:text-indigo-900 hover:border-indigo-300'
                    }
                `}
              >
                  {part}
              </span>
          );
      });
  };

  if (subMode === 'SELECT') {
      return (
          <div className="w-full max-w-6xl mx-auto animate-slide-up py-12 px-6">
              <div className="text-center mb-16">
                  <h2 className="text-4xl md:text-5xl font-black text-slate-900 mb-4 uppercase tracking-tighter italic">{passage.title}</h2>
                  <div className="inline-block bg-black text-white px-4 py-1 font-bold uppercase tracking-widest text-sm transform rotate-2">Select Reading Mode</div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <button onClick={() => setSubMode('COMPREHENSION')} className="group bg-indigo-500 p-8 rounded-[2.5rem] border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-2 hover:shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] transition-all text-left relative overflow-hidden h-64 flex flex-col justify-between">
                      <BookOpen className="w-24 h-24 absolute -right-4 -bottom-4 text-indigo-700 opacity-50 rotate-12" />
                      <div className="w-12 h-12 bg-white border-2 border-black rounded-xl flex items-center justify-center text-black shadow-md">
                          <BookOpen className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-xl font-black text-white uppercase mb-1">Comprehension</h3>
                        <p className="text-indigo-200 text-xs font-bold">Standard Q&A</p>
                      </div>
                  </button>

                  <button onClick={() => setSubMode('SPEED_STATIC')} className="group bg-emerald-500 p-8 rounded-[2.5rem] border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-2 hover:shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] transition-all text-left relative overflow-hidden h-64 flex flex-col justify-between">
                      <Clock className="w-24 h-24 absolute -right-4 -bottom-4 text-emerald-700 opacity-50 rotate-12" />
                      <div className="w-12 h-12 bg-white border-2 border-black rounded-xl flex items-center justify-center text-black shadow-md">
                          <Clock className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-xl font-black text-white uppercase mb-1">Speed Test</h3>
                        <p className="text-emerald-200 text-xs font-bold">Measure WPM</p>
                      </div>
                  </button>

                  <button onClick={() => setSubMode('SPEED_FLASH')} className="group bg-amber-400 p-8 rounded-[2.5rem] border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-2 hover:shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] transition-all text-left relative overflow-hidden h-64 flex flex-col justify-between">
                      <Zap className="w-24 h-24 absolute -right-4 -bottom-4 text-amber-600 opacity-50 rotate-12" />
                      <div className="w-12 h-12 bg-white border-2 border-black rounded-xl flex items-center justify-center text-black shadow-md">
                          <Zap className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-xl font-black text-black uppercase mb-1">Rapid Flash</h3>
                        <p className="text-amber-800 text-xs font-bold">RSVP Training</p>
                      </div>
                  </button>

                  <button onClick={() => setSubMode('FREE_RECALL')} className="group bg-rose-500 p-8 rounded-[2.5rem] border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-2 hover:shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] transition-all text-left relative overflow-hidden h-64 flex flex-col justify-between">
                      <PenTool className="w-24 h-24 absolute -right-4 -bottom-4 text-rose-700 opacity-50 rotate-12" />
                      <div className="w-12 h-12 bg-white border-2 border-black rounded-xl flex items-center justify-center text-black shadow-md">
                          <PenTool className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-xl font-black text-white uppercase mb-1">Free Recall</h3>
                        <p className="text-rose-200 text-xs font-bold">Memory Retention</p>
                      </div>
                  </button>
              </div>
          </div>
      );
  }

  // --- FREE RECALL MODE ---
  if (subMode === 'FREE_RECALL') {
      return (
          <div className="w-full max-w-4xl mx-auto py-8 md:py-12 px-6 animate-slide-up flex flex-col h-full min-h-[calc(100vh-140px)]">
              <button onClick={resetAll} className="mb-6 text-xs font-black uppercase tracking-widest text-slate-500 hover:text-black self-start">← Back</button>
              
              {/* Phase Header */}
              <div className="flex justify-between items-end mb-8 border-b-4 border-black pb-4">
                  <div>
                      <h2 className="text-3xl md:text-4xl font-black text-slate-900 uppercase tracking-tighter">Free Recall Protocol</h2>
                      <p className="text-slate-500 font-bold mt-1">
                          {recallPhase === 'READING' ? "Step 1: Read carefully." : recallPhase === 'WRITING' ? "Step 2: Type everything you remember." : "Step 3: Evaluation"}
                      </p>
                  </div>
                  <div className={`px-4 py-1 rounded-full border-2 border-black text-xs font-black uppercase tracking-widest ${recallPhase === 'READING' ? 'bg-indigo-400 text-white' : recallPhase === 'WRITING' ? 'bg-rose-400 text-white' : 'bg-emerald-400 text-black'}`}>
                      {recallPhase}
                  </div>
              </div>

              {recallPhase === 'READING' && (
                  <div className="bg-white rounded-[2rem] p-8 md:p-12 border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] relative animate-scale-in">
                      <p className="whitespace-pre-wrap text-lg font-medium leading-loose text-slate-800 font-serif">
                          {passage.text}
                      </p>
                      <div className="mt-8 flex justify-end">
                          <button 
                            onClick={() => setRecallPhase('WRITING')}
                            className="bg-black text-white px-8 py-4 rounded-xl font-black uppercase tracking-widest hover:bg-rose-600 transition-all shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)] border-2 border-transparent hover:border-black hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 active:translate-y-0 active:shadow-none flex items-center gap-2"
                          >
                              Hide & Recall <ArrowRight className="w-5 h-5" />
                          </button>
                      </div>
                  </div>
              )}

              {recallPhase === 'WRITING' && (
                  <div className="flex-1 flex flex-col bg-slate-100 rounded-[2rem] p-8 border-4 border-black shadow-inner animate-slide-up">
                      <textarea 
                          value={recallText}
                          onChange={(e) => setRecallText(e.target.value)}
                          placeholder="Start typing everything you remember from the text..."
                          className="flex-1 bg-transparent border-none outline-none resize-none text-xl font-medium text-slate-900 placeholder:text-slate-400 leading-relaxed"
                          autoFocus
                      />
                      <div className="mt-4 flex justify-between items-center pt-4 border-t-2 border-slate-300">
                          <div className="text-xs font-bold text-slate-500 uppercase tracking-widest">{recallText.split(/\s+/).filter(w => w).length} Words</div>
                          <button 
                            onClick={submitFreeRecall}
                            disabled={isEvaluatingRecall || !recallText.trim()}
                            className="bg-black text-white px-8 py-3 rounded-xl font-black uppercase tracking-widest hover:bg-emerald-600 transition-all shadow-md disabled:opacity-50 flex items-center gap-2"
                          >
                              {isEvaluatingRecall ? <Loader2 className="animate-spin w-4 h-4" /> : <Check className="w-4 h-4" />} Submit
                          </button>
                      </div>
                  </div>
              )}

              {recallPhase === 'RESULT' && recallResult && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-scale-in">
                      {/* Score Card */}
                      <div className="bg-slate-900 text-white rounded-[2rem] p-8 border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] text-center flex flex-col items-center justify-center">
                          <div className={`text-8xl font-black mb-2 ${recallResult.score > 70 ? 'text-emerald-400' : 'text-amber-400'}`}>
                              {recallResult.score}%
                          </div>
                          <p className="text-slate-400 font-bold uppercase tracking-widest text-sm">Retention Score</p>
                      </div>

                      {/* Feedback Card */}
                      <div className="bg-white rounded-[2rem] p-8 border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
                          <h3 className="text-lg font-black uppercase mb-4 flex items-center gap-2">
                              <CheckCircle className="w-6 h-6 text-emerald-500" /> Feedback
                          </h3>
                          <p className="text-slate-700 font-medium leading-relaxed mb-6">
                              "{recallResult.feedback}"
                          </p>
                          
                          {recallResult.missedPoints.length > 0 && (
                              <div className="bg-rose-50 border-2 border-rose-100 rounded-xl p-4">
                                  <h4 className="text-xs font-black text-rose-500 uppercase tracking-widest mb-3 flex items-center gap-2">
                                      <AlertCircle className="w-4 h-4" /> Missed Details
                                  </h4>
                                  <ul className="space-y-2">
                                      {recallResult.missedPoints.map((pt, i) => (
                                          <li key={i} className="text-sm font-bold text-rose-900 flex gap-2">
                                              <span>•</span> {pt}
                                          </li>
                                      ))}
                                  </ul>
                              </div>
                          )}
                      </div>

                      <button 
                        onClick={resetAll}
                        className="col-span-1 md:col-span-2 py-4 bg-indigo-600 text-white rounded-xl font-black uppercase tracking-wider hover:bg-indigo-500 border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 active:translate-y-0 active:shadow-none transition-all"
                      >
                          Try Another Text
                      </button>
                  </div>
              )}
          </div>
      );
  }

  // COMPREHENSION MODE (Side by Side)
  if (subMode === 'COMPREHENSION') {
      return (
          <div className="w-full max-w-[1920px] mx-auto min-h-[calc(100vh-140px)] md:h-[calc(100vh-140px)] animate-fade-in flex flex-col md:flex-row gap-8 px-2 md:px-6 pt-24 pb-8">
              {/* Left: Passage */}
              <div className="w-full md:w-1/2 bg-white rounded-[2rem] border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] md:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] overflow-hidden relative flex flex-col min-h-[500px] md:min-h-0">
                  <div className="flex items-center gap-4 p-4 md:p-6 border-b-4 border-black bg-slate-50 z-20">
                      <button onClick={resetAll} className="text-[10px] md:text-xs font-black uppercase tracking-widest text-slate-500 hover:text-black">← Back</button>
                      <h2 className="text-sm md:text-lg font-black text-slate-900 line-clamp-1 uppercase">{passage.title}</h2>
                      <div className="ml-auto flex items-center gap-2 text-[10px] font-bold text-white bg-black px-3 py-1 rounded-full uppercase">
                          <Eye className="w-3 h-3" />
                          <span className="hidden sm:inline">Interactive</span>
                      </div>
                  </div>
                  
                  <div className="flex-1 overflow-y-auto p-6 md:p-10 font-medium text-base md:text-lg leading-loose text-slate-800 relative bg-white">
                      <p className="whitespace-pre-wrap pb-32">{renderClickableText()}</p>
                  </div>

                  {/* Definition Panel */}
                  <div className={`
                    absolute bottom-0 left-0 w-full bg-slate-900 text-white border-t-4 border-black transition-transform duration-300 z-30
                    ${inspectedWord ? 'translate-y-0' : 'translate-y-full'}
                  `}>
                      {inspectedWord && (
                          <div className="p-6 md:px-8 flex flex-col md:flex-row gap-6 items-start md:items-center relative">
                                <button 
                                    onClick={() => setInspectedWord(null)} 
                                    className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white"
                                >
                                    <X className="w-6 h-6" />
                                </button>

                                <div className="flex-1">
                                    <h4 className="text-2xl font-black capitalize flex items-center gap-3">
                                        {inspectedWord.word}
                                        {inspectedWord.data && (
                                            <span className="text-[10px] bg-emerald-400 text-black px-2 py-0.5 rounded font-bold uppercase tracking-wide">
                                                Band {inspectedWord.data.band}
                                            </span>
                                        )}
                                    </h4>
                                    
                                    {inspectedWord.loading ? (
                                        <div className="flex items-center gap-2 mt-2 text-slate-400 text-sm font-bold">
                                            <Loader2 className="w-4 h-4 animate-spin" /> Fetching...
                                        </div>
                                    ) : inspectedWord.error ? (
                                        <p className="text-rose-400 text-sm mt-1 font-bold">Definition not found.</p>
                                    ) : (
                                        <p className="text-slate-200 font-medium mt-1 leading-snug text-lg">
                                            {inspectedWord.data?.definition}
                                        </p>
                                    )}
                                </div>
                          </div>
                      )}
                  </div>
              </div>

              {/* Right: Questions */}
              <div className="w-full md:w-1/2 bg-indigo-50 rounded-[2rem] border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] md:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] p-6 md:p-8 overflow-y-auto h-full flex flex-col min-h-[500px] md:min-h-0">
                  <div className="mb-6 flex justify-between items-center">
                    <h3 className="text-xs md:text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 md:w-5 md:h-5" /> Questions
                    </h3>
                    {showResults && (
                        <span className="bg-black text-white font-black px-4 py-2 rounded-lg text-sm border-2 border-transparent shadow-[4px_4px_0px_0px_rgba(255,255,255,0.5)]">
                            Score: {score}/{passage.questions.length}
                        </span>
                    )}
                  </div>
                  
                  <div className="space-y-6 flex-1">
                      {passage.questions.map((q, idx) => (
                          <div key={q.id} className="bg-white rounded-xl p-4 md:p-6 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                              <p className="font-bold text-slate-900 mb-4 flex gap-3 text-base md:text-lg">
                                  <span className="bg-black text-white w-6 h-6 md:w-8 md:h-8 rounded-full flex items-center justify-center text-xs md:text-sm flex-none">{idx + 1}</span> {q.text}
                              </p>
                              <div className="space-y-2 pl-9 md:pl-11">
                                  {q.options.map(opt => {
                                      let btnClass = "w-full text-left p-3 rounded-lg border-2 text-xs md:text-sm font-bold transition-all ";
                                      const isSelected = answers[q.id] === opt;
                                      
                                      if (showResults) {
                                          if (opt === q.correctAnswer) {
                                              btnClass += "bg-emerald-400 border-black text-black";
                                          } else if (isSelected && opt !== q.correctAnswer) {
                                              btnClass += "bg-rose-400 border-black text-black";
                                          } else {
                                              btnClass += "bg-slate-100 border-slate-200 text-slate-400";
                                          }
                                      } else {
                                          if (isSelected) {
                                              btnClass += "bg-indigo-600 border-black text-white shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]";
                                          } else {
                                              btnClass += "bg-white border-slate-300 text-slate-600 hover:border-black hover:bg-indigo-50 hover:text-black";
                                          }
                                      }

                                      return (
                                          <button 
                                            key={opt} 
                                            onClick={() => handleAnswerSelect(q.id, opt)}
                                            disabled={showResults}
                                            className={btnClass}
                                          >
                                              {opt}
                                          </button>
                                      );
                                  })}
                              </div>
                          </div>
                      ))}
                  </div>

                  {!showResults ? (
                      <button 
                        onClick={checkAnswers} 
                        disabled={Object.keys(answers).length < passage.questions.length}
                        className="w-full mt-8 py-4 bg-black hover:bg-slate-800 text-white rounded-xl font-black uppercase tracking-wider shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)] border-2 border-transparent hover:border-black hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                          Submit Answers
                      </button>
                  ) : (
                      <button 
                        onClick={onComplete} 
                        className="w-full mt-8 py-4 bg-emerald-500 hover:bg-emerald-600 text-black rounded-xl font-black uppercase tracking-wider shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] border-2 border-black hover:-translate-y-1 hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all"
                      >
                          Finish Reading
                      </button>
                  )}
              </div>
          </div>
      );
  }

  // SPEED TEST (STATIC)
  if (subMode === 'SPEED_STATIC') {
      return (
          <div className="w-full max-w-4xl mx-auto py-12 px-6 animate-slide-up">
               <button onClick={resetAll} className="mb-8 text-xs font-black uppercase tracking-widest text-slate-500 hover:text-black">← Back</button>
               
               <div className="bg-white rounded-[2rem] p-10 border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] relative min-h-[600px] flex flex-col overflow-hidden">
                   
                   {/* Results Overlay */}
                   {endTime > 0 && (
                       <div className="absolute inset-0 z-50 bg-white/95 flex flex-col items-center justify-center animate-fade-in p-8 text-center">
                           <div className="w-24 h-24 bg-emerald-400 rounded-full flex items-center justify-center mb-6 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                               <Clock className="w-12 h-12 text-black" />
                           </div>
                           <h2 className="text-5xl font-black text-slate-900 mb-2 uppercase tracking-tighter">Reading Complete</h2>
                           <p className="text-slate-500 font-bold mb-8">Time: {Math.round((endTime - startTime) / 1000)}s</p>
                           
                           <div className="bg-black p-8 rounded-3xl border-4 border-black mb-10 w-full max-w-sm shadow-[8px_8px_0px_0px_#22c55e]">
                               <div className="text-xs font-black uppercase tracking-widest text-emerald-400 mb-2">Reading Speed</div>
                               <div className="text-7xl font-black text-white">{wpm} <span className="text-2xl text-slate-400 font-bold">WPM</span></div>
                           </div>
                           
                           <div className="flex gap-4">
                               <button 
                                 onClick={handleStartStatic}
                                 className="px-8 py-4 rounded-xl bg-white border-2 border-black text-black font-black hover:bg-slate-100 transition-colors flex items-center gap-2 uppercase tracking-wide"
                               >
                                   <RotateCcw className="w-4 h-4" /> Retry
                               </button>
                               <button 
                                 onClick={resetAll}
                                 className="px-10 py-4 rounded-xl bg-indigo-600 text-white font-black border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all flex items-center gap-2 uppercase tracking-wide"
                               >
                                   Done <CheckCircle className="w-5 h-5" />
                               </button>
                           </div>
                       </div>
                   )}

                   <div className="flex justify-between items-center mb-8 border-b-4 border-black pb-4">
                       <h2 className="text-3xl font-black text-slate-900 uppercase italic">{passage.title}</h2>
                       <div className="flex items-center gap-4">
                           {isTimerRunning && (
                               <span className="animate-pulse text-rose-500 flex items-center gap-2 font-mono font-bold uppercase border-2 border-rose-500 px-3 py-1 rounded bg-rose-50">
                                   <div className="w-2 h-2 rounded-full bg-rose-500"></div> Recording...
                               </span>
                           )}
                       </div>
                   </div>

                   <div className={`flex-1 relative ${!isTimerRunning && endTime === 0 ? 'filter blur-md select-none opacity-50' : ''}`}>
                       <p className="font-medium text-xl leading-loose text-slate-900 whitespace-pre-wrap font-serif">
                           {passage.text}
                       </p>
                   </div>
                   
                   {!isTimerRunning && endTime === 0 && (
                       <div className="absolute inset-0 flex items-center justify-center z-10">
                           <button 
                             onClick={handleStartStatic}
                             className="bg-emerald-500 text-white px-12 py-6 rounded-2xl font-black text-2xl border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] hover:scale-105 hover:shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] transition-all flex items-center gap-4 uppercase tracking-tighter"
                           >
                               <Play className="w-8 h-8 fill-current" /> Start Reading
                           </button>
                       </div>
                   )}

                   {isTimerRunning && (
                        <div className="sticky bottom-0 flex justify-center mt-8 pt-4">
                            <button 
                                onClick={handleStopStatic}
                                className="bg-rose-500 text-white px-10 py-4 rounded-xl font-black border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all uppercase tracking-wider"
                            >
                                Stop Timer
                            </button>
                        </div>
                   )}
               </div>
          </div>
      );
  }

  // RSVP FLASH MODE
  if (subMode === 'SPEED_FLASH') {
      return (
          <div className="w-full max-w-4xl mx-auto py-12 px-6 animate-slide-up flex flex-col items-center h-[calc(100vh-100px)] justify-center">
               <button onClick={resetAll} className="self-start mb-8 text-xs font-black uppercase tracking-widest text-slate-500 hover:text-black">← Back</button>

               <div className="w-full max-w-3xl">
                   <div className="bg-white rounded-[3rem] shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] border-4 border-black aspect-[16/9] flex items-center justify-center relative overflow-hidden mb-12">
                       <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-200"></div>
                       <div className="absolute top-0 left-1/2 h-full w-0.5 bg-slate-200"></div>
                       
                       <div className="relative z-10 w-full px-4 text-center">
                           <div className="text-6xl md:text-8xl font-black text-black font-sans tracking-tight break-words leading-none">
                               {words[flashIndex]}
                           </div>
                       </div>
                       
                       <div className="absolute bottom-8 right-10 text-sm font-mono font-bold text-slate-400">
                           {flashIndex + 1} / {words.length}
                       </div>
                   </div>

                   {/* Controls */}
                   <div className="bg-slate-100 rounded-3xl p-8 border-4 border-black flex flex-col gap-8">
                       <div className="flex items-center justify-between">
                           <div className="flex items-center gap-6">
                               <button 
                                 onClick={() => setIsFlashing(!isFlashing)}
                                 className={`w-16 h-16 rounded-2xl border-4 border-black flex items-center justify-center shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 active:translate-y-0 active:shadow-none transition-all ${isFlashing ? 'bg-amber-400 text-black' : 'bg-indigo-600 text-white'}`}
                               >
                                   {isFlashing ? <Pause className="w-8 h-8 fill-current" /> : <Play className="w-8 h-8 fill-current ml-1" />}
                               </button>
                               <button 
                                 onClick={() => { setIsFlashing(false); setFlashIndex(0); }}
                                 className="w-12 h-12 rounded-xl bg-white border-2 border-black text-slate-700 hover:bg-rose-100 flex items-center justify-center transition-colors shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-y-0.5 active:shadow-none"
                               >
                                   <RotateCcw className="w-5 h-5" />
                               </button>
                           </div>

                           <div className="flex flex-col items-end">
                               <span className="text-5xl font-black text-indigo-600 font-mono tracking-tighter">{targetWpm}</span>
                               <span className="text-xs uppercase font-black text-slate-500 tracking-widest">Words Per Minute</span>
                           </div>
                       </div>

                       <div>
                           <input 
                             type="range" 
                             min="100" 
                             max="1000" 
                             step="50" 
                             value={targetWpm}
                             onChange={(e) => setTargetWpm(Number(e.target.value))}
                             className="w-full h-4 bg-white rounded-full appearance-none cursor-pointer border-2 border-black"
                             style={{accentColor: 'black'}}
                           />
                           <div className="flex justify-between text-xs text-slate-500 mt-2 font-bold font-mono">
                               <span>100</span>
                               <span>500</span>
                               <span>1000</span>
                           </div>
                       </div>
                   </div>
               </div>
          </div>
      );
  }

  return null;
};

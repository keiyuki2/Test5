/**
 * Vocabulary Notebook — saved words with spaced repetition review
 * Accessible from sidebar. Stored in localStorage.
 */
import React, { useState, useEffect } from 'react';
import { X, BookOpen, Search, Trash2, Star, RefreshCw, ChevronRight, Plus } from 'lucide-react';
import { sfx } from '../services/soundService';
import { motion, AnimatePresence } from 'framer-motion';

interface SavedWord {
  id: string; word: string; definition: string;
  band: string; addedAt: number; reviewCount: number; nextReview: number;
}

interface Props { onClose: () => void }

const STORAGE_KEY = 'ielts_vocab_notebook';

function load(): SavedWord[] {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'); } catch { return []; }
}
function persist(words: SavedWord[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(words));
}

export const VocabNotebook: React.FC<Props> = ({ onClose }) => {
  const [words, setWords] = useState<SavedWord[]>(load);
  const [q, setQ] = useState('');
  const [reviewing, setReviewing] = useState<SavedWord | null>(null);
  const [showDef, setShowDef] = useState(false);
  const [tab, setTab] = useState<'all' | 'due'>('all');

  const now = Date.now();
  const due = words.filter(w => w.nextReview <= now);
  const filtered = (tab === 'due' ? due : words).filter(w =>
    !q || w.word.toLowerCase().includes(q.toLowerCase())
  );

  const remove = (id: string) => {
    const updated = words.filter(w => w.id !== id);
    setWords(updated); persist(updated); sfx.back();
  };

  const markReview = (correct: boolean) => {
    if (!reviewing) return;
    const interval = correct
      ? Math.min((reviewing.reviewCount + 1) * 86400000 * 2, 86400000 * 30)
      : 86400000;
    const updated = words.map(w => w.id === reviewing.id
      ? { ...w, reviewCount: w.reviewCount + 1, nextReview: now + interval }
      : w
    );
    setWords(updated); persist(updated);
    sfx[correct ? 'correct' : 'wrong']();
    setReviewing(null); setShowDef(false);
  };

  const startReview = () => {
    if (due.length === 0) return;
    setReviewing(due[Math.floor(Math.random() * due.length)]);
    setShowDef(false);
    sfx.navigate();
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-50 flex flex-col" style={{ fontFamily:"'Inter',sans-serif" }}>
      {/* Header */}
      <div className="bg-white border-b-4 border-black px-5 py-4 flex items-center justify-between shadow-[0_4px_0px_0px_rgba(0,0,0,1)] shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-fuchsia-400 border-4 border-black rounded-xl flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
            <BookOpen className="w-4 h-4 text-black" />
          </div>
          <div>
            <h1 className="font-black text-stone-900 text-base uppercase tracking-tight leading-none">Vocab Notebook</h1>
            <p className="text-stone-400 text-[10px] font-medium">{words.length} words · {due.length} due for review</p>
          </div>
        </div>
        <button onClick={() => { sfx.back(); onClose(); }}
          className="w-9 h-9 bg-stone-100 hover:bg-stone-200 border-2 border-stone-200 hover:border-stone-400 rounded-xl flex items-center justify-center text-stone-500 hover:text-stone-900 transition-all">
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Review modal */}
      <AnimatePresence>
        {reviewing && (
          <motion.div className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
            initial={{ opacity:0 }} animate={{ opacity:1 }} exit={{ opacity:0 }}>
            <motion.div className="bg-white border-4 border-black rounded-3xl p-8 max-w-sm w-full shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] text-center"
              initial={{ scale:0.9 }} animate={{ scale:1 }} exit={{ scale:0.9 }}>
              <p className="text-[10px] font-black uppercase tracking-widest text-stone-400 mb-2">Define this word</p>
              <h2 className="text-4xl font-black text-stone-900 uppercase tracking-tighter mb-6">{reviewing.word}</h2>
              {!showDef ? (
                <button onClick={() => setShowDef(true)}
                  className="w-full py-3.5 bg-stone-900 text-white border-4 border-black rounded-xl font-black text-sm uppercase tracking-widest shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 transition-all">
                  Show Definition
                </button>
              ) : (
                <>
                  <div className="bg-stone-50 border-4 border-stone-200 rounded-2xl p-4 mb-6 text-left">
                    <p className="text-sm text-stone-700 font-medium leading-relaxed">{reviewing.definition}</p>
                  </div>
                  <div className="flex gap-3">
                    <button onClick={() => markReview(false)}
                      className="flex-1 py-3 bg-rose-500 text-white border-4 border-black rounded-xl font-black text-xs uppercase tracking-widest shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 transition-all">
                      Forgot
                    </button>
                    <button onClick={() => markReview(true)}
                      className="flex-1 py-3 bg-lime-400 text-black border-4 border-black rounded-xl font-black text-xs uppercase tracking-widest shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 transition-all">
                      Got it!
                    </button>
                  </div>
                </>
              )}
              <button onClick={() => { setReviewing(null); setShowDef(false); }} className="mt-4 text-xs text-stone-400 hover:text-stone-700 font-bold transition-colors">
                Skip
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex-1 overflow-y-auto">
        {/* Search + filter */}
        <div className="bg-white border-b border-stone-100 px-5 py-3 space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
            <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search words..."
              className="w-full bg-stone-50 border-4 border-stone-200 rounded-xl pl-9 pr-4 py-2 text-sm font-medium focus:outline-none focus:border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,0.2)] transition-all" />
          </div>
          <div className="flex items-center justify-between">
            <div className="flex gap-1 bg-stone-100 border-2 border-stone-200 rounded-xl p-1">
              {(['all','due'] as const).map(t => (
                <button key={t} onClick={() => setTab(t)}
                  className={`px-3 py-1 rounded-lg text-xs font-black uppercase tracking-widest transition-all ${tab===t ? 'bg-white border-2 border-stone-200 shadow-sm text-stone-900' : 'text-stone-500'}`}>
                  {t === 'all' ? `All (${words.length})` : `Due (${due.length})`}
                </button>
              ))}
            </div>
            {due.length > 0 && (
              <button onClick={startReview}
                className="flex items-center gap-2 px-4 py-2 bg-fuchsia-400 text-black border-4 border-black rounded-xl font-black text-xs uppercase tracking-widest shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-all">
                <RefreshCw className="w-3.5 h-3.5" /> Review {due.length}
              </button>
            )}
          </div>
        </div>

        <div className="px-5 py-4 space-y-2.5">
          {filtered.length === 0 && (
            <div className="text-center py-16 flex flex-col items-center gap-3 opacity-50">
              <BookOpen className="w-10 h-10 text-stone-300" />
              <p className="font-black text-sm uppercase tracking-widest text-stone-400">
                {words.length === 0 ? 'No words saved yet' : 'No words match your search'}
              </p>
              {words.length === 0 && <p className="text-xs text-stone-400">Use the Dictionary or play Vocabulary games to save words</p>}
            </div>
          )}
          {filtered.map(w => (
            <div key={w.id}
              className="bg-white border-4 border-stone-200 rounded-2xl p-4 flex items-center gap-4 hover:border-black hover:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all group">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 bg-fuchsia-100 border-2 border-fuchsia-200 rounded-xl flex items-center justify-center">
                  <Star className="w-4 h-4 text-fuchsia-600" />
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <p className="font-black text-stone-900 text-sm capitalize">{w.word}</p>
                  <span className="px-1.5 py-0.5 bg-lime-100 border border-lime-300 rounded text-[9px] font-black text-lime-700 uppercase tracking-widest">B{w.band}</span>
                  {w.nextReview <= now && (
                    <span className="px-1.5 py-0.5 bg-amber-100 border border-amber-300 rounded text-[9px] font-black text-amber-700 uppercase tracking-widest">Due</span>
                  )}
                </div>
                <p className="text-xs text-stone-400 font-medium truncate">{w.definition}</p>
              </div>
              <button onClick={() => remove(w.id)}
                className="opacity-0 group-hover:opacity-100 w-8 h-8 bg-rose-50 border-2 border-rose-200 rounded-lg flex items-center justify-center text-rose-400 hover:text-rose-600 hover:border-rose-400 transition-all">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

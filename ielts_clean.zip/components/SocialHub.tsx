import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X, Users, Trophy, Search, Flame, Check, Globe, School,
  Copy, Zap, UserPlus, Crown, Swords, Star, Activity,
  ChevronRight, MessageCircle, BookOpen
} from 'lucide-react';
import { UserProfile } from '../types';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { sfx } from '../services/soundService';
import { Toggle } from './ui/toggle';

interface SocialHubProps { userProfile: UserProfile; onClose: () => void; }

type UserTitle = 'owner' | 'manager' | 'verified' | 'student';
interface Friend {
  id: string; name: string; level: string; avatar: string;
  streak: number; online: boolean; xp: number; title?: UserTitle;
  recentActivity?: string; bestBand?: string; totalSessions?: number;
  badges?: string[];
}

const FRIENDS: Friend[] = [
  { id:'1', name:'Enkhjin B.', level:'Band 6.5–7.5', avatar:'https://api.dicebear.com/7.x/initials/svg?seed=Enkh&backgroundColor=22d3ee&fontFamily=Arial&fontSize=40',
    streak:12, online:true,  xp:820,  title:'verified', recentActivity:'Completed Writing Task 2', bestBand:'7.0', totalSessions:48, badges:['Speed Run','7-Day'] },
  { id:'2', name:'Tsolmon G.', level:'Band 4.5–6.0', avatar:'https://api.dicebear.com/7.x/initials/svg?seed=Tsol&backgroundColor=f43f5e&fontFamily=Arial&fontSize=40',
    streak:5,  online:true,  xp:610,  recentActivity:'Played Vocabulary drill', bestBand:'5.5', totalSessions:22, badges:['First Login'] },
  { id:'3', name:'Bataa N.',   level:'Band 8.0–9.0', avatar:'https://api.dicebear.com/7.x/initials/svg?seed=Bata&backgroundColor=4ade80&fontFamily=Arial&fontSize=40',
    streak:30, online:false, xp:980,  title:'student', recentActivity:'Mock exam: Band 8.5', bestBand:'8.5', totalSessions:94, badges:['Band 7+','30-Day'] },
  { id:'4', name:'Oyuna T.',   level:'Band 6.5–7.5', avatar:'https://api.dicebear.com/7.x/initials/svg?seed=Oyun&backgroundColor=fbbf24&fontFamily=Arial&fontSize=40',
    streak:8,  online:false, xp:755,  recentActivity:'Pronunciation lab score: 88%', bestBand:'7.0', totalSessions:36, badges:['Speed Run'] },
];

const LB = [
  { rank:1,  name:'Bataa N.',     school:'NUM',   xp:9840, streak:30, avatar:'https://api.dicebear.com/7.x/initials/svg?seed=Bata&backgroundColor=fbbf24&fontFamily=Arial&fontSize=40', title:'student' as UserTitle },
  { rank:2,  name:'Sara K.',      school:'MUST',  xp:9210, streak:22, avatar:'https://api.dicebear.com/7.x/initials/svg?seed=Sara&backgroundColor=a78bfa&fontFamily=Arial&fontSize=40' },
  { rank:3,  name:'Enkhjin B.',   school:'NUM',   xp:8820, streak:12, avatar:'https://api.dicebear.com/7.x/initials/svg?seed=Enkh&backgroundColor=22d3ee&fontFamily=Arial&fontSize=40', title:'verified' as UserTitle },
  { rank:4,  name:'Tulgaa M.',    school:'ШУТИС', xp:8400, streak:18, avatar:'https://api.dicebear.com/7.x/initials/svg?seed=Tulg&backgroundColor=fb923c&fontFamily=Arial&fontSize=40' },
  { rank:5,  name:'Oyuna T.',     school:'МУИС',  xp:7550, streak:8,  avatar:'https://api.dicebear.com/7.x/initials/svg?seed=Oyun&backgroundColor=4ade80&fontFamily=Arial&fontSize=40' },
  { rank:6,  name:'Anar D.',      school:'ХААИС', xp:7200, streak:6,  avatar:'https://api.dicebear.com/7.x/initials/svg?seed=Anar&backgroundColor=f472b6&fontFamily=Arial&fontSize=40' },
  { rank:7,  name:'Munkhbat S.',  school:'',      xp:6900, streak:15, avatar:'https://api.dicebear.com/7.x/initials/svg?seed=Munk&backgroundColor=60a5fa&fontFamily=Arial&fontSize=40' },
  { rank:8,  name:'Delgermaa E.', school:'УБИС',  xp:6540, streak:3,  avatar:'https://api.dicebear.com/7.x/initials/svg?seed=Delg&backgroundColor=34d399&fontFamily=Arial&fontSize=40' },
];

const SCHOOLS = [
  { school:'NUM',   count:234, avg:'7.2', bg:'bg-amber-400' },
  { school:'ШУТИС', count:189, avg:'7.0', bg:'bg-lime-400'  },
  { school:'МУИС',  count:156, avg:'6.8', bg:'bg-cyan-400'  },
  { school:'УБИС',  count:98,  avg:'6.5', bg:'bg-fuchsia-400'},
  { school:'МУБИС', count:76,  avg:'6.3', bg:'bg-rose-400'  },
];

const TITLE_STYLE: Record<string,string> = {
  owner:    'bg-gradient-to-r from-amber-400 to-orange-400 text-black border-amber-600',
  manager:  'bg-gradient-to-r from-fuchsia-500 to-purple-600 text-white border-fuchsia-700',
  verified: 'bg-gradient-to-r from-cyan-400 to-blue-500 text-white border-cyan-600',
  student:  'bg-gradient-to-r from-lime-400 to-emerald-500 text-black border-lime-600',
};

// ── Friend detail card (IG/Discord style) ─────────────────────────────────────
function FriendCard({ friend }: { friend: Friend }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className={`bg-white border-4 rounded-2xl transition-all overflow-hidden ${expanded ? 'border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]' : 'border-stone-200 hover:border-stone-400 hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,0.3)]'}`}>
      {/* Main row */}
      <button className="w-full flex items-center gap-3 p-4 text-left" onClick={() => { sfx.click(); setExpanded(!expanded); }}>
        <div className="relative flex-shrink-0">
          <img src={friend.avatar} className="w-11 h-11 rounded-xl border-2 border-stone-200 object-cover" alt="" />
          <div className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-white ${friend.online ? 'bg-lime-400' : 'bg-stone-300'}`} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5 flex-wrap">
            <p className="font-black text-stone-900 text-sm">{friend.name}</p>
            {friend.title && (
              <span className={`inline-flex items-center px-1.5 py-0.5 rounded border-2 font-black text-[8px] uppercase tracking-widest shadow-[1px_1px_0px_0px_rgba(0,0,0,0.8)] ${TITLE_STYLE[friend.title]}`}>{friend.title}</span>
            )}
          </div>
          <p className="text-[10px] text-stone-400 font-medium truncate">{friend.recentActivity}</p>
        </div>
        <div className="flex items-center gap-3 flex-shrink-0">
          <div className="flex items-center gap-1">
            <Flame className="w-3.5 h-3.5 text-amber-500" />
            <span className="font-black text-sm text-stone-700">{friend.streak}</span>
          </div>
          <ChevronRight className={`w-4 h-4 text-stone-300 transition-transform ${expanded ? 'rotate-90' : ''}`} />
        </div>
      </button>

      {/* Expanded detail — Discord/IG profile card style */}
      <AnimatePresence>
        {expanded && (
          <motion.div initial={{ height:0, opacity:0 }} animate={{ height:'auto', opacity:1 }} exit={{ height:0, opacity:0 }}
            transition={{ duration:0.2 }} className="overflow-hidden">
            <div className="border-t-2 border-stone-100 px-4 pb-4 pt-3">
              {/* Stats grid */}
              <div className="grid grid-cols-3 gap-2 mb-3">
                {[
                  { label:'XP', val: friend.xp.toLocaleString(), bg:'bg-amber-100', text:'text-amber-700' },
                  { label:'Best Band', val: friend.bestBand || '—', bg:'bg-lime-100', text:'text-lime-700' },
                  { label:'Sessions', val: String(friend.totalSessions || 0), bg:'bg-cyan-100', text:'text-cyan-700' },
                ].map(s => (
                  <div key={s.label} className={`${s.bg} rounded-xl p-2.5 text-center border-2 border-black`}>
                    <p className={`font-black text-sm ${s.text} leading-none`}>{s.val}</p>
                    <p className={`text-[9px] font-black uppercase tracking-widest ${s.text} opacity-70 mt-0.5`}>{s.label}</p>
                  </div>
                ))}
              </div>

              {/* Level + streak bar */}
              <div className="flex items-center gap-3 mb-3">
                <div className="flex-1 h-1.5 bg-stone-100 rounded-full overflow-hidden border border-stone-200">
                  <div className="h-full bg-amber-400 rounded-full" style={{ width: `${Math.min((friend.xp/1000)*100, 100)}%` }} />
                </div>
                <span className="text-[10px] font-black text-stone-400">{friend.level}</span>
              </div>

              {/* Badges */}
              {friend.badges && friend.badges.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mb-3">
                  {friend.badges.map(b => (
                    <span key={b} className="px-2 py-0.5 bg-stone-100 border-2 border-stone-300 rounded-lg text-[9px] font-black uppercase tracking-widest text-stone-600">{b}</span>
                  ))}
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-2">
                <button className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-stone-900 text-white border-4 border-black rounded-xl font-black text-[10px] uppercase tracking-widest shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all">
                  <Swords className="w-3 h-3" /> Challenge
                </button>
                <button className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-amber-400 text-black border-4 border-black rounded-xl font-black text-[10px] uppercase tracking-widest shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all">
                  <Zap className="w-3 h-3" /> Compare
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ── Streak challenge modal ────────────────────────────────────────────────────
function StreakChallenge({ onClose }: { onClose: () => void }) {
  const [selected, setSelected] = useState<string|null>(null);
  const [days, setDays] = useState(7);
  const [sent, setSent] = useState(false);
  return (
    <div className="fixed inset-0 z-[90] bg-black/60 backdrop-blur-sm flex items-end md:items-center justify-center p-4">
      <motion.div initial={{ y:40, opacity:0 }} animate={{ y:0, opacity:1 }} transition={{ duration:0.25, ease:[0.16,1,0.3,1] }}
        className="bg-white border-4 border-black rounded-3xl shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] w-full max-w-md overflow-hidden"
        onClick={e => e.stopPropagation()}>
        <div className="bg-amber-400 border-b-4 border-black px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5"><Zap className="w-5 h-5 text-black" /><h2 className="font-black text-black text-base uppercase tracking-tight">Streak Challenge</h2></div>
          <button onClick={onClose} className="w-8 h-8 bg-black/10 hover:bg-black/20 rounded-xl flex items-center justify-center transition-all"><X className="w-4 h-4 text-black" /></button>
        </div>
        <div className="p-5 space-y-4">
          {sent ? (
            <div className="text-center py-8">
              <div className="w-14 h-14 bg-lime-400 border-4 border-black rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]"><Check className="w-7 h-7 text-black" /></div>
              <h3 className="font-black text-xl text-stone-900 uppercase tracking-tight mb-2">Challenge Sent!</h3>
              <p className="text-stone-500 text-sm font-medium">May the best streak win.</p>
              <button onClick={onClose} className="mt-5 px-6 py-2.5 bg-stone-900 text-white border-4 border-black rounded-xl font-black text-xs uppercase tracking-widest shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">Close</button>
            </div>
          ) : (
            <>
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-400 mb-2">Pick opponent</p>
                <div className="space-y-1.5">
                  {FRIENDS.map(f => (
                    <button key={f.id} onClick={() => setSelected(f.id)}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border-4 transition-all ${selected===f.id ? 'border-black bg-amber-50 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]' : 'border-stone-200 hover:border-stone-400'}`}>
                      <img src={f.avatar} className="w-8 h-8 rounded-lg border-2 border-stone-200 object-cover" alt="" />
                      <div className="flex-1 text-left">
                        <p className="font-bold text-stone-900 text-sm">{f.name}</p>
                        <div className="flex items-center gap-1"><Flame className="w-3 h-3 text-amber-500" /><span className="text-[10px] text-stone-400 font-bold">{f.streak} day streak</span></div>
                      </div>
                      {selected===f.id && <Check className="w-4 h-4 text-lime-600" />}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-400 mb-2">Duration</p>
                <div className="flex gap-2">
                  {[3,7,14,30].map(d => (
                    <button key={d} onClick={() => setDays(d)}
                      className={`flex-1 py-2.5 rounded-xl border-4 font-black text-sm transition-all ${days===d ? 'border-black bg-stone-900 text-white shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]' : 'border-stone-200 text-stone-500 hover:border-stone-400'}`}>
                      {d}d
                    </button>
                  ))}
                </div>
              </div>
              <button onClick={() => selected && setSent(true)} disabled={!selected}
                className="w-full flex items-center justify-center gap-2 py-3.5 bg-amber-400 text-black border-4 border-black rounded-xl font-black text-sm uppercase tracking-widest shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all disabled:opacity-40">
                <Zap className="w-4 h-4" /> Send {days}-Day Challenge
              </button>
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
}

export const SocialHub: React.FC<SocialHubProps> = ({ userProfile, onClose }) => {
  const [tab, setTab] = useState<'leaderboard'|'friends'|'streaks'|'school'>('leaderboard');
  const [q, setQ] = useState('');
  const [copied, setCopied] = useState(false);
  const [showOnlineOnly, setShowOnlineOnly] = useState(false);
  const [showStreakModal, setShowStreakModal] = useState(false);
  const [notifStreak, setNotifStreak] = useState(true);
  const [lobbyMode, setLobbyMode] = useState<'create'|'join'>('create');
  const [lobbyCode, setLobbyCode] = useState('');

  const code = `#${(userProfile.name||'USER').replace(/\s/g,'').toUpperCase().slice(0,6)}-${Math.abs((userProfile.name?.charCodeAt(0)||65)*31)%9000+1000}`;
  const myXP = 5200;
  const myRank = LB.filter(u => u.xp > myXP).length + 1;

  const copy = () => { navigator.clipboard.writeText(code).catch(()=>{}); setCopied(true); sfx.xp(); setTimeout(()=>setCopied(false),2000); };

  const filteredFriends = FRIENDS
    .filter(f => !q || f.name.toLowerCase().includes(q.toLowerCase()))
    .filter(f => !showOnlineOnly || f.online);

  const tabs = [
    { id:'leaderboard', label:'Ranks',   icon:Trophy },
    { id:'friends',     label:'Friends', icon:Users  },
    { id:'streaks',     label:'Streaks', icon:Flame  },
    { id:'school',      label:'School',  icon:School },
  ] as const;

  // ── Overlay modal (not full screen) ────────────────────────────────────────
  return (
    <div className="fixed inset-0 z-[80] bg-black/60 backdrop-blur-md flex items-center justify-center p-4"
      onClick={e => { if (e.target === e.currentTarget) { sfx.back(); onClose(); } }}>
      {showStreakModal && <StreakChallenge onClose={() => setShowStreakModal(false)} />}

      <motion.div
        initial={{ scale:0.95, opacity:0, y:16 }}
        animate={{ scale:1, opacity:1, y:0 }}
        exit={{ scale:0.95, opacity:0 }}
        transition={{ duration:0.25, ease:[0.16,1,0.3,1] }}
        className="w-full max-w-lg bg-white border-4 border-black rounded-3xl shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] flex flex-col overflow-hidden max-h-[88vh]"
        style={{ fontFamily:"'Inter',sans-serif" }}
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-white border-b-4 border-black px-5 pt-5 pb-0 flex-shrink-0">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-cyan-400 border-4 border-black rounded-xl flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
                <Users className="w-4 h-4 text-black" />
              </div>
              <div>
                <h1 className="font-black text-stone-900 text-base uppercase tracking-tight leading-none">Social</h1>
                <p className="text-stone-400 text-[10px] font-medium">Friends · Rankings · Streaks</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => setShowStreakModal(true)}
                className="flex items-center gap-1.5 px-3 py-2 bg-amber-400 border-4 border-black rounded-xl font-black text-[10px] uppercase tracking-widest shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all">
                <Zap className="w-3.5 h-3.5 text-black" /> Challenge
              </button>
              <button onClick={() => { sfx.back(); onClose(); }}
                className="w-9 h-9 bg-stone-100 hover:bg-stone-200 border-2 border-stone-200 hover:border-stone-400 rounded-xl flex items-center justify-center text-stone-500 hover:text-stone-900 transition-all">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
          <div className="flex gap-1">
            {tabs.map(t => (
              <button key={t.id} onClick={() => { sfx.click(); setTab(t.id); }}
                className={`flex items-center gap-1.5 px-3 py-2.5 text-[11px] font-black uppercase tracking-widest border-b-4 -mb-[1px] transition-all ${tab===t.id ? 'border-black text-stone-900' : 'border-transparent text-stone-400 hover:text-stone-700'}`}>
                <t.icon className="w-3.5 h-3.5" />{t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto bg-stone-50">
          <AnimatePresence mode="wait">

            {/* LEADERBOARD */}
            {tab === 'leaderboard' && (
              <motion.div key="lb" initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} exit={{opacity:0}} transition={{duration:0.18}} className="p-4 space-y-4">
                <div className="bg-white border-4 border-black rounded-2xl p-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] flex items-center gap-3">
                  <div className="w-10 h-10 bg-amber-400 border-4 border-black rounded-xl flex items-center justify-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] font-black text-black text-sm">#{myRank}</div>
                  <img src={userProfile.avatar} className="w-10 h-10 rounded-xl border-2 border-stone-200 object-cover" alt="" />
                  <div className="flex-1">
                    <p className="font-black text-stone-900 text-sm">{userProfile.name}</p>
                    <p className="text-stone-400 text-xs font-medium">{myXP.toLocaleString()} XP · Your rank</p>
                  </div>
                  <p className="font-black text-2xl text-amber-500">#{myRank}</p>
                </div>

                {/* Podium */}
                <div className="bg-white border-4 border-black rounded-2xl p-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                  <p className="text-[10px] font-black uppercase tracking-widest text-stone-400 mb-4">Top 3</p>
                  <div className="flex items-end justify-center gap-3">
                    {[LB[1], LB[0], LB[2]].map((u, i) => {
                      const hs = ['h-20','h-28','h-16'];
                      const bg = ['bg-stone-300','bg-amber-400','bg-orange-400'];
                      const labels = ['2nd','1st','3rd'];
                      return (
                        <div key={u.rank} className="flex flex-col items-center gap-2 flex-1">
                          <img src={u.avatar} className="w-10 h-10 rounded-xl border-2 border-stone-200 object-cover" alt="" />
                          <p className="text-[10px] font-black text-stone-500 text-center">{u.name.split(' ')[0]}</p>
                          <div className={`w-full ${hs[i]} ${bg[i]} border-4 border-black rounded-t-xl flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]`}>
                            <span className="font-black text-black text-sm">{labels[i]}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-10">#</TableHead>
                      <TableHead>Student</TableHead>
                      <TableHead>School</TableHead>
                      <TableHead className="text-right">XP</TableHead>
                      <TableHead className="text-right w-16">Streak</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {LB.map(u => (
                      <TableRow key={u.rank}>
                        <TableCell>
                          <div className="w-7 h-7 bg-stone-100 border-2 border-stone-200 rounded-lg flex items-center justify-center font-black text-xs text-stone-500">{u.rank}</div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2.5">
                            <img src={u.avatar} className="w-7 h-7 rounded-lg border-2 border-stone-200 object-cover" alt="" />
                            <div>
                              <p className="font-bold text-stone-900 text-sm">{u.name}</p>
                              {u.title && <span className={`inline-flex items-center px-1 py-0.5 rounded border font-black text-[8px] uppercase ${TITLE_STYLE[u.title]}`}>{u.title}</span>}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-stone-400 text-xs">{u.school || '—'}</TableCell>
                        <TableCell className="text-right font-black text-stone-900">{u.xp.toLocaleString()}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center gap-1 justify-end">
                            <Flame className="w-3 h-3 text-amber-500" />
                            <span className="font-black text-sm text-stone-700">{u.streak}</span>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </motion.div>
            )}

            {/* FRIENDS — Instagram/Discord card style */}
            {tab === 'friends' && (
              <motion.div key="fr" initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} exit={{opacity:0}} transition={{duration:0.18}} className="p-4 space-y-3">
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                    <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search friends..."
                      className="w-full bg-white border-4 border-stone-200 rounded-xl pl-9 pr-4 py-2 text-sm font-medium focus:outline-none focus:border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,0.2)] transition-all" />
                  </div>
                  <Toggle pressed={showOnlineOnly} onPressedChange={setShowOnlineOnly} variant="outline" size="sm">
                    Online
                  </Toggle>
                </div>

                {/* Online count pill */}
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-lime-400 rounded-full" />
                  <p className="text-xs font-black text-stone-500 uppercase tracking-widest">{FRIENDS.filter(f=>f.online).length} online now</p>
                  <div className="flex-1 h-px bg-stone-200" />
                  <p className="text-xs font-black text-stone-500 uppercase tracking-widest">{FRIENDS.length} friends</p>
                </div>

                {filteredFriends.map(f => <FriendCard key={f.id} friend={f} />)}

                {filteredFriends.length === 0 && (
                  <div className="text-center py-10 opacity-50">
                    <Users className="w-8 h-8 text-stone-300 mx-auto mb-2" />
                    <p className="font-black text-xs uppercase tracking-widest text-stone-400">No friends found</p>
                  </div>
                )}

                {/* Friend code */}
                <div className="bg-white border-4 border-black rounded-2xl p-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                  <p className="font-black text-sm uppercase tracking-wide text-stone-900 mb-1 flex items-center gap-2">
                    <UserPlus className="w-4 h-4 text-lime-600" />Your Code
                  </p>
                  <p className="text-xs text-stone-400 font-medium mb-2">Share to get added as a friend.</p>
                  <div className="flex items-center gap-2 bg-stone-50 border-4 border-stone-200 rounded-xl px-4 py-2.5">
                    <code className="font-mono font-black text-amber-600 text-sm flex-1">{code}</code>
                    <button onClick={copy}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-stone-900 text-white rounded-lg text-[10px] font-black uppercase tracking-widest border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all">
                      {copied ? <Check className="w-3 h-3 text-lime-400" /> : <Copy className="w-3 h-3" />}
                      {copied ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                </div>
              </motion.div>
            )}

            {/* STREAKS */}
            {tab === 'streaks' && (
              <motion.div key="sk" initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} exit={{opacity:0}} transition={{duration:0.18}} className="p-4 space-y-4">
                <div className="bg-amber-400 border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                  <div className="flex items-center justify-between mb-3">
                    <div><p className="font-black text-black text-base uppercase tracking-tight">Your Streak</p><p className="text-black/60 text-xs font-medium">Keep studying every day</p></div>
                    <div className="flex items-center gap-2"><Flame className="w-8 h-8 text-black" /><span className="font-black text-4xl text-black">7</span></div>
                  </div>
                  <div className="flex gap-1.5 mt-3">
                    {['M','T','W','T','F','S','S'].map((d,i) => (
                      <div key={i} className="flex-1 flex flex-col items-center gap-1">
                        <div className={`w-full h-8 rounded-lg border-2 border-black flex items-center justify-center ${i < 5 ? 'bg-black' : 'bg-black/20'}`}>
                          {i < 5 && <Check className="w-3.5 h-3.5 text-amber-400" />}
                        </div>
                        <span className="text-[9px] font-black text-black/60">{d}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <p className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-400">Friend Challenges</p>
                  <button onClick={() => setShowStreakModal(true)}
                    className="flex items-center gap-1.5 px-3 py-2 bg-stone-900 text-white border-4 border-black rounded-xl font-black text-[10px] uppercase tracking-widest shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all">
                    <Zap className="w-3 h-3" /> New
                  </button>
                </div>

                <Table>
                  <TableHeader><TableRow>
                    <TableHead>Opponent</TableHead>
                    <TableHead className="text-center">Mine</TableHead>
                    <TableHead className="text-center">Theirs</TableHead>
                    <TableHead className="text-right">Days Left</TableHead>
                  </TableRow></TableHeader>
                  <TableBody>
                    {[
                      { friend:FRIENDS[0], mine:7, theirs:12, days:4 },
                      { friend:FRIENDS[2], mine:7, theirs:30, days:9 },
                    ].map(row => (
                      <TableRow key={row.friend.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="relative">
                              <img src={row.friend.avatar} className="w-7 h-7 rounded-lg border border-stone-200 object-cover" alt="" />
                              <div className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border border-white ${row.friend.online?'bg-lime-400':'bg-stone-300'}`} />
                            </div>
                            <span className="font-bold text-stone-900 text-sm">{row.friend.name.split(' ')[0]}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-center font-black text-stone-900">{row.mine}</TableCell>
                        <TableCell className="text-center font-black text-amber-600">{row.theirs}</TableCell>
                        <TableCell className="text-right"><span className="px-2 py-0.5 bg-stone-100 border-2 border-stone-300 rounded-lg text-[10px] font-black text-stone-600">{row.days}d</span></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>

                <div className="bg-white border-4 border-stone-200 rounded-xl p-4 flex items-center justify-between gap-3">
                  <div>
                    <p className="font-black text-stone-900 text-sm uppercase tracking-wide">Streak Reminders</p>
                    <p className="text-xs text-stone-400 font-medium">Daily reminder to keep your streak</p>
                  </div>
                  <Toggle pressed={notifStreak} onPressedChange={setNotifStreak} />
                </div>
              </motion.div>
            )}

            {/* SCHOOL */}
            {tab === 'school' && (
              <motion.div key="sc" initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} exit={{opacity:0}} transition={{duration:0.18}} className="p-4 space-y-4">
                <div className="bg-white border-4 border-black rounded-2xl p-5 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                  <p className="font-black text-sm uppercase tracking-wide text-stone-900 mb-3 flex items-center gap-2">
                    <School className="w-4 h-4 text-cyan-600" />Your School
                  </p>
                  <input defaultValue={userProfile.school || ''} placeholder="e.g. NUM, ШУТИС, МУИС..."
                    className="w-full bg-stone-50 border-4 border-stone-200 rounded-xl px-4 py-2.5 text-sm font-bold focus:outline-none focus:border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,0.2)] transition-all" />
                  <p className="text-[10px] text-stone-400 font-medium mt-2">Shown next to your name on the leaderboard.</p>
                </div>
                <Table>
                  <TableHeader><TableRow>
                    <TableHead className="w-10">#</TableHead>
                    <TableHead>School</TableHead>
                    <TableHead className="text-right">Students</TableHead>
                    <TableHead className="text-right">Avg Band</TableHead>
                  </TableRow></TableHeader>
                  <TableBody>
                    {SCHOOLS.map((s,i) => (
                      <TableRow key={s.school}>
                        <TableCell><div className={`w-7 h-7 ${s.bg} border-4 border-black rounded-lg flex items-center justify-center font-black text-xs text-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]`}>{i+1}</div></TableCell>
                        <TableCell className="font-bold text-stone-900">{s.school}</TableCell>
                        <TableCell className="text-right text-stone-500">{s.count}</TableCell>
                        <TableCell className="text-right font-black text-stone-900">Band {s.avg}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
};

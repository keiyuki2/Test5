import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AssessmentQuestion, Difficulty, UserProfile, Language } from '../types';
import { generateAssessmentTest } from '../services/geminiService';
import { Checkbox } from './ui/checkbox';
import { Badge } from './ui/badge';
import { TermsOfService } from './TermsOfService';
import { sfx } from '../services/soundService';
import {
  Mail, Lock, ArrowRight, ArrowLeft, Check, Loader2,
  ShieldCheck, Eye, EyeOff, RefreshCw, GraduationCap,
  Target, User, ChevronRight, Sparkles, X
} from 'lucide-react';

interface AuthScreenProps {
  mode: 'LOGIN' | 'SIGNUP' | 'ASSESSMENT';
  onComplete: (profile: UserProfile) => void;
  onBack: () => void;
  initialData?: UserProfile | null;
  lang: Language;
}

// Step type for the multi-step signup flow
type AuthStep =
  | 'MODE_SELECT'    // choose login vs signup
  | 'EMAIL'          // enter email
  | 'OTP'            // enter 6-digit code (simulated)
  | 'PASSWORD'       // set/enter password + terms (signup) OR just password (login)
  | 'PROFILE'        // name + target band + level
  | 'INTRO'          // assessment loading
  | 'TEST'           // assessment questions
  | 'RESULT';        // assessment result

// Slide animation config
const slide = {
  initial: (dir: number) => ({ opacity: 0, x: dir * 40 }),
  animate: { opacity: 1, x: 0 },
  exit:    (dir: number) => ({ opacity: 0, x: dir * -40 }),
  transition: { duration: 0.28, ease: [0.16, 1, 0.3, 1] },
};

// Generate a fake 6-digit OTP
function makeOTP() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

// ── Sub-component: Branded left panel ─────────────────────────────────────
function LeftPanel() {
  return (
    <div className="hidden lg:flex flex-col justify-between bg-stone-900 p-10 relative overflow-hidden">
      {/* Dot grid */}
      <div className="absolute inset-0 opacity-[0.04]"
        style={{ backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)', backgroundSize: '22px 22px' }} />
      {/* Glow */}
      <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-amber-400/15 rounded-full blur-[80px]" />
      <div className="absolute top-10 right-10 w-48 h-48 bg-rose-500/10 rounded-full blur-[60px]" />

      <div className="relative z-10">
        <div className="flex items-center gap-2.5 mb-12">
          <div className="w-9 h-9 bg-rose-500 border-4 border-white/20 rounded-xl flex items-center justify-center shadow-sm">
            <Target className="w-4 h-4 text-white" strokeWidth={2.5} />
          </div>
          <span className="font-black text-base tracking-tight uppercase text-white">
            IELTS<span className="text-rose-400"> MASTER</span>
          </span>
        </div>

        <h2 className="text-4xl font-black text-white uppercase tracking-tighter leading-tight mb-4">
          Your path to<br /><span className="text-amber-400">Band 8+</span> starts here.
        </h2>
        <p className="text-stone-400 font-medium leading-relaxed max-w-xs">
          AI-powered feedback, speaking simulation, and full mock exams — everything in one place.
        </p>
      </div>

      <div className="relative z-10 space-y-3">
        {[
          { stat: '50,000+', label: 'Students' },
          { stat: '95%',     label: 'Score improvement rate' },
          { stat: '0.5',     label: 'Avg band gain in 2 weeks' },
        ].map(s => (
          <div key={s.label} className="flex items-center gap-3">
            <div className="w-1.5 h-1.5 bg-amber-400 rounded-full flex-shrink-0" />
            <span className="font-black text-white text-sm">{s.stat}</span>
            <span className="text-stone-500 text-sm font-medium">{s.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Sub-component: Step indicator ─────────────────────────────────────────
function StepDots({ steps, current }: { steps: string[]; current: number }) {
  return (
    <div className="flex items-center gap-2">
      {steps.map((_, i) => (
        <div key={i} className={`h-1.5 rounded-full transition-all duration-300 ${
          i < current ? 'bg-lime-400 w-4' : i === current ? 'bg-amber-400 w-6' : 'bg-stone-200 w-3'
        }`} />
      ))}
    </div>
  );
}

// ── Main component ─────────────────────────────────────────────────────────
export const AuthScreen: React.FC<AuthScreenProps> = ({ mode, onComplete, onBack, initialData, lang }) => {
  const selectedPlan = (sessionStorage.getItem('selectedPlan') || 'free') as 'free' | 'pro' | 'elite';

  const initialStep: AuthStep = mode === 'ASSESSMENT' ? 'INTRO' : mode === 'LOGIN' ? 'EMAIL' : 'EMAIL';
  const [step, setStep] = useState<AuthStep>(initialStep);
  const [direction, setDirection] = useState(1); // 1 = forward, -1 = backward
  const [isLogin, setIsLogin] = useState(mode === 'LOGIN');

  // Form state
  const [email, setEmail]             = useState('');
  const [otpSent, setOtpSent]         = useState(false);
  const [fakeOTP]                      = useState(makeOTP());
  const [otpInput, setOtpInput]       = useState(['', '', '', '', '', '']);
  const [otpError, setOtpError]       = useState(false);
  const [password, setPassword]       = useState('');
  const [showPw, setShowPw]           = useState(false);
  const [agreedTerms, setAgreedTerms] = useState(false);
  const [agreedAge, setAgreedAge]     = useState(false);
  const [showTerms, setShowTerms]     = useState(false);
  const [name, setName]               = useState(initialData?.name || '');
  const [targetBand, setTargetBand]   = useState(initialData?.targetBand || '7.0');
  const [manualLevel, setManualLevel] = useState<Difficulty | null>(initialData?.proficiencyLevel || null);

  // Assessment state
  const [questions, setQuestions]           = useState<AssessmentQuestion[]>([]);
  const [currentQIndex, setCurrentQIndex]   = useState(0);
  const [score, setScore]                   = useState(0);
  const [calibrationPct, setCalibrationPct] = useState(0);
  const [logIndex, setLogIndex]             = useState(0);
  const LOG_MSGS = ['Generating questions...', 'Calibrating difficulty...', 'Almost ready...'];

  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);

  const go = (next: AuthStep, dir = 1) => {
    sfx.navigate();
    setDirection(dir);
    setStep(next);
  };

  useEffect(() => {
    if (mode === 'ASSESSMENT') startAssessment();
  }, []);

  // ── OTP input logic ──────────────────────────────────────────────────────
  const handleOtpChange = (i: number, val: string) => {
    if (!/^\d*$/.test(val)) return;
    const next = [...otpInput];
    next[i] = val.slice(-1);
    setOtpInput(next);
    setOtpError(false);
    if (val && i < 5) otpRefs.current[i + 1]?.focus();
  };

  const handleOtpKey = (i: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otpInput[i] && i > 0) {
      otpRefs.current[i - 1]?.focus();
    }
  };

  const handleOtpPaste = (e: React.ClipboardEvent) => {
    const text = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    if (text.length === 6) {
      setOtpInput(text.split(''));
      otpRefs.current[5]?.focus();
    }
  };

  const verifyOTP = () => {
    const entered = otpInput.join('');
    if (entered === fakeOTP) {
      sfx.correct();
      go(isLogin ? 'PASSWORD' : 'PASSWORD');
    } else {
      sfx.wrong();
      setOtpError(true);
      setOtpInput(['', '', '', '', '', '']);
      otpRefs.current[0]?.focus();
    }
  };

  const sendOTP = () => {
    if (!email.includes('@')) return;
    sfx.click();
    setOtpSent(true);
    // In prod this triggers an email — for now show the code in console for testing
    console.log(`[DEV] OTP for ${email}: ${fakeOTP}`);
    go('OTP');
  };

  const handlePasswordSubmit = () => {
    if (!password || password.length < 6) return;
    if (!isLogin && (!agreedTerms || !agreedAge)) return;
    sfx.click();
    if (isLogin) {
      // Simulate login — load stored profile
      const stored = localStorage.getItem('ielts_user_profile');
      if (stored) { onComplete(JSON.parse(stored)); return; }
    }
    go('PROFILE');
  };

  const handleProfileSubmit = (withAssessment: boolean) => {
    if (!name.trim()) return;
    if (withAssessment) { startAssessment(); return; }
    const level = manualLevel ?? Difficulty.MEDIUM;
    completeProfile(level);
  };

  const completeProfile = (level: Difficulty) => {
    sfx.complete();
    onComplete({
      name,
      targetBand,
      avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(name)}&backgroundColor=f43f5e&fontFamily=Arial&fontSize=40`,
      proficiencyLevel: level,
      plan: selectedPlan,
      synapseLevels: initialData?.synapseLevels || {},
    });
    sessionStorage.removeItem('selectedPlan');
  };

  // ── Assessment flow ────────────────────────────────────────────────────
  const startAssessment = async () => {
    setStep('INTRO');
    setCalibrationPct(0);
    setLogIndex(0);
    setScore(0);
    setCurrentQIndex(0);

    const promise = generateAssessmentTest();
    const interval = setInterval(() => setCalibrationPct(p => p >= 90 ? p : p + 2), 60);
    const logTimer = setInterval(() => setLogIndex(p => p < LOG_MSGS.length - 1 ? p + 1 : p), 900);

    try {
      const qs = await promise;
      setQuestions(qs);
      clearInterval(interval); clearInterval(logTimer);
      setCalibrationPct(100);
      setTimeout(() => { setDirection(1); setStep('TEST'); }, 400);
    } catch {
      clearInterval(interval); clearInterval(logTimer);
      completeProfile(Difficulty.MEDIUM);
    }
  };

  const handleAnswer = (opt: string) => {
    const q = questions[currentQIndex];
    const correct = opt === q.correctAnswer;
    if (correct) { sfx.correct(); setScore(s => s + 3); }
    else sfx.wrong();

    if (currentQIndex < questions.length - 1) {
      setCurrentQIndex(i => i + 1);
    } else {
      setDirection(1); setStep('RESULT');
    }
  };

  const finalizeResult = () => {
    const total = questions.length * 3;
    const pct = score / total;
    const level =
      pct >= 0.8 ? Difficulty.HARD :
      pct >= 0.55 ? Difficulty.MEDIUM :
      pct >= 0.35 ? Difficulty.EASY : Difficulty.FOUNDATION;
    completeProfile(level);
  };

  // ── SIGNUP STEPS: which index are we on ───────────────────────────────
  const signupSteps = ['Email', 'Verify', 'Password', 'Profile'];
  const signupIdx = { EMAIL: 0, OTP: 1, PASSWORD: 2, PROFILE: 3 }[step as string] ?? 0;

  // ── Shared wrapper ─────────────────────────────────────────────────────
  const Wrapper = ({ children }: { children: React.ReactNode }) => (
    <div className="fixed inset-0 z-50 bg-stone-50 flex" style={{ fontFamily: "'Inter', sans-serif" }}>
      {showTerms && <TermsOfService onClose={() => setShowTerms(false)} />}

      <LeftPanel />

      <div className="flex-1 flex flex-col items-center justify-center p-6 md:p-10 overflow-y-auto bg-stone-50 relative">
        {/* Subtle dot bg */}
        <div className="absolute inset-0 opacity-[0.025]"
          style={{ backgroundImage: 'radial-gradient(circle, #000 1px, transparent 1px)', backgroundSize: '24px 24px' }} />

        <div className="relative z-10 w-full max-w-md">
          {/* Back button */}
          <button onClick={() => { sfx.back(); onBack(); }}
            className="flex items-center gap-2 text-sm font-bold text-stone-400 hover:text-stone-900 transition-colors mb-8 group">
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" /> Back
          </button>

          <AnimatePresence mode="wait" custom={direction}>
            <motion.div key={step} custom={direction}
              variants={slide} initial="initial" animate="animate" exit="exit">
              {children}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );

  // ══════════════════════════════════════════════════════════════════════
  // STEP: EMAIL
  // ══════════════════════════════════════════════════════════════════════
  if (step === 'EMAIL') return (
    <Wrapper>
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 bg-amber-400 border-4 border-black rounded-xl flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
          <Mail className="w-5 h-5 text-black" />
        </div>
        <div>
          <Badge variant="default">{isLogin ? 'Log in' : 'Sign up'}</Badge>
        </div>
      </div>

      {!isLogin && (
        <div className="mt-3 mb-1">
          <StepDots steps={signupSteps} current={0} />
        </div>
      )}

      <h1 className="text-3xl font-black uppercase tracking-tighter text-stone-900 mt-4 mb-1">
        {isLogin ? 'Welcome back.' : 'Create account.'}
      </h1>
      <p className="text-stone-400 font-medium text-sm mb-8">
        {isLogin ? 'Enter your email to receive a login code.' : 'Enter your email — we\'ll send you a verification code.'}
      </p>

      <div className="space-y-4">
        <div>
          <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-stone-500 mb-1.5">Email address</label>
          <input
            type="email" value={email} onChange={e => setEmail(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && sendOTP()}
            autoFocus
            placeholder="you@gmail.com"
            className="w-full bg-white border-4 border-black rounded-xl px-4 py-3.5 text-sm font-medium text-stone-900 placeholder:text-stone-300 focus:outline-none focus:border-amber-400 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all"
          />
        </div>

        <button onClick={sendOTP} disabled={!email.includes('@')}
          className="w-full flex items-center justify-center gap-2.5 py-4 bg-stone-900 text-white border-4 border-black rounded-xl font-black text-sm uppercase tracking-widest shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all disabled:opacity-40 disabled:cursor-not-allowed group">
          Send Code <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>

      <div className="mt-6 pt-5 border-t border-stone-100 flex items-center justify-between">
        <span className="text-sm text-stone-400 font-medium">
          {isLogin ? "Don't have an account?" : 'Already have an account?'}
        </span>
        <button onClick={() => { sfx.click(); setIsLogin(!isLogin); }}
          className="text-sm font-black text-rose-500 hover:text-rose-700 transition-colors uppercase tracking-wide">
          {isLogin ? 'Sign up' : 'Log in'}
        </button>
      </div>
    </Wrapper>
  );

  // ══════════════════════════════════════════════════════════════════════
  // STEP: OTP
  // ══════════════════════════════════════════════════════════════════════
  if (step === 'OTP') return (
    <Wrapper>
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 bg-lime-400 border-4 border-black rounded-xl flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
          <ShieldCheck className="w-5 h-5 text-black" />
        </div>
        <Badge variant="success">Verify email</Badge>
      </div>
      {!isLogin && <div className="mt-3 mb-1"><StepDots steps={signupSteps} current={1} /></div>}

      <h1 className="text-3xl font-black uppercase tracking-tighter text-stone-900 mt-4 mb-1">Check your email.</h1>
      <p className="text-stone-400 font-medium text-sm mb-2">
        We sent a 6-digit code to <span className="text-stone-700 font-bold">{email}</span>.
      </p>
      {/* DEV hint */}
      <div className="bg-amber-50 border-2 border-amber-200 rounded-xl px-4 py-2 mb-6 flex items-center gap-2">
        <Sparkles className="w-3.5 h-3.5 text-amber-600 flex-shrink-0" />
        <span className="text-xs font-bold text-amber-700">Dev mode — code is logged to console. Check browser devtools.</span>
      </div>

      {/* 6-box OTP */}
      <div className="flex gap-2 mb-4" onPaste={handleOtpPaste}>
        {otpInput.map((val, i) => (
          <input key={i} ref={el => otpRefs.current[i] = el}
            type="text" inputMode="numeric" maxLength={1} value={val}
            onChange={e => handleOtpChange(i, e.target.value)}
            onKeyDown={e => handleOtpKey(i, e)}
            className={`w-11 h-11 text-center text-xl font-black border-4 rounded-xl focus:outline-none transition-all ${
              otpError ? 'border-rose-500 bg-rose-50 text-rose-700 shake' :
              val ? 'border-amber-400 bg-amber-50 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]' :
              'border-stone-300 bg-white focus:border-amber-400 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]'
            }`}
          />
        ))}
      </div>

      {otpError && (
        <p className="text-sm text-rose-500 font-bold mb-4 flex items-center gap-1.5">
          <X className="w-3.5 h-3.5" /> Incorrect code — try again.
        </p>
      )}

      <button onClick={verifyOTP} disabled={otpInput.join('').length < 6}
        className="w-full flex items-center justify-center gap-2.5 py-4 bg-lime-400 text-black border-4 border-black rounded-xl font-black text-sm uppercase tracking-widest shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all disabled:opacity-40 disabled:cursor-not-allowed">
        <ShieldCheck className="w-4 h-4" /> Verify Code
      </button>

      <div className="mt-5 flex items-center justify-between">
        <button onClick={() => go('EMAIL', -1)} className="text-sm text-stone-400 hover:text-stone-700 font-medium flex items-center gap-1.5 transition-colors">
          <ArrowLeft className="w-3.5 h-3.5" /> Change email
        </button>
        <button onClick={() => { sfx.click(); setOtpInput(['','','','','','']); setOtpError(false); }}
          className="text-sm text-stone-400 hover:text-rose-500 font-bold flex items-center gap-1.5 transition-colors">
          <RefreshCw className="w-3.5 h-3.5" /> Resend
        </button>
      </div>
    </Wrapper>
  );

  // ══════════════════════════════════════════════════════════════════════
  // STEP: PASSWORD
  // ══════════════════════════════════════════════════════════════════════
  if (step === 'PASSWORD') return (
    <Wrapper>
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 bg-rose-400 border-4 border-black rounded-xl flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
          <Lock className="w-5 h-5 text-black" />
        </div>
        <Badge variant="destructive">{isLogin ? 'Enter password' : 'Set password'}</Badge>
      </div>
      {!isLogin && <div className="mt-3 mb-1"><StepDots steps={signupSteps} current={2} /></div>}

      <h1 className="text-3xl font-black uppercase tracking-tighter text-stone-900 mt-4 mb-1">
        {isLogin ? 'Your password.' : 'Create password.'}
      </h1>
      <p className="text-stone-400 font-medium text-sm mb-6">
        {isLogin ? 'Enter your password to continue.' : 'Minimum 6 characters. Make it strong.'}
      </p>

      <div className="space-y-5">
        <div>
          <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-stone-500 mb-1.5">Password</label>
          <div className="relative">
            <input type={showPw ? 'text' : 'password'} value={password}
              onChange={e => setPassword(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handlePasswordSubmit()}
              autoFocus placeholder="••••••••"
              className="w-full bg-white border-4 border-black rounded-xl px-4 py-3.5 pr-12 text-sm font-medium text-stone-900 placeholder:text-stone-300 focus:outline-none focus:border-amber-400 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all" />
            <button type="button" onClick={() => setShowPw(!showPw)}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700 transition-colors">
              {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          {!isLogin && password.length > 0 && (
            <div className="mt-2 flex gap-1">
              {[2, 4, 8].map((threshold, i) => (
                <div key={i} className={`flex-1 h-1.5 rounded-full transition-all ${password.length >= threshold ? ['bg-rose-400', 'bg-amber-400', 'bg-lime-400'][i] : 'bg-stone-200'}`} />
              ))}
              <span className="text-[10px] font-bold text-stone-400 ml-2">
                {password.length < 4 ? 'Weak' : password.length < 8 ? 'Fair' : 'Strong'}
              </span>
            </div>
          )}
        </div>

        {/* Terms — only for signup */}
        {!isLogin && (
          <div className="space-y-3 bg-stone-50 border-2 border-stone-200 rounded-2xl p-4">
            <label className="flex items-start gap-3 cursor-pointer group">
              <Checkbox checked={agreedTerms} onCheckedChange={v => setAgreedTerms(!!v)} className="mt-0.5" />
              <span className="text-sm text-stone-600 font-medium leading-snug">
                I agree to the{' '}
                <button type="button" onClick={() => setShowTerms(true)}
                  className="text-rose-500 font-bold underline underline-offset-2 hover:text-rose-700 transition-colors">
                  Terms of Service
                </button>{' '}
                and{' '}
                <button type="button" onClick={() => setShowTerms(true)}
                  className="text-rose-500 font-bold underline underline-offset-2 hover:text-rose-700 transition-colors">
                  Privacy Policy
                </button>
              </span>
            </label>
            <label className="flex items-start gap-3 cursor-pointer">
              <Checkbox checked={agreedAge} onCheckedChange={v => setAgreedAge(!!v)} className="mt-0.5" />
              <span className="text-sm text-stone-600 font-medium">I confirm I am 13 years of age or older.</span>
            </label>
          </div>
        )}

        <button
          onClick={handlePasswordSubmit}
          disabled={!password || password.length < 6 || (!isLogin && (!agreedTerms || !agreedAge))}
          className="w-full flex items-center justify-center gap-2.5 py-4 bg-rose-500 text-white border-4 border-black rounded-xl font-black text-sm uppercase tracking-widest shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all disabled:opacity-40 disabled:cursor-not-allowed group">
          {isLogin ? 'Log In' : 'Continue'} <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </Wrapper>
  );

  // ══════════════════════════════════════════════════════════════════════
  // STEP: PROFILE
  // ══════════════════════════════════════════════════════════════════════
  if (step === 'PROFILE') return (
    <Wrapper>
      <div className="flex items-center gap-3 mb-2">
        <div className="w-10 h-10 bg-cyan-400 border-4 border-black rounded-xl flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
          <User className="w-5 h-5 text-black" />
        </div>
        <Badge variant="secondary">Almost done!</Badge>
      </div>
      <div className="mt-3 mb-1"><StepDots steps={signupSteps} current={3} /></div>

      <h1 className="text-3xl font-black uppercase tracking-tighter text-stone-900 mt-4 mb-1">Your profile.</h1>
      <p className="text-stone-400 font-medium text-sm mb-6">Tell us a bit about yourself.</p>

      <div className="space-y-5">
        <div>
          <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-stone-500 mb-1.5">Your name</label>
          <input type="text" value={name} onChange={e => setName(e.target.value)} autoFocus
            placeholder="e.g. Sara Kim"
            className="w-full bg-white border-4 border-black rounded-xl px-4 py-3.5 text-sm font-medium text-stone-900 placeholder:text-stone-300 focus:outline-none focus:border-amber-400 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all" />
        </div>

        <div>
          <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-stone-500 mb-2">Target band score</label>
          <div className="grid grid-cols-4 gap-2">
            {['6.0','6.5','7.0','7.5','8.0','8.5','9.0'].map(band => (
              <button key={band} type="button" onClick={() => { sfx.click(); setTargetBand(band); }}
                className={`py-2.5 rounded-xl border-4 font-black text-sm transition-all ${
                  targetBand === band
                    ? 'bg-amber-400 border-black shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] text-black'
                    : 'bg-white border-stone-200 text-stone-400 hover:border-stone-400 hover:text-stone-700'
                }`}>{band}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-stone-500 mb-2">Current level</label>
          <div className="grid grid-cols-2 gap-2">
            {([
              [Difficulty.FOUNDATION, 'Beginner',   'bg-rose-400'],
              [Difficulty.EASY,       'Elementary',  'bg-amber-400'],
              [Difficulty.MEDIUM,     'Intermediate','bg-lime-400'],
              [Difficulty.HARD,       'Advanced',    'bg-emerald-400'],
            ] as [Difficulty, string, string][]).map(([level, label, color]) => (
              <button key={level} type="button" onClick={() => { sfx.click(); setManualLevel(level); }}
                className={`py-3 px-4 rounded-xl border-4 font-black text-xs uppercase tracking-wide transition-all text-left ${
                  manualLevel === level
                    ? `${color} border-black shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] text-black`
                    : 'bg-white border-stone-200 text-stone-400 hover:border-stone-400'
                }`}>{label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-3">
          <button onClick={() => handleProfileSubmit(false)} disabled={!name.trim() || !manualLevel}
            className="w-full flex items-center justify-center gap-2.5 py-4 bg-stone-900 text-white border-4 border-black rounded-xl font-black text-sm uppercase tracking-widest shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] transition-all disabled:opacity-40 disabled:cursor-not-allowed group">
            Start Learning <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
          <button onClick={() => handleProfileSubmit(true)} disabled={!name.trim()}
            className="w-full flex items-center justify-center gap-2.5 py-3 bg-white text-stone-700 border-4 border-stone-200 rounded-xl font-black text-xs uppercase tracking-widest hover:border-black hover:text-stone-900 transition-all disabled:opacity-40">
            <GraduationCap className="w-4 h-4" /> Take Level Test Instead
          </button>
        </div>
      </div>
    </Wrapper>
  );

  // ══════════════════════════════════════════════════════════════════════
  // STEP: INTRO (assessment loading)
  // ══════════════════════════════════════════════════════════════════════
  if (step === 'INTRO') return (
    <div className="fixed inset-0 z-50 bg-stone-900 flex flex-col items-center justify-center p-8" style={{ fontFamily: "'Inter', sans-serif" }}>
      <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle, #fff 1px, transparent 1px)', backgroundSize: '24px 24px' }} />
      <div className="relative z-10 w-full max-w-sm flex flex-col items-center text-center">
        <div className="w-16 h-16 bg-amber-400 border-4 border-white/20 rounded-2xl flex items-center justify-center mb-8 shadow-[0_0_30px_rgba(251,191,36,0.3)]">
          <GraduationCap className="w-8 h-8 text-black" />
        </div>
        <h2 className="text-3xl font-black text-white uppercase tracking-tighter mb-2">Level Test</h2>
        <p className="text-stone-400 font-medium mb-10">Preparing your assessment...</p>
        <div className="w-full h-2 bg-stone-800 rounded-full overflow-hidden mb-3">
          <div className="h-full bg-amber-400 rounded-full transition-all duration-300 ease-out"
            style={{ width: `${calibrationPct}%`, boxShadow: '0 0 10px rgba(251,191,36,0.5)' }} />
        </div>
        <p className="text-amber-400 font-black text-4xl mb-2">{Math.round(calibrationPct)}%</p>
        <p className="text-stone-500 text-sm font-medium animate-pulse">{LOG_MSGS[logIndex]}</p>
      </div>
    </div>
  );

  // ══════════════════════════════════════════════════════════════════════
  // STEP: TEST
  // ══════════════════════════════════════════════════════════════════════
  if (step === 'TEST') {
    const q = questions[currentQIndex];
    const pct = ((currentQIndex) / questions.length) * 100;
    const diffColor = q?.difficulty === 'HARD' ? 'bg-rose-500' : q?.difficulty === 'MEDIUM' ? 'bg-amber-400' : 'bg-lime-400';
    if (!q) return null;
    return (
      <div className="fixed inset-0 z-50 bg-stone-50 flex items-center justify-center p-4" style={{ fontFamily: "'Inter', sans-serif" }}>
        <div className="w-full max-w-3xl">
          {/* Progress */}
          <div className="mb-8">
            <div className="flex justify-between items-center mb-2">
              <span className="text-xs font-black uppercase tracking-widest text-stone-500">Question {currentQIndex + 1} / {questions.length}</span>
              <span className={`text-[10px] font-black uppercase tracking-widest px-2.5 py-1 rounded-lg border-2 border-black text-black ${diffColor}`}>{q.difficulty}</span>
            </div>
            <div className="h-2 bg-stone-200 rounded-full overflow-hidden">
              <div className="h-full bg-stone-900 rounded-full transition-all duration-500" style={{ width: `${pct}%` }} />
            </div>
          </div>

          {/* Question */}
          <AnimatePresence mode="wait">
            <motion.div key={currentQIndex} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.2 }}>
              <div className="bg-white border-4 border-black rounded-3xl p-8 md:p-10 mb-6 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)]">
                <p className="text-xl md:text-2xl font-bold text-stone-900 leading-snug">{q.question}</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {q.options.map((opt, i) => (
                  <button key={i} onClick={() => handleAnswer(opt)}
                    className="group bg-white border-4 border-stone-200 rounded-2xl p-5 text-left font-medium text-stone-700 hover:border-black hover:text-stone-900 hover:-translate-y-1 hover:shadow-[5px_5px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-none transition-all flex items-start gap-3">
                    <span className="w-7 h-7 rounded-lg bg-stone-100 border-2 border-stone-300 text-xs font-black flex items-center justify-center flex-shrink-0 group-hover:bg-black group-hover:text-white group-hover:border-black transition-colors">
                      {String.fromCharCode(65 + i)}
                    </span>
                    {opt}
                  </button>
                ))}
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    );
  }

  // ══════════════════════════════════════════════════════════════════════
  // STEP: RESULT
  // ══════════════════════════════════════════════════════════════════════
  if (step === 'RESULT') {
    const total = questions.length * 3;
    const pct = Math.round((score / total) * 100);
    const band = pct >= 80 ? '8.0–9.0' : pct >= 55 ? '6.5–7.5' : pct >= 35 ? '4.5–6.0' : '1.0–4.0';
    const color = pct >= 80 ? 'bg-emerald-400' : pct >= 55 ? 'bg-lime-400' : pct >= 35 ? 'bg-amber-400' : 'bg-rose-400';

    return (
      <div className="fixed inset-0 z-50 bg-stone-50 flex items-center justify-center p-6" style={{ fontFamily: "'Inter', sans-serif" }}>
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 0.4, ease: [0.16,1,0.3,1] }}
          className="w-full max-w-md text-center">
          <div className={`w-24 h-24 ${color} border-4 border-black rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)]`}>
            <Check className="w-12 h-12 text-black" strokeWidth={3} />
          </div>
          <h2 className="text-4xl font-black uppercase tracking-tighter text-stone-900 mb-1">Test Complete</h2>
          <p className="text-stone-400 font-medium mb-8">Here are your results</p>

          <div className={`${color} border-4 border-black rounded-3xl p-8 mb-6 shadow-[5px_5px_0px_0px_rgba(0,0,0,1)]`}>
            <p className="text-[10px] font-black uppercase tracking-[0.25em] text-black/60 mb-1">Estimated Band</p>
            <p className="text-5xl font-black text-black">{band}</p>
            <p className="text-sm font-bold text-black/60 mt-1">{score} / {total} points · {pct}%</p>
          </div>

          <button onClick={finalizeResult}
            className="w-full flex items-center justify-center gap-2.5 py-4 bg-stone-900 text-white border-4 border-black rounded-2xl font-black text-sm uppercase tracking-widest shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all group">
            Start Learning <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </motion.div>
      </div>
    );
  }

  return null;
};

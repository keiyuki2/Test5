import React, { useState, useRef } from 'react';
import { Search, BookmarkCheck, Bookmark, X, Loader2, Book, Layers, Clock, Trash2 } from 'lucide-react';
import { VocabQuestion } from '../types';
import { generateVocabCard } from '../services/geminiService';
import { Badge } from './ui/badge';
import { sfx } from '../services/soundService';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from './ui/table';

interface DictionaryScreenProps {
  onBack?: () => void;
  onClose?: () => void;
  onSave: (card: VocabQuestion) => void;
  savedWords: string[];
  variant?: 'page' | 'modal';
}

export const DictionaryScreen: React.FC<DictionaryScreenProps> = ({ onClose, onSave, savedWords, variant = 'modal' }) => {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState<VocabQuestion | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const [history, setHistory] = useState<{ word: string; band: string; ts: Date }[]>([]);
  const [tab, setTab] = useState<'search' | 'history'>('search');
  const inputRef = useRef<HTMLInputElement>(null);

  const search = async (word: string) => {
    if (!word.trim()) return;
    sfx.click();
    setLoading(true); setError(false); setResult(null); setTab('search');
    try {
      const data = await generateVocabCard(word, 'General Dictionary Lookup');
      if (!data.id || data.id === '1') data.id = `dict-${Date.now()}`;
      setResult(data);
      setHistory(h => [{ word, band: data.band || '?', ts: new Date() }, ...h.filter(w => w.word !== word)].slice(0, 20));
    } catch { setError(true); }
    finally { setLoading(false); }
  };

  const isSaved = result && savedWords.includes(result.id);

  return (
    <div className="fixed inset-0 z-50 bg-stone-50 flex flex-col" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Header */}
      <div className="bg-white border-b-4 border-black px-5 py-4 flex items-center justify-between shadow-[0_4px_0px_0px_rgba(0,0,0,1)] shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-stone-900 border-4 border-black rounded-xl flex items-center justify-center shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
            <Book className="w-4 h-4 text-white" />
          </div>
          <div>
            <h1 className="font-black text-stone-900 text-base uppercase tracking-tight leading-none">Dictionary</h1>
            <p className="text-stone-400 text-[10px] font-medium">AI-powered · IELTS vocabulary</p>
          </div>
        </div>
        <button onClick={() => { sfx.back(); onClose?.(); }}
          className="w-9 h-9 bg-stone-100 hover:bg-stone-200 border-2 border-stone-200 hover:border-stone-400 rounded-xl flex items-center justify-center text-stone-500 hover:text-stone-900 transition-all">
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Search bar */}
      <div className="bg-white border-b border-stone-100 px-5 pt-4 pb-0 shrink-0">
        <form onSubmit={e => { e.preventDefault(); search(query); }} className="flex gap-2 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
            <input ref={inputRef} value={query} onChange={e => setQuery(e.target.value)}
              placeholder="Search any word..."
              className="w-full bg-white border-4 border-stone-200 rounded-xl pl-9 pr-4 py-2.5 text-sm font-medium text-stone-900 placeholder:text-stone-300 focus:outline-none focus:border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,0.3)] transition-all" />
          </div>
          <button type="submit" disabled={loading || !query.trim()}
            className="px-5 py-2.5 bg-stone-900 text-white border-4 border-black rounded-xl font-black text-xs uppercase tracking-widest shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-none transition-all disabled:opacity-40">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Go'}
          </button>
        </form>

        {/* Tabs */}
        <div className="flex gap-1 -mb-[1px]">
          {([['search','Results'], ['history','History']] as const).map(([t, label]) => (
            <button key={t} onClick={() => setTab(t)}
              className={`flex items-center gap-1.5 px-4 py-2 text-xs font-black uppercase tracking-widest border-b-4 transition-all ${tab===t ? 'border-black text-stone-900' : 'border-transparent text-stone-400 hover:text-stone-700'}`}>
              {t === 'history' && <Clock className="w-3 h-3" />}
              {label} {t === 'history' && history.length > 0 && <span className="ml-1 w-4 h-4 bg-stone-900 text-white rounded-full text-[9px] font-black flex items-center justify-center">{history.length}</span>}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* ── SEARCH TAB ─────────────────────────────────────── */}
        {tab === 'search' && (
          <div className="px-5 py-5 space-y-4">
            {loading && (
              <div className="flex flex-col items-center py-16 gap-4">
                <Loader2 className="w-8 h-8 animate-spin text-stone-400" />
                <p className="font-black text-sm uppercase tracking-widest text-stone-400">Looking up...</p>
              </div>
            )}
            {error && !loading && (
              <div className="flex flex-col items-center py-16 gap-3">
                <div className="w-14 h-14 bg-rose-100 border-4 border-rose-300 rounded-2xl flex items-center justify-center">
                  <X className="w-7 h-7 text-rose-500" />
                </div>
                <p className="font-black text-sm uppercase tracking-widest text-stone-500">Word not found</p>
                <p className="text-xs text-stone-400 font-medium">Try a different spelling</p>
              </div>
            )}
            {!result && !loading && !error && (
              <div className="flex flex-col items-center py-16 gap-3 opacity-40">
                <Book className="w-10 h-10 text-stone-300" />
                <p className="font-black text-sm uppercase tracking-widest text-stone-400">Search a word</p>
              </div>
            )}
            {result && !loading && (
              <div className="bg-white border-4 border-black rounded-3xl overflow-hidden shadow-[6px_6px_0px_0px_rgba(0,0,0,1)]">
                <div className="bg-stone-900 px-6 pt-6 pb-5">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h2 className="text-4xl font-black text-white capitalize tracking-tight leading-none mb-3">{result.word}</h2>
                      <div className="flex flex-wrap gap-2">
                        <Badge variant="success">Band {result.band}</Badge>
                        <Badge variant="secondary">Academic</Badge>
                      </div>
                    </div>
                    <button onClick={() => onSave(result)}
                      className={`w-11 h-11 rounded-xl border-4 border-black flex items-center justify-center transition-all shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-none flex-shrink-0 ${isSaved ? 'bg-amber-400' : 'bg-white hover:bg-stone-100'}`}>
                      {isSaved ? <BookmarkCheck className="w-5 h-5 text-black" /> : <Bookmark className="w-5 h-5 text-black" />}
                    </button>
                  </div>
                </div>
                <div className="p-6 space-y-5">
                  <div className="flex gap-4">
                    <div className="w-1 bg-amber-400 rounded-full flex-shrink-0" />
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-widest text-stone-400 mb-1">Definition</p>
                      <p className="text-base font-bold text-stone-900 leading-relaxed">{result.definition}</p>
                    </div>
                  </div>
                  <div className="bg-amber-50 border-4 border-amber-200 rounded-2xl p-4 relative">
                    <div className="absolute -top-3 left-4 bg-amber-400 border-2 border-black px-2.5 py-0.5 rounded-lg">
                      <span className="text-[10px] font-black uppercase tracking-widest text-black">Example</span>
                    </div>
                    <p className="text-sm font-medium text-stone-700 italic leading-relaxed mt-1">"{result.contextSentence}"</p>
                  </div>
                  {result.synonyms?.length > 0 && (
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-widest text-stone-400 mb-2.5 flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5" /> Synonyms
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {result.synonyms.map((s, i) => (
                          <button key={i} onClick={() => { setQuery(s); search(s); }}
                            className="px-3 py-1.5 bg-white border-4 border-stone-200 rounded-xl text-xs font-bold text-stone-700 hover:border-black hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all">
                            {s}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── HISTORY TAB with Table ──────────────────────────── */}
        {tab === 'history' && (
          <div className="px-5 py-5">
            {history.length === 0 ? (
              <div className="flex flex-col items-center py-16 gap-3 opacity-40">
                <Clock className="w-10 h-10 text-stone-300" />
                <p className="font-black text-sm uppercase tracking-widest text-stone-400">No history yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] font-black uppercase tracking-widest text-stone-400">{history.length} words looked up</p>
                  <button onClick={() => setHistory([])}
                    className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-rose-500 hover:text-rose-700 transition-colors">
                    <Trash2 className="w-3 h-3" /> Clear
                  </button>
                </div>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>#</TableHead>
                      <TableHead>Word</TableHead>
                      <TableHead>Band</TableHead>
                      <TableHead>Looked up</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {history.map((h, i) => (
                      <TableRow key={h.word + i}>
                        <TableCell className="text-stone-400 font-black text-xs">{i + 1}</TableCell>
                        <TableCell className="font-bold text-stone-900 capitalize">{h.word}</TableCell>
                        <TableCell><Badge variant="success">Band {h.band}</Badge></TableCell>
                        <TableCell className="text-stone-400 text-xs font-medium">
                          {h.ts.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </TableCell>
                        <TableCell>
                          <button onClick={() => { setQuery(h.word); search(h.word); }}
                            className="px-3 py-1 bg-stone-900 text-white border-2 border-black rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-stone-700 transition-colors">
                            Look up
                          </button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

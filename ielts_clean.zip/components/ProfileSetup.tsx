

import React, { useState, useRef, useEffect } from 'react';
import { AssessmentQuestion, Difficulty, UserProfile, Language } from '../types';
import { generateAssessmentTest } from '../services/geminiService';
import { translations } from '../translations';
import { User, Target, ArrowRight, Upload, Loader2, Check, X, Shield, PenTool, RefreshCw, GraduationCap, ChevronRight, Cpu, Network, Database } from 'lucide-react';

interface ProfileSetupProps {
  onComplete: (profile: UserProfile) => void;
  initialData?: UserProfile | null;
  lang: Language;
}

type SetupPhase = 'DASHBOARD' | 'IDENTITY' | 'INTRO' | 'TEST' | 'RESULT';

export const ProfileSetup: React.FC<ProfileSetupProps> = ({ onComplete, initialData, lang }) => {
  const [phase, setPhase] = useState<SetupPhase>(initialData ? 'DASHBOARD' : 'IDENTITY');
  const t = translations[lang];
  
  // Identity State
  const [name, setName] = useState(initialData?.name || '');
  const [targetBand, setTargetBand] = useState(initialData?.targetBand || '7.0');
  const [avatar, setAvatar] = useState(initialData?.avatar || ''); // Base64 string
  
  // Manual Level Selection
  const [manualLevel, setManualLevel] = useState<Difficulty | null>(initialData?.proficiencyLevel || null);
  
  // Test State
  const [questions, setQuestions] = useState<AssessmentQuestion[]>([]);
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [score, setScore] = useState(0); 
  
  // Intro Animation State
  const [calibrationProgress, setCalibrationProgress] = useState(0);
  const [logIndex, setLogIndex] = useState(0);
  
  const LOG_MESSAGES = [
      "Getting things ready...",
      "Setting up your test...",
      "Almost done..."
  ];

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onloadend = () => {
              setAvatar(reader.result as string);
          };
          reader.readAsDataURL(file);
      }
  };

  const startAssessment = async () => {
      setPhase('INTRO');
      setCalibrationProgress(0);
      setLogIndex(0);

      // Start fetching in background
      const questionPromise = generateAssessmentTest();

      // Animation Loop
      const interval = setInterval(() => {
          setCalibrationProgress(prev => {
              if (prev >= 90) return prev; // Wait for promise
              return prev + 1.5;
          });
      }, 50);

      const logInterval = setInterval(() => {
          setLogIndex(prev => (prev < LOG_MESSAGES.length - 1 ? prev + 1 : prev));
      }, 800);

      try {
          const qs = await questionPromise;
          setQuestions(qs);
          
          clearInterval(interval);
          clearInterval(logInterval);
          setCalibrationProgress(100);
          setLogIndex(LOG_MESSAGES.length - 1); 

          setTimeout(() => {
              setPhase('TEST');
          }, 1000);
      } catch (e) {
          console.error("Failed to load test", e);
          completeProfile(Difficulty.MEDIUM); // Fallback
      }
  };

  const handleAnswer = (option: string) => {
      const currentQuestion = questions[currentQIndex];
      
      if (option === currentQuestion.correctAnswer) {
          let points = 1;
          if (currentQuestion.difficulty === 'MEDIUM') points = 2;
          if (currentQuestion.difficulty === 'HARD') points = 3;
          setScore(s => s + points);
      }

      if (currentQIndex < questions.length - 1) {
          setCurrentQIndex(prev => prev + 1);
      } else {
          finishTest();
      }
  };

  const finishTest = () => {
      setPhase('RESULT');
  };

  const finalizeResult = () => {
       // Score mapping (Total max ~30)
       let level = Difficulty.FOUNDATION;
       if (score >= 24) level = Difficulty.HARD;
       else if (score >= 16) level = Difficulty.MEDIUM;
       else if (score >= 8) level = Difficulty.EASY;
       
       completeProfile(level);
  };

  const completeProfile = (level: Difficulty) => {
      /**
       */
      onComplete({
          name,
          targetBand,
          avatar: avatar || 'https://api.dicebear.com/7.x/avataaars/svg?seed=Agent',
          proficiencyLevel: level,
          synapseLevels: initialData?.synapseLevels || {}
      });
  };

  const handleSaveIdentityOnly = () => {
      const level = manualLevel || initialData?.proficiencyLevel || Difficulty.MEDIUM;
      completeProfile(level);
  };

  // --- RENDERERS ---

  if (phase === 'DASHBOARD') {
      return (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
            <div className="bg-white rounded-[3rem] p-8 md:p-12 w-full max-w-2xl border-4 border-black shadow-[16px_16px_0px_0px_rgba(0,0,0,1)] relative overflow-hidden">
                <button 
                    onClick={() => onComplete(initialData!)}
                    className="absolute top-8 right-8 p-2 rounded-full hover:bg-slate-100 transition-colors"
                >
                    <X className="w-6 h-6 text-slate-400 hover:text-black" />
                </button>

                <div className="flex flex-col items-center text-center">
                    <div className="w-32 h-32 md:w-40 md:h-40 rounded-full border-4 border-black p-1 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] mb-6 bg-white">
                        <img 
                            src={avatar || 'https://api.dicebear.com/7.x/avataaars/svg?seed=Felix'} 
                            alt="Profile" 
                            className="w-full h-full rounded-full object-cover"
                        />
                    </div>
                    
                    <h2 className="text-4xl md:text-5xl font-black text-slate-900 uppercase tracking-tighter mb-2">
                        {name}
                    </h2>
                    <div className="flex gap-3 mb-8">
                        <span className="bg-black text-white px-3 py-1 rounded-lg font-bold uppercase text-xs tracking-widest flex items-center gap-2">
                            <Target className="w-3 h-3" /> Band {targetBand}
                        </span>
                        <span className="bg-amber-400 text-black px-3 py-1 rounded-lg font-bold uppercase text-xs tracking-widest flex items-center gap-2 border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                            <Shield className="w-3 h-3" /> {initialData?.proficiencyLevel}
                        </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
                        <button 
                            onClick={() => setPhase('IDENTITY')}
                            className="bg-white border-4 border-black rounded-2xl p-6 flex items-center justify-between hover:bg-slate-50 hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transition-all group"
                        >
                            <div className="text-left">
                                <h3 className="font-black uppercase text-lg">{t.profile.editDetails}</h3>
                                <p className="text-xs font-bold text-slate-400">{t.profile.updateProfile}</p>
                            </div>
                            <div className="bg-black text-white p-3 rounded-full group-hover:scale-110 transition-transform">
                                <PenTool className="w-5 h-5" />
                            </div>
                        </button>

                        <button 
                            onClick={startAssessment}
                            className="bg-white border-4 border-black rounded-2xl p-6 flex items-center justify-between hover:bg-slate-50 hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transition-all group"
                        >
                            <div className="text-left">
                                <h3 className="font-black uppercase text-lg">{t.profile.recalibrate}</h3>
                                <p className="text-xs font-bold text-slate-400">{t.profile.saveAndRetake}</p>
                            </div>
                            <div className="bg-amber-400 text-black p-3 rounded-full group-hover:scale-110 transition-transform border-2 border-black">
                                <RefreshCw className="w-5 h-5" />
                            </div>
                        </button>
                    </div>
                </div>
            </div>
        </div>
      );
  }

  if (phase === 'IDENTITY') {
    // Identity phase remains mostly the same, ensuring clean layout
    return (
        <div className="fixed inset-0 z-50 bg-white flex items-center justify-center p-4 animate-fade-in overflow-y-auto">
        <div className="bg-white rounded-[2.5rem] p-8 md:p-12 w-full max-w-xl border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] relative overflow-hidden">
            
            {initialData && (
                 <button 
                    onClick={() => setPhase('DASHBOARD')}
                    className="absolute top-8 right-8 text-xs font-black uppercase tracking-widest text-slate-400 hover:text-black z-20"
                >
                    {t.common.back}
                </button>
            )}

            <div className="relative z-10">
                <div className="text-center mb-10">
                    <div className="inline-block bg-black text-white text-xs font-black uppercase px-3 py-1 rounded mb-4 tracking-widest border-2 border-transparent">
                        IELTS
                    </div>
                    <h2 className="text-4xl md:text-5xl font-black text-slate-900 uppercase tracking-tighter italic leading-none">
                        {initialData ? t.profile.updateProfile : t.profile.identityRequired}
                    </h2>
                </div>

                <form onSubmit={(e) => { e.preventDefault(); }} className="space-y-8">
                    {/* Avatar Upload */}
                    <div className="flex flex-col items-center">
                        <div 
                            onClick={() => fileInputRef.current?.click()}
                            className="w-32 h-32 rounded-full border-4 border-black border-dashed flex items-center justify-center cursor-pointer hover:bg-slate-50 transition-colors overflow-hidden relative group"
                        >
                            {avatar ? (
                                <img src={avatar} alt="Avatar" className="w-full h-full object-cover" />
                            ) : (
                                <div className="text-center text-slate-400">
                                    <Upload className="w-8 h-8 mx-auto mb-1" />
                                    <span className="text-[10px] font-bold uppercase">{t.profile.upload}</span>
                                </div>
                            )}
                            <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-white font-bold text-xs uppercase">
                                {t.profile.change}
                            </div>
                        </div>
                        <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
                    </div>

                    {/* Name Input */}
                    <div>
                        <label className="block text-xs font-black uppercase tracking-widest text-slate-400 mb-2">{t.profile.candidateName}</label>
                        <div className="relative">
                            <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                            <input 
                                type="text" 
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                className="w-full bg-slate-50 border-4 border-black rounded-xl py-4 pl-12 pr-4 font-bold text-lg focus:outline-none focus:bg-white focus:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all placeholder:text-slate-300"
                                placeholder={t.profile.enterName}
                                autoFocus
                            />
                        </div>
                    </div>

                    {/* Manual Level Selection */}
                    <div>
                        <label className="block text-xs font-black uppercase tracking-widest text-slate-400 mb-2">Choose your level</label>
                        <div className="grid grid-cols-2 gap-3">
                            {[Difficulty.FOUNDATION, Difficulty.EASY, Difficulty.MEDIUM, Difficulty.HARD].map((level) => (
                                <button
                                    key={level}
                                    type="button"
                                    onClick={() => setManualLevel(level)}
                                    className={`py-3 px-2 rounded-xl border-2 font-black text-xs md:text-sm uppercase tracking-wide transition-all ${
                                        manualLevel === level
                                        ? 'bg-amber-400 text-black border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]'
                                        : 'bg-white text-slate-500 border-slate-200 hover:border-black hover:text-black'
                                    }`}
                                >
                                    {level}
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Target Band */}
                    <div>
                        <label className="block text-xs font-black uppercase tracking-widest text-slate-400 mb-2">{t.profile.targetBand}</label>
                        <div className="grid grid-cols-4 gap-3">
                            {['6.0', '6.5', '7.0', '7.5', '8.0', '8.5', '9.0'].map(band => (
                                <button
                                    key={band}
                                    type="button"
                                    onClick={() => setTargetBand(band)}
                                    className={`py-2 rounded-lg border-2 font-black transition-all ${
                                        targetBand === band
                                        ? 'bg-black text-white border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)]'
                                        : 'bg-white text-slate-400 border-slate-200 hover:border-black hover:text-black'
                                    }`}
                                >
                                    {band}
                                </button>
                            ))}
                        </div>
                    </div>
                    
                    <div className="flex flex-col gap-3">
                        <button 
                            onClick={handleSaveIdentityOnly}
                            disabled={!name.trim() || !manualLevel}
                            className="w-full bg-emerald-500 text-black py-4 rounded-xl font-black text-xl uppercase tracking-wider border-4 border-transparent hover:border-black shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-none transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                        >
                            {initialData ? t.profile.saveChanges : "Start Learning"} <Check className="w-6 h-6" />
                        </button>
                        
                        {!initialData && (
                            <div className="relative flex py-2 items-center">
                                <div className="flex-grow border-t border-slate-300"></div>
                                <span className="flex-shrink-0 mx-4 text-slate-400 text-xs font-bold uppercase">OR</span>
                                <div className="flex-grow border-t border-slate-300"></div>
                            </div>
                        )}

                        <button 
                            onClick={startAssessment}
                            disabled={!name.trim()}
                            className={`w-full bg-slate-100 text-slate-600 py-3 rounded-xl font-black text-sm uppercase tracking-wider border-2 border-transparent hover:border-black hover:bg-white hover:text-black transition-all flex items-center justify-center gap-2 ${!name.trim() ? 'opacity-50 cursor-not-allowed' : ''}`}
                        >
                            <GraduationCap className="w-5 h-5" /> 
                            {initialData ? t.profile.recalibrate : "Check my level"}
                        </button>
                    </div>
                </form>
            </div>
        </div>
        </div>
    );
  }

  // --- INTRO PHASE (Simplified Loading) ---
  if (phase === 'INTRO') {
      return (
          <div className="fixed inset-0 z-50 bg-stone-50 flex flex-col items-center justify-center p-8 text-center overflow-hidden" style={{fontFamily:"'Inter',sans-serif"}}>
              <div className="relative z-10 w-full max-w-md flex flex-col items-center">
                  <div className="w-full relative mb-8">
                      <div className="h-4 w-full bg-slate-100 border-2 border-black rounded-full relative overflow-hidden flex items-center p-1">
                          <div 
                            className="h-full bg-black relative transition-all duration-100 ease-out"
                            style={{ width: `${calibrationProgress}%` }}
                          >
                          </div>
                      </div>
                      <div className="mt-4 text-4xl font-black tracking-tighter text-black">
                          {Math.round(calibrationProgress)}%
                      </div>
                  </div>

                  <div className="text-slate-900 text-lg font-bold tracking-wide h-8 overflow-hidden relative">
                      <span className="animate-pulse">{LOG_MESSAGES[logIndex]}</span>
                  </div>
              </div>
          </div>
      );
  }

  // --- TEST PHASE (The UI Upgrade) ---
  if (phase === 'TEST') {
      const q = questions[currentQIndex];
      const diffColor = q.difficulty === 'HARD' ? 'bg-rose-500' : q.difficulty === 'MEDIUM' ? 'bg-amber-500' : 'bg-emerald-500';
      const progressPercent = ((currentQIndex + 1) / questions.length) * 100;

      return (
          <div className="fixed inset-0 z-50 bg-stone-50 flex items-center justify-center p-4" style={{fontFamily:"'Inter',sans-serif"}}>
              <div className="w-full max-w-4xl h-full md:h-auto flex flex-col">
                  
                  {/* Top Progress */}
                  <div className="mb-6 md:mb-8 animate-slide-up">
                      <div className="flex justify-between items-end mb-2 px-2">
                          <div>
                              <h2 className="text-xl font-black text-slate-900 uppercase tracking-tighter italic">Level Test</h2>
                              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Question {currentQIndex + 1} of {questions.length}</span>
                          </div>
                          <div className={`px-3 py-1 rounded-full text-white text-[10px] font-black uppercase tracking-widest ${diffColor} shadow-md`}>
                              {q.difficulty}
                          </div>
                      </div>
                      <div className="h-3 bg-slate-200 rounded-full overflow-hidden">
                          <div className="h-full bg-stone-900 transition-all duration-500 ease-out" style={{ width: `${progressPercent}%` }}></div>
                      </div>
                  </div>

                  {/* Question Card */}
                  <div className="bg-white rounded-[2.5rem] border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] p-8 md:p-12 mb-6 md:mb-8 flex-1 flex flex-col justify-center animate-scale-in relative overflow-hidden">
                      {/* Decorative Background Element */}
                      <div className="absolute top-0 right-0 w-64 h-64 bg-stone-900 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none opacity-5"></div>
                      
                      <h3 className="text-2xl md:text-4xl font-black text-slate-900 leading-tight relative z-10">
                          {q.question}
                      </h3>
                  </div>

                  {/* Options Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 animate-slide-up" style={{ animationDelay: '0.1s' }}>
                      {q.options.map((opt, i) => (
                          <button
                            key={i}
                            onClick={() => handleAnswer(opt)}
                            className="group relative bg-white p-6 md:p-8 rounded-[2rem] border-4 border-slate-200 text-left hover:border-black hover:-translate-y-2 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transition-all duration-200 active:translate-y-0 active:shadow-none"
                          >
                              <div className="flex items-center justify-between mb-2">
                                  <span className="w-8 h-8 rounded-full bg-slate-100 border-2 border-slate-300 text-slate-500 font-black flex items-center justify-center text-sm group-hover:bg-black group-hover:text-white group-hover:border-black transition-colors">
                                      {String.fromCharCode(65 + i)}
                                  </span>
                                  <ArrowRight className="w-5 h-5 text-slate-300 group-hover:text-black opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0" />
                              </div>
                              <p className="text-lg md:text-xl font-bold text-slate-700 group-hover:text-black transition-colors">
                                  {opt}
                              </p>
                          </button>
                      ))}
                  </div>
              </div>
          </div>
      );
  }

  // --- RESULT PHASE (Celebration) ---
  if (phase === 'RESULT') {
      return (
          <div className="fixed inset-0 z-50 bg-stone-900 flex items-center justify-center p-4 overflow-hidden" style={{fontFamily:"'Inter',sans-serif"}}>
               {/* Confetti Background (Simple CSS Circles) */}
               <div className="absolute inset-0 pointer-events-none">
                   <div className="absolute top-1/4 left-1/4 w-4 h-4 bg-yellow-400 rounded-full animate-ping"></div>
                   <div className="absolute top-3/4 right-1/4 w-6 h-6 bg-rose-500 rounded-full animate-ping [animation-delay:0.2s]"></div>
                   <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-amber-400/20 rounded-full blur-[100px]"></div>
               </div>

               <div className="bg-white rounded-[3rem] p-12 max-w-lg w-full border-8 border-white/10 bg-clip-padding backdrop-filter relative z-10 text-center animate-scale-in shadow-2xl">
                   
                   <div className="w-32 h-32 bg-emerald-400 rounded-full flex items-center justify-center mx-auto mb-8 border-8 border-white shadow-[0_20px_50px_rgba(16,185,129,0.3)] animate-bounce">
                       <Check className="w-16 h-16 text-black" />
                   </div>
                   
                   <h2 className="text-5xl font-black uppercase tracking-tighter mb-2 text-slate-900">All Done</h2>
                   <p className="text-slate-500 font-bold uppercase tracking-widest text-sm mb-8">Test Finished</p>
                   
                   <div className="bg-slate-50 rounded-2xl p-6 mb-8 border-2 border-slate-100">
                       <p className="text-xs font-black uppercase text-slate-400 mb-2">Your Score</p>
                       <div className="text-4xl font-black text-slate-900">{score} <span className="text-lg text-slate-400">/ 30</span></div>
                   </div>

                   <button 
                     onClick={finalizeResult}
                     className="w-full py-5 bg-black text-white rounded-2xl font-black text-xl uppercase tracking-wider shadow-xl hover:bg-amber-400 hover:text-black hover:-translate-y-1 transition-all active:scale-95 flex items-center justify-center gap-3"
                   >
                       Go to Home <ChevronRight className="w-6 h-6" />
                   </button>
               </div>
          </div>
      );
  }

  return null;
};
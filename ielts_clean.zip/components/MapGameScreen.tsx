
import React, { useState, useEffect } from 'react';
import { MapQuestion, Language } from '../types';
import { translations } from '../translations';
import { ArrowRight, Volume2, Check, X, MapPin, RotateCcw } from 'lucide-react';

interface MapGameScreenProps {
  questions: MapQuestion[];
  onComplete: () => void;
  lang: Language;
}

export const MapGameScreen: React.FC<MapGameScreenProps> = ({ questions, onComplete, lang }) => {
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [hasAnswered, setHasAnswered] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const t = translations[lang];

  const currentQ = questions && questions[index];

  useEffect(() => {
    // Auto play audio instructions on load
    const timer = setTimeout(() => playAudio(), 500);
    return () => {
        clearTimeout(timer);
        window.speechSynthesis.cancel();
    };
  }, [index]);

  const playAudio = () => {
      if (!currentQ || isPlaying) return;
      setIsPlaying(true);
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(currentQ.audioScript);
      utterance.lang = 'en-GB';
      utterance.rate = 0.9;
      utterance.onend = () => setIsPlaying(false);
      window.speechSynthesis.speak(utterance);
  };

  const handleLocationClick = (loc: string) => {
    if (hasAnswered) return;
    
    setSelectedLocation(loc);
    setHasAnswered(true);
    
    if (loc === currentQ.correctLocationId) {
        setScore(s => s + 1);
    }
  };

  const handleNext = () => {
    if (index < questions.length - 1) {
      setIndex(i => i + 1);
      setHasAnswered(false);
      setSelectedLocation(null);
    } else {
      // End
      setIndex(i => i + 1);
    }
  };

  // Mock Map SVG - A simple schematic layout
  const renderMap = () => {
      // Different layouts could be rendered based on currentQ.mapSvg ID
      // For now we use a generic Campus layout
      return (
        <svg viewBox="0 0 800 600" className="w-full h-full bg-[#f0f9ff] rounded-[2rem]">
            {/* Grid Pattern */}
            <defs>
                <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                    <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#e2e8f0" strokeWidth="1"/>
                </pattern>
            </defs>
            <rect width="800" height="600" fill="url(#grid)" />

            {/* Roads */}
            <path d="M 400 600 L 400 450 Q 400 300 200 300 L 50 300" stroke="#cbd5e1" strokeWidth="50" fill="none" strokeLinecap="round" />
            <path d="M 400 450 L 400 150" stroke="#cbd5e1" strokeWidth="50" fill="none" strokeLinecap="round" />
            <path d="M 400 300 L 750 300" stroke="#cbd5e1" strokeWidth="50" fill="none" strokeLinecap="round" />
            
            {/* Roads inner white line */}
            <path d="M 400 600 L 400 450 Q 400 300 200 300 L 50 300" stroke="white" strokeWidth="40" fill="none" strokeLinecap="round" strokeDasharray="10,10" />
            <path d="M 400 450 L 400 150" stroke="white" strokeWidth="40" fill="none" strokeLinecap="round" strokeDasharray="10,10" />
            <path d="M 400 300 L 750 300" stroke="white" strokeWidth="40" fill="none" strokeLinecap="round" strokeDasharray="10,10" />

            {/* Entrance */}
            <g transform="translate(350, 540)">
                <rect width="100" height="40" fill="#0f172a" rx="8" />
                <text x="50" y="25" fill="white" fontSize="14" fontWeight="900" textAnchor="middle" letterSpacing="2">ENTRANCE</text>
            </g>

            {/* Fountain (Central Feature) */}
            <circle cx="400" cy="300" r="35" fill="#38bdf8" stroke="black" strokeWidth="3" />
            <circle cx="400" cy="300" r="20" fill="#bae6fd" stroke="none" />

            {/* Locations */}
            {(currentQ.options || []).map((opt, i) => {
                // Determine coordinates based on option name/index (mock logic for demo)
                // Real implementation would have coordinates in data
                const coords = [
                    { x: 100, y: 100 }, { x: 600, y: 100 }, 
                    { x: 100, y: 500 }, { x: 600, y: 500 },
                    { x: 400, y: 50 }
                ];
                const pos = coords[i % coords.length];
                
                // Don't render "Entrance" or "Fountain" as clickable options if they are just landmarks
                if (opt === 'Entrance' || opt === 'Fountain') return null;

                const isSelected = selectedLocation === opt;
                const isCorrect = currentQ.correctLocationId === opt;
                
                let fill = "white";
                let stroke = "black";
                let textColor = "black";
                
                if (hasAnswered) {
                    if (isCorrect) { fill = "#34d399"; stroke = "#064e3b"; } 
                    else if (isSelected) { fill = "#fb7185"; stroke = "#881337"; textColor="white"; }
                } else if (isSelected) {
                    fill = "#e0f2fe";
                }

                return (
                    <g 
                        key={opt} 
                        transform={`translate(${pos.x}, ${pos.y})`} 
                        onClick={() => handleLocationClick(opt)}
                        className="cursor-pointer hover:scale-105 transition-transform"
                        style={{ pointerEvents: hasAnswered ? 'none' : 'auto' }}
                    >
                        {/* Shadow */}
                        <rect x="-56" y="-36" width="120" height="80" rx="12" fill="black" opacity="0.2" />
                        
                        {/* Building */}
                        <rect x="-60" y="-40" width="120" height="80" rx="12" fill={fill} stroke={stroke} strokeWidth="4" />
                        
                        {/* Label */}
                        <text x="0" y="5" fontSize="14" fontWeight="bold" textAnchor="middle" fill={textColor} style={{textTransform: 'uppercase', fontFamily: 'sans-serif'}}>
                            {hasAnswered ? opt : '?'}
                        </text>
                        
                        {hasAnswered && isCorrect && (
                            <circle cx="50" cy="-30" r="14" fill="#34d399" stroke="black" strokeWidth="2" />
                        )}
                        {hasAnswered && isCorrect && (
                             <path d="M 45 -30 L 50 -25 L 55 -35" stroke="black" strokeWidth="3" fill="none" />
                        )}
                    </g>
                );
            })}
        </svg>
      );
  };

  if (!currentQ || index >= questions.length) {
       return (
          <div className="w-full max-w-2xl mx-auto py-12 px-6 animate-slide-up">
              <div className="bg-white rounded-[3rem] p-10 border-4 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] text-center relative overflow-hidden">
                  <div className="mb-8 relative z-10">
                      <div className="w-24 h-24 bg-sky-500 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                          <MapPin className="w-12 h-12 text-black" />
                      </div>
                      <h2 className="text-5xl font-black uppercase tracking-tighter mb-2">{t.vocab.finishSet}</h2>
                      <p className="text-2xl font-bold text-slate-500">
                          {t.common.score}: <span className="text-sky-600 bg-sky-100 px-2 rounded border border-sky-200">{score}</span> / {questions.length}
                      </p>
                  </div>
                  <button 
                    onClick={onComplete}
                    className="w-full py-5 bg-black text-white rounded-2xl font-black text-xl uppercase tracking-wider shadow-[6px_6px_0px_0px_rgba(0,0,0,0.5)] border-2 border-transparent hover:border-black hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 active:translate-y-0 active:shadow-none transition-all flex items-center justify-center gap-2 relative z-10"
                  >
                      {t.common.tryAgain} <RotateCcw className="w-6 h-6" />
                  </button>
              </div>
          </div>
       );
  }

  return (
    <div className="w-full max-w-[1400px] mx-auto py-6 px-4 flex flex-col h-[calc(100vh-100px)] animate-slide-up">
        {/* Top Bar */}
        <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-black text-slate-900 uppercase tracking-tighter flex items-center gap-3">
                <div className="bg-sky-500 p-2 rounded-lg border-2 border-black">
                    <MapPin className="w-6 h-6 text-white" />
                </div>
                Map Master
            </h2>
            <div className="bg-white text-black px-4 py-2 rounded-xl font-black border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                Score: {score}
            </div>
        </div>

        <div className="flex-1 flex flex-col md:flex-row gap-8 overflow-hidden">
            {/* Left: Map */}
            <div className="w-full md:w-2/3 bg-white rounded-[2.5rem] border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] relative overflow-hidden">
                {renderMap()}
            </div>

            {/* Right: Controls & Script */}
            <div className="w-full md:w-1/3 flex flex-col gap-6">
                <div className="bg-sky-100 p-8 rounded-[2.5rem] border-4 border-black shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] flex-1 flex flex-col justify-center items-center text-center relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-sky-300 rounded-full blur-3xl opacity-50 transform translate-x-1/2 -translate-y-1/2"></div>
                    
                    <button 
                        onClick={() => playAudio()}
                        className={`w-28 h-28 rounded-full border-4 border-black flex items-center justify-center shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-all mb-8 relative z-10 ${isPlaying ? 'bg-amber-400 animate-pulse' : 'bg-white hover:bg-sky-50 hover:-translate-y-1'}`}
                    >
                        <Volume2 className="w-12 h-12 text-black" />
                    </button>
                    
                    <div className="bg-white px-4 py-1 rounded-full border-2 border-black font-black text-xs uppercase tracking-widest mb-4">Listening Task</div>
                    <p className="text-slate-900 font-bold text-lg leading-snug">"Click the correct building on the map."</p>
                    
                    {hasAnswered && (
                        <div className="mt-8 bg-white p-6 rounded-2xl border-2 border-black w-full text-left max-h-[250px] overflow-y-auto shadow-sm animate-scale-in">
                            <p className="text-xs font-black uppercase text-slate-400 mb-2 tracking-wider">Audio Transcript</p>
                            <p className="text-sm leading-relaxed font-medium">{currentQ.audioScript}</p>
                        </div>
                    )}
                </div>

                {hasAnswered && (
                    <button 
                        onClick={handleNext}
                        className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black text-xl uppercase tracking-wider shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] border-2 border-black hover:bg-indigo-700 hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-none transition-all flex items-center justify-center gap-2"
                    >
                        {t.common.next} <ArrowRight className="w-6 h-6" />
                    </button>
                )}
            </div>
        </div>
    </div>
  );
};

import React, { useRef, useState, useEffect, useCallback } from 'react';
import {
  Eraser, PenTool, Trash2, Undo, X, Wand2,
  Square, Circle, Minus, Download, ZoomIn, ZoomOut,
  ChevronLeft, Highlighter
} from 'lucide-react';
import { recognizeHandwrittenMath } from '../services/geminiService';
import { Toggle } from './ui/toggle';

interface Props { onClose: () => void }

const COLORS = ['#000000','#ef4444','#3b82f6','#22c55e','#f97316','#a855f7','#ffffff'];
const WIDTHS = [2, 4, 7, 12];

export const WhiteboardCanvas: React.FC<Props> = ({ onClose }) => {
  const canvasRef  = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [drawing, setDrawing] = useState(false);
  const [color,   setColor]   = useState('#000000');
  const [width,   setWidth]   = useState(4);
  const [tool,    setTool]    = useState<'pen'|'eraser'|'rect'|'circle'|'line'|'highlight'>('pen');
  const [history, setHistory] = useState<ImageData[]>([]);
  const [aiResult, setAiResult] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const shapeStart = useRef<{x:number,y:number}|null>(null);
  const snapshot   = useRef<ImageData|null>(null);

  const ctx = () => canvasRef.current?.getContext('2d') ?? null;

  const resize = useCallback(() => {
    const c = canvasRef.current, cont = containerRef.current;
    if (!c || !cont) return;
    const saved = ctx()?.getImageData(0, 0, c.width, c.height);
    c.width  = cont.clientWidth;
    c.height = cont.clientHeight;
    const cx = ctx();
    if (cx) {
      cx.fillStyle = '#ffffff';
      cx.fillRect(0, 0, c.width, c.height);
      if (saved) cx.putImageData(saved, 0, 0);
      cx.lineCap = 'round';
      cx.lineJoin = 'round';
    }
  }, []);

  useEffect(() => {
    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, [resize]);

  const getPos = (e: React.MouseEvent | React.TouchEvent) => {
    const rect = canvasRef.current!.getBoundingClientRect();
    const src = 'touches' in e ? e.touches[0] : e;
    return { x: src.clientX - rect.left, y: src.clientY - rect.top };
  };

  const saveHistory = () => {
    const c = canvasRef.current; if (!c) return;
    const img = ctx()?.getImageData(0, 0, c.width, c.height);
    if (img) setHistory(h => [...h.slice(-19), img]);
  };

  const applyStroke = (cx: CanvasRenderingContext2D) => {
    if (tool === 'eraser') {
      cx.globalCompositeOperation = 'destination-out';
      cx.strokeStyle = 'rgba(0,0,0,1)';
      cx.lineWidth = width * 4;
    } else if (tool === 'highlight') {
      cx.globalCompositeOperation = 'source-over';
      cx.strokeStyle = color + '55';
      cx.lineWidth = width * 5;
    } else {
      cx.globalCompositeOperation = 'source-over';
      cx.strokeStyle = color;
      cx.lineWidth = width;
    }
    cx.lineCap = 'round';
    cx.lineJoin = 'round';
  };

  const onStart = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    const cx = ctx(); if (!cx) return;
    saveHistory();
    const p = getPos(e);
    if (['rect','circle','line'].includes(tool)) {
      shapeStart.current = p;
      snapshot.current = cx.getImageData(0, 0, canvasRef.current!.width, canvasRef.current!.height);
    } else {
      applyStroke(cx);
      cx.beginPath();
      cx.moveTo(p.x, p.y);
    }
    setDrawing(true);
  };

  const onMove = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    if (!drawing) return;
    const cx = ctx(); if (!cx) return;
    const p = getPos(e);
    if (tool === 'pen' || tool === 'eraser' || tool === 'highlight') {
      applyStroke(cx);
      cx.lineTo(p.x, p.y);
      cx.stroke();
      cx.beginPath();
      cx.moveTo(p.x, p.y);
    } else if (shapeStart.current && snapshot.current) {
      cx.putImageData(snapshot.current, 0, 0);
      cx.globalCompositeOperation = 'source-over';
      cx.strokeStyle = color; cx.lineWidth = width; cx.lineCap = 'round';
      const {x:sx, y:sy} = shapeStart.current;
      cx.beginPath();
      if (tool === 'rect')   { cx.strokeRect(sx, sy, p.x - sx, p.y - sy); }
      if (tool === 'line')   { cx.moveTo(sx, sy); cx.lineTo(p.x, p.y); cx.stroke(); }
      if (tool === 'circle') {
        const rx = (p.x - sx) / 2, ry = (p.y - sy) / 2;
        cx.ellipse(sx + rx, sy + ry, Math.abs(rx), Math.abs(ry), 0, 0, Math.PI * 2);
        cx.stroke();
      }
    }
  };

  const onEnd = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    const cx = ctx(); if (!cx) return;
    cx.globalCompositeOperation = 'source-over';
    setDrawing(false);
    shapeStart.current = null;
    snapshot.current = null;
  };

  const undo = () => {
    const cx = ctx(); const c = canvasRef.current; if (!cx || !c) return;
    if (history.length === 0) { cx.fillStyle='#fffdf5'; cx.fillRect(0,0,c.width,c.height); return; }
    cx.putImageData(history[history.length - 1], 0, 0);
    setHistory(h => h.slice(0,-1));
  };

  const clear = () => {
    const cx = ctx(); const c = canvasRef.current; if (!cx||!c) return;
    saveHistory();
    cx.fillStyle = '#fffdf5';
    cx.fillRect(0, 0, c.width, c.height);
    setAiResult('');
  };

  const download = () => {
    const c = canvasRef.current; if (!c) return;
    const a = document.createElement('a');
    a.href = c.toDataURL('image/png');
    a.download = 'whiteboard.png';
    a.click();
  };

  const runAI = async () => {
    const c = canvasRef.current; if (!c) return;
    setAiLoading(true); setAiResult('');
    try {
      const dataUrl = c.toDataURL('image/png');
      const result = await recognizeHandwrittenMath(dataUrl);
      setAiResult(result);
    } catch { setAiResult('Could not recognize. Try writing more clearly.'); }
    finally { setAiLoading(false); }
  };

  const tools: { id: typeof tool; icon: any; label: string }[] = [
    { id: 'pen',       icon: PenTool,     label: 'Pen'       },
    { id: 'highlight', icon: Highlighter, label: 'Highlighter'},
    { id: 'eraser',    icon: Eraser,      label: 'Eraser'    },
    { id: 'line',      icon: Minus,       label: 'Line'      },
    { id: 'rect',      icon: Square,      label: 'Rect'      },
    { id: 'circle',    icon: Circle,      label: 'Circle'    },
  ];

  return (
    <div className="fixed inset-0 z-[100] bg-white flex flex-col" style={{ fontFamily:"'Inter',sans-serif", touchAction:'none' }}>

      {/* ── Toolbar ──────────────────────────────────────────────────── */}
      <div className="bg-white border-b-4 border-black flex items-center gap-2 px-3 py-2 shrink-0 shadow-[0_4px_0px_0px_rgba(0,0,0,1)] flex-wrap">
        {/* Back */}
        <button onClick={onClose}
          className="flex items-center gap-1.5 px-3 py-2 bg-stone-100 border-4 border-stone-300 rounded-xl font-black text-xs uppercase tracking-widest text-stone-700 hover:border-black hover:text-stone-900 transition-all shadow-[2px_2px_0px_0px_rgba(0,0,0,0.3)] flex-shrink-0">
          <ChevronLeft className="w-4 h-4" /> Back
        </button>

        <div className="w-px h-6 bg-stone-200 flex-shrink-0" />

        {/* Tool buttons */}
        <div className="flex gap-1">
          {tools.map(t => (
            <button key={t.id} onClick={() => setTool(t.id)} title={t.label}
              className={`w-9 h-9 rounded-xl border-4 flex items-center justify-center transition-all ${tool===t.id ? 'bg-stone-900 border-black text-white shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]' : 'border-stone-200 text-stone-500 hover:border-stone-400 hover:text-stone-900'}`}>
              <t.icon className="w-4 h-4" />
            </button>
          ))}
        </div>

        <div className="w-px h-6 bg-stone-200 flex-shrink-0" />

        {/* Colors */}
        <div className="flex gap-1.5 items-center">
          {COLORS.map(c => (
            <button key={c} onClick={() => setColor(c)} title={c}
              className={`w-6 h-6 rounded-full border-4 transition-all ${color===c ? 'border-black scale-125 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]' : 'border-stone-300 hover:border-stone-500'}`}
              style={{ background: c }} />
          ))}
        </div>

        <div className="w-px h-6 bg-stone-200 flex-shrink-0" />

        {/* Widths */}
        <div className="flex gap-1.5 items-center">
          {WIDTHS.map(w => (
            <button key={w} onClick={() => setWidth(w)} title={`${w}px`}
              className={`flex items-center justify-center rounded-lg border-4 transition-all ${width===w ? 'border-black bg-stone-100 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]' : 'border-stone-200 hover:border-stone-400'}`}
              style={{ width: 32, height: 32 }}>
              <div className="rounded-full bg-stone-900" style={{ width: Math.min(w * 2, 20), height: Math.min(w * 2, 20) }} />
            </button>
          ))}
        </div>

        <div className="w-px h-6 bg-stone-200 flex-shrink-0" />

        {/* Actions */}
        <div className="flex gap-1">
          <button onClick={undo} title="Undo" className="w-9 h-9 rounded-xl border-4 border-stone-200 flex items-center justify-center text-stone-500 hover:border-black hover:text-stone-900 transition-all">
            <Undo className="w-4 h-4" />
          </button>
          <button onClick={clear} title="Clear" className="w-9 h-9 rounded-xl border-4 border-stone-200 flex items-center justify-center text-stone-500 hover:border-rose-500 hover:text-rose-500 transition-all">
            <Trash2 className="w-4 h-4" />
          </button>
          <button onClick={download} title="Download" className="w-9 h-9 rounded-xl border-4 border-stone-200 flex items-center justify-center text-stone-500 hover:border-black hover:text-stone-900 transition-all">
            <Download className="w-4 h-4" />
          </button>
          <button onClick={runAI} disabled={aiLoading} title="AI Math Solve"
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border-4 font-black text-xs uppercase tracking-widest transition-all shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] active:translate-y-0 active:shadow-none ${aiLoading ? 'border-stone-200 text-stone-400' : 'bg-amber-400 border-black text-black'}`}>
            <Wand2 className="w-3.5 h-3.5" />
            {aiLoading ? 'Solving...' : 'AI Solve'}
          </button>
        </div>
      </div>

      {/* ── Canvas ───────────────────────────────────────────────────── */}
      <div ref={containerRef} className="flex-1 relative overflow-hidden cursor-crosshair">
        <canvas ref={canvasRef}
          onMouseDown={onStart} onMouseMove={onMove} onMouseUp={onEnd} onMouseLeave={onEnd}
          onTouchStart={onStart} onTouchMove={onMove} onTouchEnd={onEnd}
          className="absolute inset-0 w-full h-full"
          style={{ cursor: tool === 'eraser' ? 'cell' : tool === 'pen' || tool === 'highlight' ? 'crosshair' : 'crosshair', touchAction: 'none', WebkitUserSelect: 'none' }}
        />

        {/* AI result overlay */}
        {aiResult && (
          <div className="absolute bottom-4 left-4 right-4 bg-white border-4 border-black rounded-2xl p-4 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)]">
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1">
                <p className="text-[10px] font-black uppercase tracking-widest text-stone-400 mb-1.5 flex items-center gap-1.5">
                  <Wand2 className="w-3 h-3 text-amber-500" /> AI Result
                </p>
                <p className="font-bold text-stone-900 text-sm leading-relaxed">{aiResult}</p>
              </div>
              <button onClick={() => setAiResult('')}
                className="w-7 h-7 bg-stone-100 border-2 border-stone-200 rounded-lg flex items-center justify-center text-stone-500 hover:text-stone-900 transition-all flex-shrink-0">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
